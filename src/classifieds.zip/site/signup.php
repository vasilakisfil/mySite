﻿<?php
/****************************************************************************************
*	Auth h selida emfanizei thn forma eggrafhs enos kainourgiou xrhsth
*****************************************************************************************/

//including required files
include('includes.php');


dispHeader('');
//h sunarthsh dispRegForm() emfanizei thn forma eggrafhs
dispRegForm();
dispFooter();

?>
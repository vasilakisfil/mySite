#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <omp.h>

#define DIM	2400

//struct that holds all the necessary information about the graph and the under-construction MST
struct prim_data {
  
  int edges_weight[DIM][DIM];
  int dimension;
  int U[DIM];
  int total_min_distance;
  int count_nodes_in_mst;
    
};


struct prim_data prim;

//variable that holds the current maximum distance
int min_distance;
//variable that holds the next node in MST
int new_next_element;

#endif

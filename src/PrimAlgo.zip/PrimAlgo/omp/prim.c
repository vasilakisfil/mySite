#include <stdio.h>
#include "functions.h"
#include "global.h"

int main(int argc, char **argv)
{
	int ch,j,t,p_c,p_j,k,serial=1;
	long i;
	//declaring the structs the are used by gettimeofday
	struct timeval tb1;
	struct timeval tb2;

	//setting the minimum distance
	min_distance = 1000;

	opterr = 0;
	//parsing the arguments given
	while ((ch = getopt (argc, argv, "c:l:s")) != -1) {
	  
		switch(ch) {
			case 'c':
				createfile(2400,optarg);
				loadfile(optarg);
				break;
			case 'l':
				loadfile(optarg);				
				break;
			case 's':
				serial=0;
				break;
			case '?':
				usage(argv[0]);
				exit(0);
			default:
				usage(argv[0]);
				exit(0);
		}
	}
	
	//initializing the data
    initialization();
    
	//getting  system's local time
	gettimeofday(&tb1,NULL);

	//calculating for all the nodes
	for(k = 0; k < prim.dimension -1; k++)
	{
	   	min_distance = 1000;
		//for every node in minimum spanning tree  	
		for(i = 0; i < prim.count_nodes_in_mst; i++)
		{
			//declaring OpenMP's derective with the appropriate scheduling...
			#pragma omp parallel for schedule(dynamic,300)
			for(j = 0; j < prim.dimension; j++)
			{
				//find the minimum weight
				if(prim.edges_weight[prim.U[i]][j] > min_distance || prim.edges_weight[prim.U[i]][j]==0)
				{
				 
				  continue;
				  
				}
				else
				{
					#pragma omp critical
					{
						min_distance = prim.edges_weight[prim.U[i]][j];
						new_next_element = j;
				 	}
				  
				}
			}	
		}
	  
	
		//Adding the local min_distance to the total_min_distance	  
		prim.total_min_distance += min_distance;
		//Adding the next node in the U set
		prim.U[i] = new_next_element;
		//Substructing the elements of the column in which  the new node is assosiated with
		delete_elements( new_next_element );
		//Increasing the nodes that they are in the MST
		prim.count_nodes_in_mst++;
	    
	}
	//get once more the system's local time
	gettimeofday(&tb2,NULL);

	printf("\n");
	//Print all the nodes in MST in the way that they stored in the U set
	for(i = 0 ; i < prim.dimension; i++) {
	  
	    printf("%d ",prim.U[i] + 1);
	    if( i < prim.dimension - 1 ) printf("-> ");
	   
      }
      
      printf("\n\n");      
      printf("Total minimun distance: %d\n\n", prim.total_min_distance);
      printf("\nProgram terminates now..\n");

	//calculating the difference between the two time measurements
	double real = (double)tb2.tv_sec-(double)tb1.tv_sec + ((double)tb2.tv_usec-(double)tb1.tv_usec)/1000000;
	printf("time: %f\n", real);

	return 0;
}

#ifndef FUNCTIONS_H
#define FUNCTIONS_h

#include "global.h"
//a function that prints how the program's parameters work
void usage( const char *prog );
//function that writes into the fle specidied by name *filename a random adjacency matrix
int createfile( int dimensions, char *filename );
//a function that loads a file an adjacency matrix into the memory
int loadfile( char *filename );
//function that prints the weights of the array
void print_array( void );
//function that finds the minimum weight according to the data given
void *findMin( void *data );
//function that deletes the weights of the node next_element
void delete_elements( int next_element );
//function that does all the necessary initializations
void initialization( void );



#endif

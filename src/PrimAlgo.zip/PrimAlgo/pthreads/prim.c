
#include "functions.h"
#include "global.h"

int main(int argc, char **argv)
{
	int ch,j,t,p_c,p_j;
	long i;

	//declaring the structs the are used by gettimeofday
	struct timeval tb1;
	struct timeval tb2;

	opterr = 0;
	//parsing the arguments given
	while ((ch = getopt (argc, argv, "c:l:t:")) != -1) {
	  
		switch(ch) {
			case 'c':
				createfile(optarg);
				loadfile(optarg);
				break;
			case 'l':
				loadfile(optarg);				
				break;
			case 't':
				num_threads = atoi(optarg);
				break;
			case '?':
				usage(argv[0]);
				exit(0);
			default:
				usage(argv[0]);
				exit(0);
		}
	}
	
	//initializing the data
    initialization();

	//getting  system's local time
	gettimeofday(&tb1,NULL);

	//calculating for all the nodes
	for(i = 1; i < prim.dimension-1; i++) {

		//creating a number of threads depending the NUM_THREADS
		for(t = 0; t < NUM_THREADS; t++ ) {	    

			p_c = pthread_create( &thread[t].thread_id, NULL, findMin, (void *)&thread[t] );	    
			if( p_c ) {

				perror("Error during creating thread.");
				exit(EXIT_FAILURE);

			}

		}
	  
		//waiting for threads to join the main thread..
		for(j = 0; j < NUM_THREADS; j++) {

			p_j =  pthread_join( thread[j].thread_id, NULL );
			if( p_j ) {

				perror("Error during join operation.");
				exit(EXIT_FAILURE);

			}

		}
		
		//Finding the minimun distance and the next node between the threads
		min_distance = thread[0].t_min;
		new_next_element = thread[0].t_next_element;

		for(j = 1; j < NUM_THREADS; j++) {

			if( thread[j].t_min < min_distance ) {

				min_distance = thread[j].t_min;
				new_next_element = thread[j].t_next_element;

			}

		}
		
		//Adding the local min_distance to the total_min_distance
		prim.total_min_distance += min_distance;
		//Adding the next node in the U set
		prim.U[i + 1] = new_next_element;
		//Substructing the elements of the column in which  the new node is assosiated with
		delete_elements( new_next_element );
		//Increasing the nodes that they are in the MST
		prim.count_nodes_in_mst++;

	}
	//get once more the system's local time
	gettimeofday(&tb2,NULL);

	printf("\n");
	//Print all the nodes in MST in the way that they stored in the U set
	for(i = 0 ; i < prim.dimension; i++) {
	  
	    printf("%d ",prim.U[i] + 1);
	    if( i < prim.dimension - 1 ) printf("-> ");
	   
	}
	//Print the total minimun distance
	printf("\n\n");      
	printf("Total minimun distance: %d\n\n", prim.total_min_distance);
	printf("\nProgram terminates now..\n");

	//calculating the difference between the two time measurements
	double real = (double)tb2.tv_sec-(double)tb1.tv_sec + ((double)tb2.tv_usec-(double)tb1.tv_usec)/1000000;


	printf("time: %f \n", real);


	return 0;
}

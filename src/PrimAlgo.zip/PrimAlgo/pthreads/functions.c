#include "functions.h"
#include "global.h"


/******************************************************************************
* This function just prints the usage of the programs parameters.
* (stolen from project 2009 :-D)
*******************************************************************************/
void usage(const char *prog) {
  
	fprintf(stderr, "Usage %s [-c filename | -l filename]\n", prog);
	fprintf(stderr, "\t-c:\t Create a file with name filename containing the adjunctive matrix\n");
	fprintf(stderr, "\t-l:\t Load the adjunctive matrix from file filename to memory\n");
}

/******************************************************************************
* This function creates a new file specified by *filename, in which an adjacency
* matrix is created.For the construction of the array, repetitive calls of rand()
* function are made.At the beginning, the array is created in which every edge
* is connected with every other edge with a random weight and symmetrical indexes
* of the array have the same weight.Next, all weights of diagonal are set to zero
* since there is no path between the same vertice.Then for a random number of edges,
* the weights are set to zero to emulate a real graph in which not every vertice
* is connected to every other vertice.
*******************************************************************************/
int createfile( char *filename) {
  
	int i,j=1;

	int randnum;
	struct tm *ptr;
	time_t lt;
	FILE *fd;


	//randnum=rand()%DIM;
	int randarray[ DIM-1 ];

	//getting system time to seed the rand function
	lt = time( NULL );
	ptr = localtime( &lt );

	//seeding the rand function with new value every new second
	srand( time( NULL ) );


	//creating the adjunctive array where every vertix is connected to any other vertix
	for(i=0; i<DIM; i++) {
	  
		for(j=0; j<DIM; j++) {
		  
			if(i==j) adj_array[i][j]=0;
			else {
			  
			  adj_array[i][j]=rand()%1000;
			  adj_array[j][i]=adj_array[i][j];
			}
		}
	}

	//creating an array that holds DIM -1 random numbers
	int dim = DIM;
	
	for(i = 0; i < DIM - 1; i++)
	{
		randarray[i] = (int)rand()%(dim); 
		dim--;
		//printf("%d   %d\n", randarray[i],dim);
	}

	//deleting random edges from the initial adjunctive array
	dim = DIM;
	
	for(i = 0; i < DIM - 1; i++) {
	  
		for(j=0; j<randarray[i]; j++) {
		  
			int r = i + rand()%dim;
			adj_array[i][r] = 0;
			adj_array[r][i] = 0;
		}
		
		dim--;
	}


	//opening the filename file to write the adjuntive array into the file
	if(( fd = fopen( filename, "w" )) == NULL) {
	  
		perror("Cannot open file.\n");
		exit( EXIT_FAILURE );
	}

	//writing the DIM of the array int the file
	fprintf(fd,"%d\n", DIM);
	//writing the adjunctive array into the file
	for(i = 0; i < DIM; i++) {
	  
		for( j = 0; j < DIM; j++) {
		  
			fprintf(fd,"%d ", adj_array[i][j]);
		}
		fprintf(fd,"\n");		
	}
	
	//closing the file descriptor
	fclose(fd);

	return 0;
}


/******************************************************************************
* This function opens a file specified by *filename, reads the characters of
* the file and stores them on the ARRAY[][].The function presupposes that
* the dimensions of the square table are written at the top of the file.
*******************************************************************************/
int loadfile(char *filename) {
	int i,j;
	FILE *fd;

	printf("Opening the file...\n");
	
	if(( fd = fopen(filename, "r") ) == NULL) {
	
		perror("Cannot open file.\n");
		exit(EXIT_FAILURE);
	}
	
	//store the dimensions in prim.dimension
	fscanf(fd, "%d", &prim.dimension);

	//read the weights of every edge from the file
	for (i = 0; i < prim.dimension; ++i) {
	
		for (j = 0; j < prim.dimension; j++) {
		
			fscanf(fd, "%d", &(prim.edges_weight[i][j]));
		}
	}
	
	fclose(fd);

	return 0;
}

/******************************************************************************
* This function prints the array prim.edges_weight[i][j] which holds all the
* weights of the adjacency matrix.
*******************************************************************************/
void print_array(void) {


	int i,j;


	printf("Printing the weight array...\n\n");
	for(i=0; i<prim.dimension; i++) {
	
		for(j=0; j<prim.dimension; j++) {
		
			printf("%d\t",prim.edges_weight[i][j]);
		}
		printf("\n");
	}
}


/******************************************************************************
* This function is called by pthread_create() and finds the mininum weight in
* each row of the adjacency matrix according to the data given through the pointer
* (of type struct thread_data) *data
*******************************************************************************/
void *findMin(void *data) {

	//casting the argument
	struct thread_data *new_data;
	new_data = ( struct thread_data * )data;
	int i,j;
	new_data->t_min = 1000;

	//for every node in minimum spanning tree
	for(i = 0; i < prim.count_nodes_in_mst; i++) {
		//for every every column of the matrix that is given to the calling thread
		for(j = (new_data->t_part_1); j < ( new_data->t_part_2 ); j++) {
			//find the minimum weight
			if(prim.edges_weight[prim.U[i]][j] > new_data->t_min || prim.edges_weight[prim.U[i]][j]==0) {

				continue;
			}
			else {

				new_data->t_min = prim.edges_weight[prim.U[i]][j];
				new_data->t_next_element = j;

			}
		}    
	}
 
    return ((void *)0);
}


/******************************************************************************
* This function just sets the weight of every cell of the column given(next_element)
* to zero.It is called every time a new node is inserted into the U set.
*******************************************************************************/
void delete_elements(int next_element) {
  
  int k;
    
  for(k = 0; k < prim.dimension; k++) {
     
    prim.edges_weight[k][next_element] = 0;
        
  }
    
}

/******************************************************************************
* This function initializes 
*******************************************************************************/
void initialization(void) {
  

	int i;   

	//decalting a new struct of type thread_data that will set the first node in the MST
	struct thread_data first_thread_arg;
	first_thread_arg.thread_id = 0;
	first_thread_arg.t_part_1 = 0;
	first_thread_arg.t_part_2 = prim.dimension;
	first_thread_arg.t_next_element = 0;
	first_thread_arg.t_min = 0;


	prim.total_min_distance = 0;
	prim.count_nodes_in_mst = 0;

	//initializing the U set
	for(i = 0; i < prim.dimension; i++) prim.U[i] = -1;

	//storing the first node into the U set
	prim.U[0] = 0;
	//deleting the first node
	delete_elements( prim.U[0] );
	//incrementing by one the number of node that are inside the U set
	prim.count_nodes_in_mst++;

	//finding the minimum weight for the first node of U set
	findMin( &first_thread_arg );
	//storing the first minimum wheight into the total distance of MST
	prim.total_min_distance += first_thread_arg.t_min;

	//storring into the U set the index of the next node that will be examined
	prim.U[1] = first_thread_arg.t_next_element;
	delete_elements(prim.U[1]);
	prim.count_nodes_in_mst++;

	//separating the adjacency matrix according to the number of threads that are given
	//each thread will find the minimum weight in the field [thread[i].t_part_1,thread[i].t_part_2]
	for(i = 0; i < NUM_THREADS; i++) {
	  
		thread[i].t_part_1 = ( i*prim.dimension )/NUM_THREADS;
		thread[i].t_part_2 = ( (i + 1)*prim.dimension )/NUM_THREADS;

	}
    
}


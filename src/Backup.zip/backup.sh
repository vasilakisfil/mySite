#!/bin/bash

#sleep commands have been added for more user friendly output

#variable that holds the first argument
ARG=5
#variable that holds the date on format dd_mm_yyyy
namedate=$(date +%d_%m_%Y)
#variable that holds the name of the tar file
TARNAME=Backup_of_$namedate.tar
#variable that holds the location of the Backup folder
BACKUPDIR=/$HOME/Backup

#checking if the number of the arguments is within limits..
if [ $# -ge 2 ]
then
	echo "[backup.sh]Usage: ./backup.sh parameter"
	echo "[backup.sh]parameter: the compression level ot bzip2 file"
	exit
fi

#checking if argument 1 is empty
if [ -z $1 ]
then
	#using the default compression
	ARG=1
else
	#checking if compresion arguments is between 1 and 9..
	if [ $1 -lt 1 ] || [ $1 -gt 9 ]
	then
		echo "[backup.sh]Wrong compression number."
		echo "[backup.sh]Number range 1-9."
		exit
	fi
	#using the level of compression the user asked
	ARG=$1
fi

#checking if the Backup folder exists
if [ -d $BACKUPDIR ]
then
	echo "[backup.sh]$BACKUPDIR exists."
else
	echo "Creating directory $BACKUPDIR"
	mkdir $BACKUPDIR
fi

#checking if program find exists on the system
if [ -x /usr/bin/find ]
then
	echo "[backup.sh]Do you want the hidden files?"
	echo "[backup.sh]press \"y\" for yes or \"n\" for no"
	read var1
	if [ "$var1" == "y" ]
	then 
		#finding files plus hidden files
		find /$HOME/ -type f -daystart -mtime -1 | grep -v Backup_of_$namedate.tar | grep -v $BACKUPDIR/temp.out > $BACKUPDIR/temp.out
	else
		#finding files ecluding hidden files
		find $HOME/ \( ! -regex '.*/\..*' \) -type f -daystart -mtime -1 | grep -v Backup_of_$namedate.tar | grep -v $BACKUPDIR/temp.out > $BACKUPDIR/temp.out
	fi

else
	echo "[backup.sh]Program find was not found"
fi

echo "[backup.sh]Your list is on $BACKUPDIR/temp.out"

sleep 4

#checking if the program tar exists on the system
if [ -x /bin/tar ]
then
	#taring the file
	tar -cvf  $BACKUPDIR/$TARNAME -T $BACKUPDIR/temp.out
else
	echo "[backup.sh]Program tar was not found"
fi

sleep 2

#checking if previous bz2 backup file exists (if it exists the script deletes it)
if [ -a $BACKUPDIR/$TARNAME.bz2 ]
then
	echo "[backup.sh]Deleting existing backup file of date $namedate"
	rm $BACKUPDIR/$TARNAME.bz2
else
	echo "[backup.sh]No previous backup file of date $namedate found!"
fi

#checking if bzip2 program exists on the system
if [ -x /bin/bzip2 ] || [ -x /usr/bin/bzip2 ]
then
	#compressing the tar file with the bzip2 program
	echo "[backup.sh]bzip2 exists on your system...compressing with bzip2...."
	bzip2 -$ARG $BACKUPDIR/$TARNAME
else
	#no bzip2 program found, coninuing with the tar file
	echo "[backup.sh]Program bzip2 was not found..continuing with tar file..."
fi

#some information for the user about the files
if [ -x /bin/bzip2 ] || [ -x /usr/bin/bzip2 ]
then
	echo "[backup.sh]Your backup file is a bzip compressed file loacetd at $BACKUPDIR/$TARNAME.bz2"
else
	echo "[backup.sh]Your backup file is a tar archived file loacetd at $BACKUPDIR/$TARNAME"
fi

#deleting the helping file temp.out
rm $BACKUPDIR/temp.out

echo "File $BACKUPDIR/temp.out just deleted"

#informing the user that the script has just finished it's work
echo "[backup.sh] backup.sh script finished the backup"



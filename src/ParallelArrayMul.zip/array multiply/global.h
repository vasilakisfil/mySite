/***************************************************************************************************************
*					Global declarations
*
****************************************************************************************************************/

#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <omp.h>



//defining the rows of the array
#define G 50000
//defining the columns of the array
#define S 100
//defining the limit of rand() function
#define BOUND 10



//defining the arrays as global
double array1[G][S],array2[S][S],array[G][S];

struct array_info{
	int row;
	int column;
};

pthread_mutex_t mymutex;



#endif

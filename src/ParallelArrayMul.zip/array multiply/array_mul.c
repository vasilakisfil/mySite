/*************************************************************************************
*		Programma pou pollaplasiazei 2 pinakes parallhla...
*
*************************************************************************************/


#include "global.h"
#include "functions.h"

int main(void)
{

	fflush(NULL);

	int i,j;

	pthread_mutex_init(&mymutex,NULL);

	//initializing....
	initialization();
	//multiplying
	array_sum();



	//printing the array
	print_results();

	printf("calculation was made........\n");

	pthread_mutex_destroy(&mymutex);




	//pthread_exit((void *) 0);

	fflush(stdout);
	//sleep(2);
		
	return 0;


}











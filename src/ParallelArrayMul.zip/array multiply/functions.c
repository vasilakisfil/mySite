/***************************************************************************************************************
*				File that contains all the necessary functions
*					for the linear multiplication
***************************************************************************************************************/

#include "global.h"
#include "functions.h"




//function that initializes the arrays
int initialization(void)
{
	int i,j;

	//creating a seed for the rand() function
	srand(2.873462);

	//itializing
	for(i=0; i<G; i++)
	{
		for(j=0; j<S; j++)
		{
			array1[i][j]=(double)(rand()%BOUND +1)/(rand()%BOUND+1);
			array[i][j]=0;
			//initializing thread ids..
			tid[i][j]=0;
		}
	}

	//changing seed for rand function
	srand(5.234234);
	//initializing
	for(i=0; i<S; i++)
	{
		for(j=0; j<S; j++)
		{
			array2[i][j]=(double)(rand()%BOUND+1)/(rand()%BOUND+1);
		}
	}


	return 0;

}

//function that multiplies the arrays
int array_sum(void)
{

	int i,j,k,choice,err, id;
	int join_i=0,join_j=0,join_k=0;
	char temp[100];
	int flag;

	double sum=0;
	//pthread_t pid;

	struct array_info inf_array;

	inf_array.row=0;
	inf_array.column=0;

	printf("How do you want to make the multiplication ?\n1.By single thread\n2.By multiple threads\n3.Using OpenMP\n");
	
	choice=atoi(fgets(temp,sizeof temp,stdin));
	

	if(choice==1)
	{
		for(i=0; i<G; i++)
		{
		
			for(j=0; j<S; j++)
			{
				//sum=0 for the linear multiply of every row and column
				sum=0;
				for(k=0; k<S; k++)
				{
					sum+=(array1[i][k]*array2[k][j]);
				}
				array[i][j]=sum;
			}
		}
	}
	//multiplication with threads
	else if(choice==2)
	{
		for(i=0; i<G; i++)
		{
		
			for(j=0; j<S; j++)
			{
				inf_array.row=i;
				inf_array.column=j;
				//printf("2  %d  %d\n", i, j);
				//if((i==(G-1))&&j==(S-1)) break;
				if(pthread_create(&tid[i][j],NULL,thr_fn, (void *) &inf_array)!=0)
				{
					//printf("1\n");
					//printf("ERROR; return code from pthread_create is %d\n", err);
					//exit(-1);
					flag=1;
					do{
				
							if((join_i==i)&&(join_j==j))
							{
								//join_i++;
								join_j++;
								if(join_j==S)
								{
									join_i++;
									join_j=0;
								}
								fflush(NULL);
								//printf("Not joining thread...........\n\n\n\n\n");



								break;
							}
							//printf("joining thread..%d %d  %d %d\n", i, j,join_i,join_j);
							pthread_join(tid[join_i][join_j],NULL);
							join_j++;
							if(join_j==S)
							{
								join_i++;
								join_j=0;
							}
						
					}while(flag==1);
				}
				//pthread_join(tid[i][j],NULL);
			}
		}

		/*for(i=0; i<G; i++)
		{
			for(j=0; j<S; j++)
			{
				err=pthread_join(tid[i][j],NULL);
				if(err!=0)
				{
					printf("ERROR; return code from pthread_create is %d\n", err);
					exit(-1);
				}
			}
		}*/
	}
	//multiplication using OpenMP
	else if(choice==3)
	{

		omp_set_num_threads(2);		
		#pragma omp parallel for private(i,j,k,sum) default(shared)
		for(i=0; i<G; i++)
		{
			//printf("Hello World, %d %d %d\n", i, omp_get_num_threads(), omp_get_thread_num());
			//printf("%d\n", omp_in_parallel());
			for(j=0; j<S; j++)
			{
				//sum=0 for the linear multiply of every row and column
				sum=0;
				for(k=0; k<S; k++)
				{
					sum+=(array1[i][k]*array2[k][j]);

				}
				array[i][j]=sum;
			}
		}

	}
	else
	{
		printf("Wrong choice!\n");
	}

	return 0;


}

void *thr_fn(void *arg)
{
	pthread_mutex_lock(&mymutex);
	int new_r,new_c,k;
	double sum;
	struct array_info *thread_arr_inf;

	thread_arr_inf= (struct array_info *) arg;

	new_r = thread_arr_inf->row;
	new_c = thread_arr_inf->column;

	
	//sum=0 for the linear multiply of every row and column
	sum=0;
	for(k=0; k<S; k++)
	{
		//pthread_mutex_lock(&mymutex);	
		sum+=(array1[new_r][k]*array2[k][new_c]);
		//pthread_mutex_unlock(&mymutex);
	}
	//pthread_mutex_lock(&mymutex);
	array[new_r][new_c]=sum;
	//pthread_mutex_unlock(&mymutex);

	//printf("Hello World %d %d -->%d\n", new_r, new_c,sum);
	pthread_mutex_unlock(&mymutex);

	return ((void*)0);
}


int print_results(void)
{
	int i,j;

	//printing the arrays........
	for(i=0; i<G; i++)
	{
		for(j=0; j<S; j++)
		{
			printf("%f\t", array[i][j]);
		}
		printf("\n");
	}

	return 0;

}

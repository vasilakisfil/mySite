/**********************************************************************************************
*				fuctions protypes
*
**********************************************************************************************/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H


//function that makes all the necessary initializations
int initialization(void);
//function that does the linear multiplication
int array_sum(void);

void *thr_fn(void *arg);

pthread_t tid[G][S];

int print_results(void);


#endif

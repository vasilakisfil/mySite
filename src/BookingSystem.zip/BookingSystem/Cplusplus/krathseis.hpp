#ifndef SYN_H
#define SYN_H

#include <iostream>
#include <fstream>

using namespace std;

using namespace std;
enum BOOL {FALSE, TRUE};
enum CHOICE {Krathsh=1, Akurwsh, Emfanish, Apo8hkeush, Voh8eia, E3odos};
enum MESO {Train=1, Ship, Plane, Back}; //epile3te meso metaforas
enum KATHGORIA {Alfa=1, Beta=2, Gamma=3}; //epile3te 8esh
enum TRENO {PatraA8hna=1, PatraPurgos, A8hna8essalonikh, A8hnaLianokladi, A8hnaLarisa};//proorismoi| allo a8hna8essalonikh [treno] kai allo a8hnaThessalonikh [aeroplano]
enum PLOIO {PatraAnkona=1, PatraVenetia, PatraPrintezi};
enum AEROPLANO {A8hnaThessalonikh=1, A8hnaMilano, A8hnaFrankfourth, A8hnaNYorkh};
enum AKURWSH {PatraA8hnaAK=1, PatraPurgosAK, A8hna8essalonikhAK, A8hnaLianokladiAK, A8hnaLarisaAK, PatraAnkonaAK, PatraVenetiaAK, PatraPrinteziAK,A8hnaThessalonikhAK, A8hnaMilanoAK, A8hnaFrankfourthAK, A8hnaNYorkhAK, PiswAK};

int Menu();
int MenuMesou();
int MenuTreno();
int MenuPloio();
int MenuAeroplano();
int MenuKathgorias1();
int MenuKathgorias2();
int MenuAkurwshs(); 


//class Treno;
//class Ploio;
//class Aeroplano;


class Meso{
	public:
	Meso();
	Meso(string mesoname);
	int GetTicket(int t);
	void SimpleReservation(int t);
	int SimpleCancelation(int t);
	virtual void Print(int a, int b);
	virtual void Print2fileAdv();
	void Print2file(int a, int b);
	bool Yparxei(int t);
	int Backup(int t);
	int Enqueue(int t);
	int CheckQueue(int t);
	void Dequeue(int t);
	//void AdvReservation();
	//void AdvCancelation();	

	protected:
	string mesoname_;
	int ticket1init_, ticket1realtime_, ticket2init_, ticket2realtime_;
	queue <string> q1_,q2_;
};


class Treno : public Meso {
	public:
	Treno(string mesoname);
	void AdvReservation(); //edw to i paizei to rolo tou check if full
	void AdvCancelation();	
	void PrintAdv();
	void Print2fileAdv();
};

class Ploio : public Meso {
	public:
	Ploio(string mesoname);
	void AdvReservation(); //edw to i paizei to rolo tou check if full
	void AdvCancelation();	
	void PrintAdv();
	void Print2fileAdv();
};

class Aeroplano : public Meso {
	public:
	Aeroplano(string mesoname);
	void AdvReservation(); //edw to i paizei to rolo tou check if full
	void AdvCancelation();	
	void PrintAdv();
	void Print2fileAdv();
};


int Menu(){ //Main menu!
	int choice;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) Krathsh\n";
	cout << "(2) Akurwsh\n";
	cout << "(3) Emfanish\n";
	cout << "(4) Apo8hkeush\n";
	cout << "(5) Voh8eia\n";
	cout << "(6) E3odos\n";
	cin >> choice;
	return choice;
}

int MenuMesou(){ //Epilogh Mesou
	int meso;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) Treno\n";
	cout << "(2) Ploio\n";
	cout << "(3) Aeroplano\n";
	cout << "(4) Pisw\n";
	cin >> meso;
	return meso;
}

int MenuTreno(){ //Diadromes me Treno
	int treno;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) A8hna - Patra\n";
	cout << "(2) A8hna - 8essalonikh\n";
	cout << "(3) Patra - Purgos\n";
	cout << "(4) A8hna - Lianokladi\n";
	cout << "(5) A8hna - Larisa\n";
	cout << "(6) Epistrofh sto arxiko menu\n";
	cin >> treno;
	return treno;
}
int MenuPloio(){ //Diadromes me Ploio
	int ploio;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) Patra - Ankona\n";
	cout << "(2) Patra - Venetia\n";
	cout << "(3) Patra - Printezi\n";
	cout << "(4) Epistrofh sto arxiko menu\n";
	cin >> ploio;
	return ploio;
}

int MenuAeroplano(){ //Diadromes me Aeroplano
	int aeroplano;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) A8hna - 8essalonikh\n";
	cout << "(2) A8hna - Milano\n";
	cout << "(3) A8hna - Frankfurth\n";
	cout << "(4) A8hna - N.Yorkh\n";
	cout << "(5) Epistrofh sto arxiko menu\n";
	cin >> aeroplano;
	return aeroplano;
}

int MenuKathgorias1(){ //Epilogh kathgoras 8eshs menu1
	int kathgoria;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) 8esh A\n";
	cout << "(2) 8esh B\n";
	cout << "(3) [8esh C] - not availiable\n";
	cout << "(4) Epistrofh sto arxiko menu\n";
	cin >> kathgoria;
	return kathgoria;
}

int MenuKathgorias2(){ //Epilogh kathgorias 8eshs menu2
	int kathgoria;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) [8esh A] - not availiable\n";
	cout << "(2) 8esh B\n";
	cout << "(3) 8esh C\n";
	cout << "(4) Epistrofh sto arxiko menu\n";
	cin >> kathgoria;
	return kathgoria;
}

int MenuAkurwshs(){
	int Akurwsh;
	cout << "\n\n-================|Menu|===============-\n";
	cout << "(1) PatraA8hnaAK=1 \t(5) PatraPurgosAK\t(9) A8hna8essalonikhAK\n"; 
	cout << "(2) A8hnaLianokladiAK \t(6) A8hnaLarisaAK\t(10) PatraAnkonaAK\n";  
	cout << "(3) PatraVenetiaAK \t(7) PatraPrinteziAK\t(11) A8hnaThessalonikhAK\n"; 
	cout << "(4) A8hnaMilanoAK \t(8) A8hnaFrankfourthAK\t(12) A8hnaNYorkhAK\n";
	cout << "\t\t\t\t\t\t(13) Pisw\n"; 
	cin >> Akurwsh;
	return Akurwsh;

}

#endif

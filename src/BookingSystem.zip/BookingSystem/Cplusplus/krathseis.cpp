//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888//
// To programma auto ulopopoiei tis krathseis 8esewn enos upo8etikoy ta3idiwtikou grafeiou. Sugekrimena exei ulopoih8ei  //
// klash Meso, h opoia diathrei 2 metavlhtes-counters gia ta eishthria kai 2 queues me thn xrhsh ths <queue> library. E- //
// pisis exoun ulopoih8ei treis klaseis  pou klhronomoun thn meso h "Ploio", "Aeroplano" kai "Treno". Oi sunarthseis     //
// prosvashs ths klashs Meso ulopoioun aples leitourgies (opws simple reservation, enqueue, backup, yparxei, print klp)  //
// prosvashs kai anakthshs ths plhroforias pou uparxei sthn klash Meso, tis opoies oi sunarthseis prosvashs xrhsimopoi-  //
// oun, e3eidikeuoun kai emploutizoun gia thn dhmiourgia ths diepafhs me ton xrhsth. Sthn main dhmiourgounte ta katallh- //
// la antikeimena ta opoia purodotoun gegonota analoga me tis protimhseis tou xrhsth. Telos uparxei ena sunolo sunarth-  //
// sewn to opoio ulopoiei ta antistoixa menu plohghshs gia ton xrhsth. Oi sunarthseis autes -sto krathseis.hpp" den pa-  //
// rousiazoun kapoio idiaitero endiaferon oson afora tis prodiagrafes tou project oute kapoia idiaiterh duskolia. Den    //
// 8hke varuthta ekei kata thn ulopoihsh, alla stis klaseis kai tis sunarthseis prosvashs sta plaisia tou ma8hmatos a-   //
// keimenostrafous programmatismou. [Perissoteres leptomereies sthn anafora kai sta sxolia tou kwdika]                   //
//                                                                                                                       //
// | syggrafh kwdika Nikos kai Filippos Vassilakis |                                                                     //
// | contact: basilakn@ceid.upatras.gr, vasilakis@ceid.upatras.gr |                                                      //
//                                                                                                                       //
// | v3.141592653: Sygrafh anaforas.                                                                                    //
// | v3.14159265: Oloklhrwsh sxoliwn.                                                                                    //
// | v3.1415926: Dhmiourgia header file - metafora kai twn sunarthsewn menu ekei.                                        //
// | v3.141592: Dhmiourgia merikwn voh8htikwn sunarthsewn                                                                //
// | v3.14159: Grapsimo se arxeio mesw sunarthsewn prosvashs - polumorfismos                                             //
// | v3.1415: Plhrws antikeimenostrafhs proseggish. Anapty3h uperklashs, private metablhtwn kai sunarthsewn prosvashs.   //
// | v3.141: Ylopoihsh mhnymatwn eisodou e3odou gia ton xrhsth                                                           //
// | v3.14: Dhmiourgia sunarthsewn gia ton diamoirasmo ths rohs programmatos [non-object oriented]                       //
// | v3.1: klaseis ploio,aeroplano,treno me public metavlhtes                                                            //
// | V3: menu plohghshs                                                                                                  //
//                                                                                        //teleftaia allagh: 10 Feb 2008//
//|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||//
// To arxeio auto apotelei anapospasto komati ths ulopoihshs kai lushs tou project C++ tou ma8hmatos "Ontokentrikos pro- //
//  rammatismos II" gia to 2007-08.                                                                                      //
//88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888//
#include <iostream>
#include <fstream>
#include <queue>
#include "krathseis.hpp"

using namespace std;

/**************************************************************************************************************************
* class: "Meso". Perilamvanei genikes idiothtes kai sunarthseis pou 8a klhronomh8oun apo tis subclasses                   *
* Orizontai oi sunarthseis prosvashs kai oi protected metavlhtes gia ta eishthria -sumperilamvanomenwn kai ton Queues.    *
***************************************************************************************************************************/

Meso::Meso(){
	mesoname_="Tester//Initializer";
	ticket1init_=0;
	ticket2init_=0;
	ticket1realtime_=0;
	ticket2realtime_=0;
}


Meso::Meso(string mesoname){
	mesoname_=mesoname;
	ticket1init_=0;
	ticket2init_=0;
	ticket1realtime_=0;
	ticket2realtime_=0;
}

int Meso::GetTicket(int t){
	if (t==1){
		return ticket1realtime_;
	}else if (t==2){
		return ticket2realtime_;
	}else{
		cout << "Wrong ticket value" << endl;	
		return -1;
	}
}

void Meso::SimpleReservation(int t){
	if (t==1){
		ticket1realtime_--;
	}else if (t==2){
		ticket2realtime_--;
	}
}

int Meso::SimpleCancelation(int t){
	if (t==1){
		if (ticket1realtime_<ticket1init_){ //An einai mikrotero apo ta eishthria pou exoume then ok, akurwse, alliws den exoun krath8ei eishthria gia akurwsh kai exei kanei la8os o xrhsths!
			ticket1realtime_++;
			return 1;
		}else{
			cout << "Den uparxei eishthrio na akurwsete!" << endl;
			return 0;
		}
	}else if (t==2){
		if (ticket2realtime_<ticket2init_){
			ticket2realtime_++;
			return 1;
		}else{
			cout << "Den uparxei eishthrio na akurwsete!" << endl;
			return 0;
		}
	}
}
void Meso::Print2fileAdv(){
	ofstream krathseis;
	krathseis.open ("krathseis.dat");
	krathseis << "[Apo8hkeush ths sunolikhs katastashs twn dromologiwn]\n\n";
	krathseis.close();
}

void Meso::Print(int a, int b){
	//cout << mesoname_ <<": Ticket1:  " << ticket1realtime_ << " | Ticket2:  " <<ticket2realtime_ << endl; 
	cout << " ROUTE: " << mesoname_ << "\n";
	cout << " TOTAL SEATS:    "<< a+b <<"\n";
	cout << " RESERVED SEATS: "<< a+b-(ticket1realtime_+ticket2realtime_)<<"\n";
	cout << " AVAILABLE SEATS:"<< ticket1realtime_+ticket2realtime_ <<"\n";
	cout << " ---------------------- RESERVED -------------------------\n";
	cout << "               A CLASS            B CLASS\n";
	cout << "                  " << a-ticket1realtime_<< "                  " << b-ticket2realtime_<< "\n";
	cout << " ---------------------- AVAILABLE ------------------------\n";
	cout << "               A CLASS            B CLASS\n";
	cout << "                  " << ticket1realtime_ << "                  " << ticket2realtime_ << "\n";
	cout << " =========================================================\n\n";
}

void Meso::Print2file(int a, int b){
	ofstream myfile;//(krathseis.txt, ios::app);
	myfile.open ("krathseis.dat",ios::app);
	myfile << " ROUTE:" << mesoname_ << "\n";
	myfile << " TOTAL SEATS:    "<< a+b <<"\n";
	myfile << " RESERVED SEATS: "<< a+b-(ticket1realtime_+ticket2realtime_)<<"\n";
	myfile << " AVAILABLE SEATS:"<< ticket1realtime_+ticket2realtime_ <<"\n";
	myfile << " ---------------------- RESERVED -------------------------\n";
	myfile << "               A CLASS            B CLASS\n";
	myfile << "                  " << a-ticket1realtime_<< "                  " << b-ticket2realtime_ << "\n";
	myfile << " ---------------------- AVAILABLE ------------------------\n";
	myfile << "               A CLASS            B CLASS\n";
	myfile << "                  " << ticket1realtime_ << "                  " << ticket2realtime_ << "\n\n";
	myfile.close();
}

bool Meso::Yparxei(int t){
	if (t==1){
		if (ticket1realtime_==0){
			return false;
		}else{
			return true;
		}
	} else if (t==2){
		if (ticket2realtime_==0){
			return false;
		}else{
			return true;
		}
	} else {
		cout << " error: wrong Yparxei() argument!" << endl;
	}	
}

int Meso::Backup(int t) {
	int epilogh;
	cout << "Dystyxws den uparxoun eleu8eres 8eseis sthn thn kathgoria pthn opoia epi8umeite gia thn diadromh" << mesoname_ << endl;
	cout << "Yparxoun omws eleu8eres 8eseis se allh 8esh. 8a 8elate na kanete thn diadromh " << mesoname_ << " sthn allh 8esh? \n (1) nai \n (2) oxi" << endl;
	cout << "\nSe periptwsh pou epile3ete \"(2) oxi \" 8a krathsoume ta stoixeia sas kai 8a mpeite se lista anamonhs [new!] gia thn 8esh thn opoia arxika zhthsate." << endl;
	cin >> epilogh;
	if (epilogh==1){
		SimpleReservation(t);
		cout << "Egine krathsh gia to dromologio: " << mesoname_ << " me epituxia! \n\nKalo sas ta3idi!\n" << endl;
		return 1; 			//epituxes backup proceedure
	}else if (epilogh==2){
		return 0;			//aneputyxes backup proceedure logw dusareskeias tou xrhsth::xrhsimeuei wste na energopoih8ei to enqueue!
	}else{
		cout << "AUTO DEN EINAI ELLHNIKA DUUUDE!" << endl;
	}

}

int Meso::Enqueue(int t){
	string info;
	int epikurwsh;
	
	while (1) {
		cout << "Parakalw dwste mas ta sxoixeia sas sth morfh: < Epwnymo_Onoma_Thlefwno > gia nampeite se lista anamonhs gia to dromologio: " << mesoname_ << " kai th 8esh pou arxika zhthsate. (shm.: Mhn eisagete ta <>)." << endl;
		cout << "<" << endl;
		cin >> info ;
		cout << ">" << endl;
		cout << "Ta stoixeia pou eisagate einai ta e3hs: <" << info << ">" << endl;
		cout << "Sumfwneite me auta ta stoixeia? \n(1) epikurwsh  \n(2) epidior8wsh (otidhpote allo apo 1 8a ekluf8ei ws epilogh epidior8wshs)" << endl;
		cin >> epikurwsh;
		if (epikurwsh==1){
			if (t==1){
				q1_.push(info);
			}else if (t==2){
				q2_.push(info);
			}
			break;
		}
	}

	cout << "Euxaristoume. Exoume krathsei ta stoixeia sas kai 8a epikoinwnhsoume mazi sas to suntomotero dunaton!\n" << endl;
	
	return 0;
}

int Meso::CheckQueue(int t){ //An einai empty epistrefei 0
	
	if ((t==1) && (!q1_.empty())){
		//tsekare an exei kati mesa h Q1 ths klasshs Meso (An dhladh uparxei kapoios pou exei kanei krathsh gia thn 1h kathgoria 8eshs) KAI AN YPARXEI epistrepse 1
		//cout << "We neeeed a Queue!" << endl;
		return 1;
	}else if ((t==2) && (!q2_.empty())){
		//tsekare an exei kati mesa h Q2 ths klasshs Meso (An dhladh uparxei kapoios pou exei kanei krathsh gia thn 1h kathgoria 8eshs) KAI AN YPARXEI epistrepse 1
		//cout << "We neeeed a Queue!" << endl;
		return 1;
	}else{
		return 0;
	}
}
void Meso::Dequeue(int t){
	int epilogh;

	if (t==1){
		//cout << "Vale Dequeue 1" << endl;
		while (!q1_.empty()){ //8a prospa8w na kanw deque mexri kapoios na dex8ei	
			cout << "Stoixeia katoxou epomenhs krathshs: "  << q1_.front() << "\nEpi8umei o pelaths telika krathsh auths ths 8eshs gia thn diadromh " << mesoname_ << "?\n(1) nai \n(2) oxi \n[an oxi 8a metavoume ston pelath me thn akrivws epomenh seira proteraiothtas sthn lista anamonhs]" << endl;
			cin >> epilogh;
			if (epilogh==1){
				q1_.pop();
				this->SimpleReservation(1);
				break;
			}else if (epilogh==2){
				q1_.pop();
			}else{
				cout << "La8os epilogh";
			}
		}
	}else if (t==2){
		//cout << "Vale Dequeue 2" << endl;
		while (!q2_.empty()){ //8a prospa8w na kanw deque mexri kapoios na dex8ei	
			cout << "Stoixeia katoxou epomenhs krathshs: "  << q2_.front() << "\nEpi8umei o pelaths telika krathsh auths ths 8eshs gia thn diadromh " << mesoname_ << "?\n (1) nai \n(2) oxi \n[an oxi 8a metavoume ston pelath me thn akrivws epomenh seira proteraiothtas sthn lista anamonhs]" << endl;
			cin >> epilogh;
			if (epilogh==1){
				q2_.pop();
				this->SimpleReservation(2);
				break;
			}else if (epilogh==2){
				q2_.pop();
			}else{
				cout << "La8os epilogh";
			}
		}
	}else{
		cout << "dbg msg: Error on Dequeue" << endl;
	}

}

/**************************************************************************************************************************
* subclasses: "Treno".                                                                                                    *
* Klhronomei apo to class: "Meso".                                                                                        *
***************************************************************************************************************************/


Treno::Treno(string mesoname):Meso(mesoname){ 	//to meso den 8elei (int mesoname);
	mesoname_=mesoname;
	ticket1realtime_=6;
	ticket2realtime_=12;
	ticket1init_=6;
	ticket2init_=12;
}

void Treno::PrintAdv(){
	cout << " ======================== TRAIN ==========================" << endl ;
	Meso::Print(6,12);
}

void Treno::Print2fileAdv(){
	ofstream myfile;//(krathseis.txt, ios::app);
	myfile.open ("krathseis.dat",ios::app);
	myfile << " ________________________________________________________\n";
	myfile << " WAY OF TRANSPORTATION: TRAIN.\n";
	myfile.close();
	Meso:Print2file(6,12);
}

//////////////////Krathsh
void Treno::AdvReservation(){
	int t;	
	t = MenuKathgorias1();
	//Meso::SimpleReservation
	if (t==1){					//epilegei 8esh A
		//cout << "ok1"<< endl;			//dbg msg
		if (this->Yparxei(1)){			//an uparxei eleu8erh 8esh A
			//cout << "ok2"<< endl;		//dbg msg
			cout << "\n Ta3ideuontas " << mesoname_ <<" me treno sthn 1h 8esh!\n" << endl;
			Meso::SimpleReservation(1);	//Ektupwnw sthn o8onh to ti 8a ginei kai kanw krathsh mia 8esh A 
		}else{ 					//alliws
			//cout << "ok3"<< endl;		//dbg msg
			if (this->Yparxei(2)){		//An uparxei 2h 8esh [B se emas logw trenou]
				if (!(this->Backup(2))){//Energopoihsh leitourgias backup choise(2)? wste na rwthsw an epi8umoun krathsh me diaforetikh 8esh (2) [kanw en8esh sthn queue mou]
					this->Enqueue(1);//An den htan epituxes to backup proceedure 8a ton valoume se queue!
				}				
			}else {				//An den uparxei, ton vazw sthn lista amonhs GIA THN 8ESH thn opoia zhthse arxika
				cout << "Dystyxws den uparxei kamia 8esh oute sthn kathgoria 2 alliws 8a sas proteiname na ta3idepsete me 8esh sthn kathgoria 1! 8a sas valoume sthn lista anamonhs [new!]" << endl;
				this->Enqueue(1);	//Lista anamonhs
			}
		}
	}else if (t==2){				//Antistoixws an zhthse 8esh B
		//cout << "ok1"<< endl;
		if (this->Yparxei(2)){
			//cout << "ok2"<< endl;
			cout << "\n Ta3ideuontas " << mesoname_ <<" me treno sthn 2h 8esh!\n" << endl;
			Meso::SimpleReservation(2);
		}else{ 
			//cout << "ok3"<< endl;
			if (this->Yparxei(1)){
				if (!(this->Backup(1))){//Energopoihsh leitourgias backup choise(2)? wste na rwthsw an epi8umoun krathsh me diaforetikh 8esh (2) [kanw en8esh sthn queue mou]
					this->Enqueue(2);//An den htan epituxes to backup proceedure 8a ton valoume se queue!
				}			
			}else {
				cout << "Dystyxws den uparxei kamia 8esh oute sthn kathgoria 1 alliws 8a sas proteiname na ta3idepsete me 8esh sthn kathgoria 1! 8a sas valoume sthn lista anamonhs [new!]" << endl;
				this->Enqueue(2);
			}
		}
	}else{
		cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
	}
}

//////////////////Akurwsh
void Treno::AdvCancelation(){
	int t;	
	t = MenuKathgorias1();
	if (t==1){
		if (this->SimpleCancelation(1)){   //den uparxei Q an den uparxei kan hdh eishthrio!
			if (this->CheckQueue(1)){  //Episis kanw prwta akurwsh 8eshs kai ustera apo to Deque 3anakanw krathsh kai auto dioti den mporei na anevei panw apo sugekrimeno ar8mo krathsewn [dld na katevei h metablhth ticket1realtime_ katw apo to 0!]
				this->Dequeue(1);
			}
		}
	}else if (t==2){				//Antistoixws an zhthse 8esh B
		if (this->SimpleCancelation(2)){
			if (this->CheckQueue(2)){
				this->Dequeue(2);
			}
		}
	}else{
		cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
	}
}

/**************************************************************************************************************************
* subclasses: "Ploio".                                                                                                    *
* Klhronomei apo to class: "Meso".                                                                                        *
***************************************************************************************************************************/


Ploio::Ploio(string mesoname):Meso(mesoname){ 	//to meso den 8elei (int mesoname);
	mesoname_=mesoname;
	ticket1realtime_=1;
	ticket2realtime_=1;
	ticket1init_=10;
	ticket2init_=24;
}

void Ploio::PrintAdv(){
	cout << " ======================== SHIP ===========================\n";
	Meso::Print(10,24);
}

void Ploio::Print2fileAdv(){
	ofstream myfile;//(krathseis.txt, ios::app);
	myfile.open ("krathseis.dat",ios::app);
	myfile << " ________________________________________________________\n";
	myfile << " WAY OF TRANSPORTATION: SHIP.\n";
	myfile.close();
	Meso:Print2file(10,24);
}

//////////////////Krathsh                                    Exoun prob ta backup kai enqueue
void Ploio::AdvReservation(){
	int t;	
	t = MenuKathgorias2();
	//Meso::SimpleReservation
	if (t==2){					//epilegei 8esh B
		//cout << "ok1"<< endl;			//dbg msg
		if (this->Yparxei(1)){			//an uparxei eleu8erh 8esh B
			//cout << "ok2"<< endl;		//dbg msg
			cout << "\n Ta3ideuontas " << mesoname_ <<" me ploio sthn 2h 8esh!\n" << endl;
			Meso::SimpleReservation(1);	//Ektupwnw sthn o8onh to ti 8a ginei kai kanw krathsh mia 8esh A 
		}else{ 					//alliws
			//cout << "ok3"<< endl;		//dbg msg
			if (this->Yparxei(2)){		//An uparxei 3h 8esh [C se emas logw ploiou]
				if (!(this->Backup(2))){//Energopoihsh leitourgias backup choise(2)? wste na rwthsw an epi8umoun krathsh me diaforetikh 8esh (2) [kanw en8esh sthn queue mou]
					this->Enqueue(1);//An den htan epituxes to backup proceedure 8a ton valoume se queue!
				}				
			}else {				//An den uparxei, ton vazw sthn lista amonhs GIA THN 8ESH thn opoia zhthse arxika
				cout << "Dystyxws den uparxei kamia 8esh se kamia apo tis upoloipes kathgories [alliws 8a proteiname enallaktikh]! 8a sas valoume sthn lista anamonhs [new!]" << endl;
				this->Enqueue(1);	//Lista anamonhs
			}
		}
	}else if (t==3){				//Antistoixws an zhthse 8esh C
		//cout << "ok1"<< endl;
		if (this->Yparxei(2)){
			//cout << "ok2"<< endl;
			cout << "\n Ta3ideuontas " << mesoname_ <<" me ploio sthn 3h 8esh!\n" << endl;
			Meso::SimpleReservation(2);
		}else{ 
			//cout << "ok3"<< endl;
			if (this->Yparxei(1)){
				if (!(this->Backup(1))){//Energopoihsh leitourgias backup choise(2)? wste na rwthsw an epi8umoun krathsh me diaforetikh 8esh (2) [kanw en8esh sthn queue mou]
					this->Enqueue(2);//An den htan epituxes to backup proceedure 8a ton valoume se queue!
				}			
			}else {
				cout << "Dystyxws den uparxei kamia 8esh se kamia apo tis upoloipes kathgories [alliws 8a proteiname enallaktikh]! 8a sas valoume sthn lista anamonhs [new!]" << endl;
				this->Enqueue(2);
			}
		}
	}else{
		cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
	}
}

//////////////////Akurwsh                    Na alla3w merika cout sthn deque
void Ploio::AdvCancelation(){
	int t;	
	t = MenuKathgorias2();
	if (t==2){
		if (this->SimpleCancelation(1)){   	//den uparxei Q an den uparxei kan hdh eishthrio!
			if (this->CheckQueue(1)){  	//Episis kanw prwta akurwsh 8eshs kai ustera apo to Deque 3anakanw krathsh kai auto dioti den mporei na anevei panw apo sugekrimeno ar8mo krathsewn [dld na katevei h metablhth ticket1realtime_ katw apo to 0!]
				this->Dequeue(1);
			}
		}
	}else if (t==3){				//Antistoixws an zhthse 8esh B
		if (this->SimpleCancelation(2)){
			if (this->CheckQueue(2)){
				this->Dequeue(2);
			}
		}
	}else{
		cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
	}
}

/**************************************************************************************************************************
* subclasses: "Aeroplano".                                                                                                    *
* Klhronomei apo to class: "Meso".                                                                                        *
***************************************************************************************************************************/


Aeroplano::Aeroplano(string mesoname):Meso(mesoname){ 	//to meso den 8elei (int mesoname);
	mesoname_=mesoname;
	ticket1realtime_=4;
	ticket2realtime_=16;
	ticket1init_=4;
	ticket2init_=16;
}

void Aeroplano::PrintAdv(){
	cout << " ======================== PLANE ==========================\n";
	Meso::Print(4,16);
}

void Aeroplano::Print2fileAdv(){
	ofstream myfile;//(krathseis.txt, ios::app);
	myfile.open ("krathseis.dat",ios::app);
	myfile << " ________________________________________________________\n";
	myfile << " WAY OF TRANSPORTATION: PLANE.\n";
	myfile.close();
	Meso:Print2file(4,16);
}

//////////////////Krathsh
void Aeroplano::AdvReservation(){
	int t;	
	t = MenuKathgorias1();
	//Meso::SimpleReservation
	if (t==1){					//epilegei 8esh A
		//cout << "ok1"<< endl;			//dbg msg
		if (this->Yparxei(1)){			//an uparxei eleu8erh 8esh A
			//cout << "ok2"<< endl;		//dbg msg
			cout << "\n Ta3ideuontas " << mesoname_ <<" me aeroplano sthn 1h 8esh!\n" << endl;
			Meso::SimpleReservation(1);	//Ektupwnw sthn o8onh to ti 8a ginei kai kanw krathsh mia 8esh A 
		}else{ 					//alliws
			//cout << "ok3"<< endl;		//dbg msg
			if (this->Yparxei(2)){		//An uparxei 2h 8esh [B se emas logw trenou]
				if (!(this->Backup(2))){//Energopoihsh leitourgias backup choise(2)? wste na rwthsw an epi8umoun krathsh me diaforetikh 8esh (2) [kanw en8esh sthn queue mou]
					this->Enqueue(1);//An den htan epituxes to backup proceedure 8a ton valoume se queue!
				}				
			}else {				//An den uparxei, ton vazw sthn lista amonhs GIA THN 8ESH thn opoia zhthse arxika
				cout << "Dystyxws den uparxei kamia 8esh oute sthn kathgoria 2 alliws 8a sas proteiname na ta3idepsete me 8esh sthn kathgoria 1! 8a sas valoume sthn lista anamonhs [new!]" << endl;
				this->Enqueue(1);	//Lista anamonhs
			}
		}
	}else if (t==2){				//Antistoixws an zhthse 8esh B
		//cout << "ok1"<< endl;
		if (this->Yparxei(2)){
			//cout << "ok2"<< endl;
			cout << "\n Ta3ideuontas " << mesoname_ <<" me aeroplano sthn 2h 8esh!\n" << endl;
			Meso::SimpleReservation(2);
		}else{ 
			//cout << "ok3"<< endl;
			if (this->Yparxei(1)){
				if (!(this->Backup(1))){//Energopoihsh leitourgias backup choise(2)? wste na rwthsw an epi8umoun krathsh me diaforetikh 8esh (2) [kanw en8esh sthn queue mou]
					this->Enqueue(2);//An den htan epituxes to backup proceedure 8a ton valoume se queue!
				}			
			}else {
				cout << "Dystyxws den uparxei kamia 8esh oute sthn kathgoria 1 alliws 8a sas proteiname na ta3idepsete me 8esh sthn kathgoria 1! 8a sas valoume sthn lista anamonhs [new!]" << endl;
				this->Enqueue(2);
			}
		}
	}else{
		cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
	}
}

//////////////////Akurwsh
void Aeroplano::AdvCancelation(){
	int t;	
	t = MenuKathgorias1();
	if (t==1){
		if (this->SimpleCancelation(1)){   //den uparxei Q an den uparxei kan hdh eishthrio!
			if (this->CheckQueue(1)){  //Episis kanw prwta akurwsh 8eshs kai ustera apo to Deque 3anakanw krathsh kai auto dioti den mporei na anevei panw apo sugekrimeno ar8mo krathsewn [dld na katevei h metablhth ticket1realtime_ katw apo to 0!]
				this->Dequeue(1);
			}
		}
	}else if (t==2){				//Antistoixws an zhthse 8esh B
		if (this->SimpleCancelation(2)){
			if (this->CheckQueue(2)){
				this->Dequeue(2);
			}
		}
	}else{
		cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
	}
}
int main(){
	int choice=Krathsh;	//epiloges twn menues
	int meso=Train;
	int treno=PatraA8hna;
	int ploio=PatraAnkona;
	int aeroplano=A8hnaThessalonikh;
	int kathgoria=Alfa;
	int akurwsh=PatraA8hnaAK;
	int exit=FALSE;
	Meso Printer_Polumorphism; //polumorphismos gia ektupwsh sto arxeio. Sugekrimena to h virtual tou mesou kanei initialize to arxeio enw oi alles ekteloun thn ektupwsh/apo8hkeush seiriaka
	Treno Patra_A8hna("Patra_A8hna"), Patra_Purgos("Patra_Purgos"), A8hna_8essalonikh("A8hna_8essalonikh"), A8hna_Lianokladi("A8hna_Lianokladi"), A8hna_Larisa("A8hna_Larisa");//ola ta antikeimena trenou, ploiou, aeroplanou.
	Ploio Patra_Ankona("Patra_Ankona"), Patra_Venetia("Patra_Venetia"), Patra_Printezi("Patra_Printezi");
	Aeroplano A8hna_Thessalonikh("A8hna_Thessalonikh"), A8hna_Milano("A8hna_Milano"), A8hna_Frankfourth("A8hna_Frankfourth"), A8hna_NYorkh("A8hna_NYorkh"); // Prosoxh A8hna_Thessalonikh diaferei apo A8hna_8essalonikh!

	cout << "\n\n===================+===================\n";		//Arxika mhnymata kata thn ekkinhsh tou programmatos.
	cout << "Patras Travel Agency_______________\n";
	cout << "Kalws hr8ate sto prohghmeno systhma\n";
	cout << "krathsewn ths etairias mas. Plohgh8eite\n";
	cout << "eleu8era mesa apo ta menu epilogwn. Mhn\n";
	cout << "distasete opoiadhpote stigmh na piesete\n";
	cout << "to 5 gia voh8eia. Kalh synexeia!\n";
	sleep(1);
	while (!exit){			//Atermwn vrogxos gia na dex8ei to input gia thn epilogh tou prwtou menu
		choice = Menu();	//1h epilogh
		if ( choice<Krathsh || choice>E3odos){
			cout << "\n H sygekrimenh epilogh den einai dynath\n\n";
			continue;	//Xeirismos la8ous.
		}
		switch (choice){	
			case Krathsh:	//An epele3e na kanei krathsh apo to prwto menu | Ka8e stigmh sta epomena menu o xrhsths mporei na epistrepsei pisw se auto to menu.
				//system("clear");
				cout << "|Krathseis:|\n";
				cout << " Epile3te analoga me to meso me to opoio epi8umeite na ta3idepsete:\n";
				meso = MenuMesou();//Metavash se 2o menu gia thn epilogh mesou metakinhshs.
				if ( meso<Train || meso>Back){
					cout << "\n H sygekrimenh epilogh den einai dynath.\nEpistrofh sto arxiko menu!\n\n";
					break;//Xeirismos la8ous.
				}
				switch (meso){
					case Train://///////////////////////////ti 8a ginei an parei treno:
						treno = MenuTreno();
						if ( treno<PatraA8hna || treno>A8hnaLarisa){
							cout << "\nEpistrofh sto arxiko menu!\n\n";
							break;//Xeirismos la8ous.
						}
						switch (treno){ //Analoga me thn epilogh ekteleitai Advanced Reservation gia th sugekrimenh diadromh [ekei o xrhsths epilegei 8esh]
							case PatraA8hna:
								Patra_A8hna.AdvReservation();
								break;
							case PatraPurgos:
								Patra_Purgos.AdvReservation();
								break;
							case A8hna8essalonikh:
								A8hna_8essalonikh.AdvReservation();
								break;
							case A8hnaLianokladi:
								A8hna_Lianokladi.AdvReservation();
								break;
							case A8hnaLarisa:
								A8hna_Larisa.AdvReservation();
								break;
							default://debugging default option
								cout << "edw eimaste sthn default trenou!";
								break;
						}
						break;
					case Ship://///////////////////////////ti 8a ginei an parei ploio:
						ploio = MenuPloio();
						if ( ploio<PatraAnkona || ploio>PatraPrintezi){
							cout << "\nEpistrofh sto arxiko menu!\n\n";
							break;//Xeirismos la8ous.
						}
						switch (ploio){//Analoga me thn epilogh ekteleitai Advanced Reservation gia th sugekrimenh diadromh [ekei o xrhsths epilegei 8esh]
							case PatraAnkona:
								Patra_Ankona.AdvReservation();
								break;
							case PatraVenetia:
								Patra_Venetia.AdvReservation();
								break;
							case PatraPrintezi:
								Patra_Printezi.AdvReservation();
								break;
							default://debugging default option
								cout << "edw eimaste sthn default ploiou!";//debugging message
								break;
						}
						break;
					case Plane://///////////////////////////ti 8a ginei an parei aeroplano:
						aeroplano = MenuAeroplano();
						if ( aeroplano<PatraAnkona || aeroplano>PatraPrintezi){
							cout << "\nEpistrofh sto arxiko menu!\n\n";
							break;//Xeirismos la8ous.
						}
						switch (aeroplano){//Analoga me thn epilogh ekteleitai Advanced Reservation gia th sugekrimenh diadromh [ekei o xrhsths epilegei 8esh]
							case A8hnaThessalonikh:
								A8hna_Thessalonikh.AdvReservation();
								break;
							case A8hnaMilano:
								A8hna_Milano.AdvReservation();
								break;
							case A8hnaFrankfourth:
								A8hna_Frankfourth.AdvReservation();
								break;
							case A8hnaNYorkh:
								A8hna_NYorkh.AdvReservation();
								break;
							default://debugging default option
								cout << "edw eimaste sthn default aeroplanou!";//debugging message
								break;
						}
						break;
					case Back:
						break;
					default://debugging default option
						cout << "Default case tou mesou";
						break;
				}
				break;
			case Akurwsh:
				//system("clear");
				cout << "|Akurwseis:|\n";
				cout << " Epile3te analoga me to dromologio kai thn 8esh pou exei ginei h krathsh:\n";
						akurwsh = MenuAkurwshs();
						if ( akurwsh<PatraA8hnaAK || akurwsh>PiswAK){
							cout << "La8os epilogh.\nEpistrofh sto arxiko menu!\n\n";
							break;//Xeirismos la8ous.
						}
						switch (akurwsh){//Analoga me thn epilogh ekteleitai Advanced Cancelation gia th sugekrimenh diadromh [ekei o xrhsths epilegei 8esh]
							case PatraA8hnaAK:
								Patra_A8hna.AdvCancelation();
								break;
							case PatraPurgosAK:
								Patra_Purgos.AdvCancelation();
								break;
							case A8hna8essalonikhAK:
								A8hna_8essalonikh.AdvCancelation();
								break;
							case A8hnaLianokladiAK:
								 A8hna_Lianokladi.AdvCancelation();
								break;
							case A8hnaLarisaAK:
								A8hna_Larisa.AdvCancelation();
								break;
							case PatraAnkonaAK:
								Patra_Ankona.AdvCancelation();
								break;
							case PatraVenetiaAK:
								Patra_Venetia.AdvCancelation();
								break;
							case PatraPrinteziAK:
								Patra_Printezi.AdvCancelation();
								break;
							case A8hnaThessalonikhAK:
								A8hna_Thessalonikh.AdvCancelation();
								break;
							case A8hnaMilanoAK:
								A8hna_Milano.AdvCancelation();
								break;
							case A8hnaFrankfourthAK:
								A8hna_Frankfourth.AdvCancelation();
								break;
							case A8hnaNYorkhAK:
								A8hna_NYorkh.AdvCancelation();
								break;
							case PiswAK:
								break;
							default://debugging default option
								cout << "edw eimaste sthn Akurwsh";//debugging message
								break;
						}
				break;
			case Emfanish: //Edw ektelountai oi sunarthseis gia thn emfanish twn antistoixwn antikeimenwn. Gia logous kompsothtas emfanizontai oi zhtoumenes plhrofories mono gia 3 antikeimena [sthn ektupws se arxeio emfanizontai ola ta antikeimena
				//system("clear");
				cout << "|Emfanish:|\n";
				cout << " [gia logous kompsothtas emfanizetai mono \n to 1o dromologio ana meso metaofras]\n\n";
				//sleep(1);
				Patra_A8hna.PrintAdv(); //Advanced Printing!
				Patra_Ankona.PrintAdv();
				A8hna_Thessalonikh.PrintAdv();
				//sleep(5);
				break;
			case Apo8hkeush:	//Ginetai apo8hkeush se arxeio apo tis kaloumenes sunarthseis. Prwta kaleitai h sunarthsh prosvashs gia thn "uperklash" Meso opou kanei to initialization tou arxeiou kai ustera oles oi sunarthseis antistoixa gia ka8e antikeimeno ka8e upoklashs [polumorphism]
				//system("clear");
				cout << "|Apo8hkeush:|\n";
				cout << " Ginetai apo8hkeush tou sunolou twn krathsewn sto arxeio krathseis.dat\n";
				sleep(1);
				Printer_Polumorphism.Print2fileAdv();
				Patra_A8hna.Print2fileAdv();
				Patra_Purgos.Print2fileAdv();
				A8hna_8essalonikh.Print2fileAdv();
				A8hna_Lianokladi.Print2fileAdv();
				A8hna_Larisa.Print2fileAdv();
				Patra_Ankona.Print2fileAdv();
				Patra_Venetia.Print2fileAdv();
				Patra_Printezi.Print2fileAdv();
				A8hna_Thessalonikh.Print2fileAdv();
				A8hna_Milano.Print2fileAdv();
				A8hna_Frankfourth.Print2fileAdv();
				A8hna_NYorkh.Print2fileAdv();
				cout << " H diadikasia oloklhrw8hke.\n";
				//sleep(1);
				break;
			case Voh8eia:		//Aneptugmeno susthma voh8eias:P
				//system("clear");
				cout << "\n|Anapty3h:|\n";
				cout << " Nikolaos kai Filippos Vasilakis.\n\n|Epikoinwnia:|\n";
				cout << " baslakn@ceid.upatras.gr,\n";
				cout << " vasilakis@ceid.upatras.gr.\n\n";
				cout << "|Voh8eia:|\n";
				cout << " Pieste to plhktro 1 gia na metaveite sto\n upomenu krathsewn, to 2 gia na akurwsete\n kapoia hdh uparxousa krathsh, to 3 gia na\n ektypwsete thn trexousa katastash sthn o-\n 8onh, to 4 gia na apo8hkeusete to sunolo\n twn krathsewn sto arxeio krathseis.dat, to\n 5 gia voh8eia (edw), kai to 6 gia oristikh\n e3odo apo to systhma.\n";
				//sleep(8);
				break;
			case E3odos:
				//system("clear");
				cout << "|E3odos|\n";
				cout << "\nEuxaristoume!\n";
				exit=TRUE;
				break;
			default://debugging default option
				cout << "omg dude!\n";
				exit=TRUE;
				break;
		}
	}

	return 0;
	
}

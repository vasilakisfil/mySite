#ifndef PRIMES_H
#define PRIMES_H

struct thread_data {
	int number;
	long int max;
	long int min;
	long int sum;
}pass;

struct timeval first,last,elapsed;

pthread_mutex_t mymutex;



#endif

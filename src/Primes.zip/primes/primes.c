/********************************************************************************************************
*		Main fuction that calculates(through a threa,multiple treads or multiprocesses)
*		the number of primes that exist on a range of numbers.
********************************************************************************************************/


#include "primes_fuct.h"
#include "primes.h"
#include <sys/utsname.h>
#include <string.h>
#include <sys/time.h>

//struct that it's passed to the tread fuction



int main(int argc, char *argv[])
{



	//variables
	int select;
	char temp[100];
	pid_t pid;

	//struct utsname id;
	//er=uname(&id);


	system("clear");
	
	//printf("%d %ld\n", (int)new.tv_sec, new.tv_usec);

	printf("Program that calculates the prime numbers that exist in a range of numbers\n\n");
	printf("1.Run the program in a single process.\n");
	printf("2.Run the program with processes(not curently working).\n");
	printf("3.Run the progam with threads.\n");
	printf("4.Run the program using OpenMP\n");
	fflush(NULL);
	select=atoi(fgets(temp,sizeof temp, stdin));
	
	if(select==1)
	{
		long int sum;
		//double prime;
		printf("Running in a single thread/process\n");
		
		printf("Finding all the prime numbers between %d and %d\n", MIN, MAX);
		//printf("(with 1 second delay)\n");
		//sleep(1);

		//to find the number of the prime numbers we used the Wilson's theorem, which states that every prime p divides (p − 1)! + 1.
		gettimeofday(&first,NULL);
		sum = calculatePrimeNumbers(MIN, MAX);
		gettimeofday(&last,NULL);
		if(first.tv_usec>last.tv_usec)
		{
			last.tv_usec+=1000000;
			last.tv_sec--;
		}
		elapsed.tv_sec=last.tv_sec-first.tv_sec;
		elapsed.tv_usec=last.tv_usec-first.tv_usec;
		printf("Total sum of prime numbers: %ld\nsec: %d\tusec: %d\n", sum, (int)elapsed.tv_sec, (int)elapsed.tv_usec);
		
	}

	
	if(select==2)
	{
		if((pid=fork())==0)
		{
			if((pid=fork())==0)
			{
				if((pid=fork())==0)
				{
					printf("process 4...\n");

					printf("Hello World %d\n", getpid());
					fflush(NULL);
					//exit(0);
				}
				else
				{
					waitpid(pid,NULL,0);
					printf("process 3...\n");

					printf("Hello world %d\n", getpid());
					fflush(NULL);			

				}
			}
			else
			{
				waitpid(pid,NULL,0);
				printf("process 2...\n");
			
				printf("Hello world %d\n", getpid());			

			}
		}
		else
		{
			waitpid(pid,NULL,0);
			printf("process 1...\n");
			
			printf("Hello world %d\n", getpid());			

		}
	}

	if(select==3)
	{
		pthread_t number;
		int err;
		if(argc==1)
		{
			for(i=0; i<4; i++)
			{
				inumber=i;
				err=pthread_create(&number, NULL, thread_fuction,(void *) &inumber);
				if(err)
				{
					printf("ERROR; return code from pthread_create is %d\n", err);
					exit(-1);
				}
				pthread_join(number,NULL);
			}
		}
		else if(argc==2)
		{
			//initializes the mutex, no attributes
			//pthread_mutex_init(&mymutex, NULL);

			int sub,mood,i,set,argument;


			//initializint the sum
			pass.sum=0;

			//int max=200,min=95;

			argument=atoi(argv[1]);
			struct thread_data passi[argument];

			printf("Parallel computing of the primes.Number of threads:   %d.\n", argument);
			//printf("The argument which results to the number of the parallel threads is %d\n", argument);

			sub=MAX-MIN;
			//printf("TTTT %d %d\n", sub,argument);
			mood=sub%argument;
			set=(int)sub/argument;
			//printf("---->%d, %d\n", set, mood);
			//pthread_mutex_lock(&mymutex);
			
			gettimeofday(&first,NULL); //cheating a bit..
			for(i=1; i<=argument; i++)
			{
				passi[i-1].number=i;
				passi[i-1].min=(i-1)*set;
				passi[i-1].max=i*set;
				if(i==argument) pass.max=i*set+mood;
				//printf("%d\n", i*set);
				err=pthread_create(&number, NULL, thread_fuction2, (void *) &passi[i-1]);
				if(err)
				{
					printf("ERROR; return code from pthread_create is %d\n", err);
					exit(-1);
				}
				//pthread_join(number, NULL);
			}
			//sleep(1);
			pthread_join(number, NULL);

			gettimeofday(&last,NULL);
			if(first.tv_usec>last.tv_usec)
			{
				last.tv_usec+=1000000;
				last.tv_sec--;
			}
			elapsed.tv_sec=last.tv_sec-first.tv_sec;
			elapsed.tv_usec=last.tv_usec-first.tv_usec;

			printf("Total sum of prime numbers: %ld \nsec: %d\tusec: %d\n", pass.sum, (int)elapsed.tv_sec, (int)elapsed.tv_usec);
			//pthread_mutex_unlock(&mymutex);

			//pthread_mutex_destroy(&mymutex);
		}
		else
		{
			printf("Usage: ./a.out num_of_threads\n");
			printf("num_of_threads: The number of threads they wil be used for parallelizing.\n");
		}

	}

	if(select==4)
	{
		long int sum;
		//double prime;
		printf("Calculating using OpenMP");
		
		printf("Finding all the prime numbers between %d and %d\n", MIN, MAX);

		//to find the number of the prime numbers we used the Wilson's theorem, which states that every prime p divides (p − 1)! + 1.

		//calling OpenMP's function
		gettimeofday(&first,NULL);
		sum = calculatePrimeNumbers_OpenMP(MIN, MAX);

		gettimeofday(&last,NULL);

		if(first.tv_usec>last.tv_usec)
		{
			last.tv_usec+=1000000;
			last.tv_sec--;
		}
		elapsed.tv_sec=last.tv_sec-first.tv_sec;
		elapsed.tv_usec=last.tv_usec-first.tv_usec;

		printf("Total sum of prime numbers: %ld\nsec: %d\tusec: %d\n", sum, (int)elapsed.tv_sec, (int)elapsed.tv_usec);
		
	}




	return 0;

}

/****************************************** prime numbers' algorithm *************************************
Αλγόριθμοι εύρεσης πρώτων

Παρατίθενται μερικοί αλγόριθμοι (κατά σειρά ταχύτητας ή και απλότητας) για την εύρεση άν ο Ν>=2 είναι πρpthread_join(number, NULL);ώτος. Η σειρά επίσης αυτών των αλγορίθμων είναι παιδευτική για την εισαγωγή σε μια σειρά από προγράμματα για ηλεκτρονικούς υπολογιστές.

[Επεξεργασία] Απλός 1 - από τον ορισμό του πρώτου αριθμού

    * Εξετάζουμε διαδοχικά όλους τους ακέραιους Μ < Ν
    * Μόλις βρεθεί διαιρέτης του Ν σταματάμε και ο Ν δεν είναι πρώτος
    * Αν εξαντληθούν οι Μ χωρίς να βρεθεί διαιρέτης, τότε ο Ν είναι πρώτος

[Επεξεργασία] Απλός 2

Βασιζόμενοι στην παρατήρηση ότι κανένας αριθμός 'Ν' δεν έχει διαιρέτη μεγαλύτερο του 'Ν'/2, τροποποιούμε τον παραπάνω αλγόριθμο εξετάζοντας όλους τους αριθμούς 'Μ' < 'Ν'/2.

[Επεξεργασία] Απλός 3

Παρατηρούμε ότι αν ένας αριθμός Ν δεν είναι πρώτος τότε έχει (τουλάχιστον) δύο διαιρέτες μεγαλύτερους από 1. Σε αυτήν την περίπτωση τουλάχιστον ένας διαιρέτης είναι μικρότερος από την τετραγωνική ρίζα του αριθμού. Τροποποιούμε τον αλγόριθμο 2 εξετάζοντας όλους τους αριθμούς Μ που είναι μικρότεροι από την τετραγωνική ρίζα του N, αν η τελευταία δεν είναι ακέραιος. Αλλιώς ο αριθμός δεν είναι πρώτος, επειδή τον διαιρεί και η τετραγωνική του ρίζα.

[Επεξεργασία] Απλός 4

*/

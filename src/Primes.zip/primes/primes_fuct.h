/**********************************************************************************************
*			fuctions protypes
*
**********************************************************************************************/

#ifndef PRIMES_FUCT_H
#define PRIMES_FUCT_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <math.h>
#include <omp.h>

#define MIN 0
#define MAX 10000000


void *thread_fuction(void *num);
int findPrimeNumber(int num);
int calculatePrimeNumbers(long int min, long int max);
//OpenMP's function
int calculatePrimeNumbers_OpenMP(long int min, long int max);
void *thread_fuction2(void *threadarg);

int inumber;
volatile int i;
/*
struct thread_data {
	int number;
	int max;
	int min;
};*/

#endif


/********************************************************************************************************
*			fuctions declarations
*
********************************************************************************************************/

#include "primes_fuct.h"
#include "primes.h"



int calculatePrimeNumbers(long int min, long int max)
{


	int new=0,sum=0,i;


	for(i=min; i<max; i++)
	{
		new=findPrimeNumber(i);
		//printf("new: %d %d \n", i, new);
		if(new==0)
		{
			sum++;
		}
		//printf("--------------------> %ld\n", max);
	}
	//printf("Number of prime numbers...: %d, %d\n", sum, *i);

	return sum;
}

//We use different function for OpenMP because the directives are declared in side the function...
int calculatePrimeNumbers_OpenMP(volatile long int min, volatile long int max)
{


	volatile int new=0,sum=0,i;



	#pragma omp parallel for shared(i) firstprivate(new) reduction(+:sum)

	for(i=min; i<max; i++)
	{
		new=findPrimeNumber(i);
		//printf("new: %d %d \n", i, new);
		if(new==0)
		{
			sum++;
			//printf("Hello World, %d %d %d\n", i, omp_get_num_threads(), omp_get_thread_num());
		}
		//printf("--------------------> %ld\n", max);
	}
	//printf("Number of prime numbers...: %d, %d\n", sum, *i);

	return sum;
}


int findPrimeNumber(int num)
{
	int i;
	double sq;

	sq=sqrt(num);

	if(sq==(int)sq)
	{
		return -1;
	}
	else
	{
		int flag=1;
		//printf("%d continuing....\n", (int)num);
		for(i=2; i<sq; i++)
		{	
			if((num)%i==0)
			{
				flag=0;
				break;
			}
			
		}
		if(flag)
		{
			//printf("%d first number\n", num);
			return 0;
		}
		else return -1;
	}


}

void *thread_fuction(void *num)
{
	int *new;

	new=(int *)num;
	printf("Hello World through the function !!! %d\n", *new);

	return NULL;
}

void *thread_fuction2(void *threadarg)
{

	int sum, min,max;

	//sum = malloc(sizeof(sum));


	struct thread_data *new_data;



	new_data = (struct thread_data *) threadarg;

	min=new_data->min;
	max=new_data->max;

	
	//printf("Thread %u, min: %d   max: %d\n", (unsigned int)pthread_self(), min, max);
	

	sum=calculatePrimeNumbers(min, max);
	//printf("%d %d %u\n",sum, max, (unsigned int)pthread_self());

	pthread_mutex_lock(&mymutex);

	pass.sum= pass.sum + sum;

	pthread_mutex_unlock(&mymutex);

	//printf("-->%d \n", pass.sum);
	

	//terminate the thread
	pthread_exit(NULL);

	return NULL;

}



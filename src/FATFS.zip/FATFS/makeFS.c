/*************************************************************************
*	Functions to initialize the filesystem :-)
*
**************************************************************************/

//not including the global.h
#include "makeFS.h"

int create_filesystem(int num_of_blocks,int size_of_blocks)
{

	int i;
	//the file discriptor
	int fd;
	//the filename of our filesystem
	char *filename="ceidFS";

	//directory table made on a struct
	struct directory_table
	{
		char filename[16];
		long int size;
		int fat_index;
		int ufid;
	};

	//FAT table made on a two-dimensional array
	int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	short int free_blocks[1000];


	/***************************************************** initializations ****************************************************/

	//initializing the FAT array..we initialize it with negative numbers since it holds blocks a negative number is an error
	//for the disc blocks column we set as default the number -1 whereas in the second column we set as default number -2 and not the EOF number.
	for(i=0; i<1000; i++)
	{
		FAT[i][0]=-1;
		FAT[i][1]=-2;
	}

	//initializing the directory table..
	//since we cannot know from the bigining how much space we should allocate for the directory table(means how many files the user will create)
	//we set a limit to 100 files in order to be able to allocate the space..
	struct directory_table dir_table[100];

	//initializing the size,fat_index and the ufid to -1
	for(i=0; i<100; i++)
	{
		dir_table[i].size=-1;
		dir_table[i].fat_index=-1;
		dir_table[i].ufid=-1;
	}

	//initializing the free block list..we set 1 for the free blocks and 0 for the used blocks..
	for(i=0; i<1000; i++)
	{
		free_blocks[i]=1;
	}
	

	/***************************************** writing the data structures to the file *******************************************/

	//now we will write all the structure to the file and then we sill extend the file where there will be the blocks..

	fd=open(filename,O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);

	//writing the directory table first..
	write(fd,dir_table,sizeof dir_table);

	//writing the FAT table next..
	write(fd,FAT,sizeof FAT);

	//writing the free block list at last..
	write(fd,free_blocks,sizeof free_blocks);

	int structures_size=sizeof dir_table + sizeof FAT + sizeof free_blocks;
	printf("the size of all the structures: %d\n", structures_size);
	
	//extending the file..
	//the size of the extension
	int size=1000*4;

	//by ftruncate manual:
	//int ftruncate(int fildes, off_t length);
	/*If fildes refers to a regular file, the ftruncate() function shall cause the size of the file to be truncated to length. If the size of the file 		previously exceeded length, the extra data shall no longer be available to reads on the file. If the file previously was smaller than this size, 		ftruncate() shall either increase the size of the file or fail.XSI-conformant systems shall increase the size of the file.If the file size is 		increased, the extended area shall appear as if it were zero-filled. The value of the seek pointer shall not be modified by a call to ftruncate().*/

	//which means that if we have a file of 100 bytes and we want to extend it by 200 bytes we have to enter as length 300 bytes..

	//we set as length the extension we want to have plus the length of the initial size..
	if(ftruncate(fd, size+structures_size) == -1)
	{
        	perror("ftruncate");
        	close(fd);
        	exit(EXIT_FAILURE);
    	}

	//closing the file
	close(fd);

	return 0;

}




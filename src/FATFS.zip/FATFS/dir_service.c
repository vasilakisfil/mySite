/***********************************************************************
*			The directory service
*
***********************************************************************/


#include "global.h"
#include "dir_service.h"
#include "service_block.h"



//auth h sunarthsh anhkei sto directory service...auto shmainei oti se sxesh me to block service apla mono dhmiourgei ena arxeio me mhdeniko mege8os tipota allo...topo8eteitai epishs sto directory table to mege8os pou einai 0,to ufid tou,kai sto FAT table katalamvanetai mono mia 8esh...
int my_create(const char *FileName)
{

	/******************************************************************* allocations ***************************************************************/

	int i,position1,position2;

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	//to find the first free block to write
	for(i=0; i<1000; i++)
	{
		if(free_blocks[i]==1)

		{
			position1=i;
			free_blocks[i]=0;
			break;
		}
	}

	//writing the i position of FAT array..
	FAT[position1][0]=i;
	FAT[position1][1]=-2;

	//should change this.........
	for(i=0; i<100; i++)
	{
		if(dir_table[i].size==-1&&dir_table[i].fat_index==-1&&dir_table[i].ufid==-1)
		{
			position2=i;
			break;
		}
	}

	//printf("position on dir_table %d\n", position2);

	//creating the input on the directory table
	strcpy(dir_table[position2].filename,FileName);
	dir_table[position2].size=0;
	dir_table[position2].fat_index=position1;
	dir_table[position2].ufid=position1;


	//put_block(position1,"hey");


	return 0;

}


//function marks the fdTable that the FileName is open and on success return's the file's descriptor else(if there is no space for example on fdTable) -1
int my_open(const char *FileName)
{

	int ufid,i,j,flag=-1;
	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];

	//opening the file of the filesystem (Write Only mode-access by everyone) in order to copy the data structures to the memory
	//fd=open(filename,O_RDRW);

	for(i=0; i<100; i++)
	{
		if(!strcmp(dir_table[i].filename,FileName))
		{
			flag=0;
			ufid=dir_table[i].ufid;
			//printf("--------------->hello world\n");
			for(j=0; j<10; j++)
			{
				if((fdTable[j][0]==-1)&&(fdTable[j][1]==-2))
				{
					fdTable[j][0]=dir_table[i].ufid;
					fdTable[j][1]=dir_table[i].fat_index;
				}
				break;
			}
			break;
		}
	}
	
	if(flag==0)
	{
		return ufid;
	}
	else return flag;
}


//function that returns the number of the files of the filesystem and an array with their filenames..
int my_files(char ***filenames)
{

	/******************************************************************* allocations ***************************************************************/

	int i,count=0;

	//printf("%d", count);

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//char **temp;

	*filenames=(char **) malloc(count*sizeof(char *));

	/******************************************************							***************************************/

	for(i=0; i<100; i++)
	{
		if(!((dir_table[i].ufid==-1)&&(dir_table[i].size==-1)))
		{
			count++;
			(*filenames)[count-1]=malloc(dir_table[i].size);
			//printf("%d", count);
			strcpy((*filenames)[count-1],dir_table[i].filename);
		}
	}

	/*for(i=0; i<count; i++)
	{
		printf("%d.  %s\n",i+1,(*filenames)[i]);
	}*/

	return count;
}




int my_delete(const char *filename)
{

	/******************************************************************* allocations ***************************************************************/

	int num_blocks,i,j;
	int index,size;

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];

	for(i=0; i<100; i++)
	{
		if(!strcmp(dir_table[i].filename,filename))
		{
			index=dir_table[i].fat_index;
			size=dir_table[i].size;
			//printf("-->%ld\n",dir_table[i].size);
			dir_table[i].fat_index=-1;
			dir_table[i].size=-1;
			dir_table[i].ufid=-1;
		}
	}

	//to get how many blocks we will need...
	if((double)size/4==(int)size/4)
	{
		num_blocks=size/4;
	}
	else	num_blocks=size/4+1;

	j=index;
	//printf("%d\n",j);
	free_blocks[j]=1;
	int temp;
	for(i=0; i<num_blocks; i++)
	{
		FAT[j][0]=-1;
		temp=FAT[j][1];
		//printf("%d\n",j);
		FAT[j][1]=-2;
		free_blocks[j]=1;
		j=temp;
	}

	//printf("Num of blocks %d", num_blocks);
	
	return 0;
}


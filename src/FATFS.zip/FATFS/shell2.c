/****************************************************************************************
*  The shell where te user can input commands to handle the
*  filesystem
*****************************************************************************************/


#include "global.h"
#include "makeFS.h"
#include "mountingFS.h"
#include "dir_service.h"
#include "file_service.h"


//function for the input text on the my_echo command
char *enter_text(void);
//function that prints the help file
int my_help(void);


int main(void)
{
	//an array to handle all the inputs from fgets
	char temp[100];

	//to clear the terminal(unix command)
	system("clear");

	while(1)
	{	
		//the shell output
		printf("OpSys1FS>");
		//zeroing the array before any input from the user
		bzero(temp,sizeof temp);
		//getting the command the user entered
		fgets(temp,sizeof temp,stdin);
		if(!strncmp(temp,"my_mkfs",7))
		{
			//an array to handle the blocks,we declare it as char in order to work with the strncpy function...
			//we are going to modify from char to int with te atoi() function
			char blocks_a[100];
			bzero(blocks_a,sizeof blocks_a);
			//variables to handle the blocks numbers(size of every block-number of all the blocks)
			int blocks;
			int block_size;
			int i;
			//since the user etnered "my_mkfs " we search for the first next empty space of it's string
			for(i=8; i<100; i++)
			{
				//if you find it stop to hold the pisition(the i viriable)
				if(temp[i]==' ') break;
			}
			//copy the number of all the blocks
			strncpy(blocks_a,temp+8,i-8);
			//change the sring given from char to int in order to be able to use it
			blocks=atoi(blocks_a);
			printf("Number of blocks:%d\n",blocks);
			//zero again the array
			bzero(blocks_a,sizeof blocks_a);
			//copy the next number..the user MUST put the exact numbers in the correct form...the shell cannot handle errors
			strcpy(blocks_a,temp+i);
			//again change it to integer
			block_size=atoi(blocks_a);
			printf("Block size: %d\n",block_size);
			//calling the function which makes the filesystem and initializes some values..
			create_filesystem(4,1000);
		}
		else if(!strcmp(temp,"my_mount\n"))
		{
			printf("The filesystem was mounted\n");
			//function call for mounting..
			mountFS();
			continue;
		}
		else if(!strcmp(temp,"my_unmount\n"))
		{
			printf("The filesystem was unmounted...you can now exit safely.\n");
			//function call for unmounitng..
			unmountFS();
			continue;		
		}
		else if(!strcmp(temp,"my_quit\n"))
		{
			printf("Bye...\n");
			//no funtion call :P
			break;
		}
		else if(!strcmp(temp,"my_test1FS\n"))			/***************     private use only	  ****************/
		{
			printf("testing...\n");
			test1FS();
		}
		else if(!strcmp(temp,"my_print\n"))			/***************     private use only	  ****************/
		{
			printf("printing...\n");
			print_all();
		}
		else if(!strncmp(temp,"my_cat",6))
		{
			//array to hold the filename
			char file[100];
			int ufid,size;
			//copy the filename the user entered
			strcpy(file,temp+7);
			//cat_file(file);
			ufid=my_open(file);
			size=my_file_size(ufid);
			printf("size: %d\n", size);
			char text[size];
			//if the file exists
			if(ufid>=0)
			{
				my_read(ufid,text,size,0);
				my_close(ufid);
				printf("\n");
			}
			else printf("No such a file\n");

		}
		else if(!strncmp(temp,"my_2cat",7))			/***************     private use only	  ****************/
		{
			char file[100];
			int ufid,size;
			strcpy(file,temp+8);
			//cat_file(file);
			ufid=my_open(file);
			size=my_file_size(ufid);
			if(ufid>=0)
			{
				my_read(ufid,file,size,42);
				my_close(ufid);
			}
			else printf("No such a file\n");

		}
		else if(!strncmp(temp,"my_size",7))			/***************     private use only	  ****************/
		{
			char file[100];
			int ufid,size;
			strcpy(file,temp+8);
			//cat_file(file);
			ufid=my_open(file);
			size=my_file_size(ufid);
			if(ufid>=0)
			{
				printf("%s   %d\n",file,size);
				my_close(ufid);
			}
			else printf("No such a filee\n");

		}
		else if(!strncmp(temp,"my_rm",5))
		{
			//an array to hold the filename the user entered
			char file[100];
			//copy the filename from the stdin array
			strcpy(file,temp+6);
			my_delete(file);

		}
		else if(!strcmp(temp,"my_help\n"))
		{
			my_help();
			//function call that prints the help file...
			continue;
		}
		else if(!strcmp(temp,"my_ls\n"))
		{
			char **files;
			int num,i;
			printf("Prints a list with all the files..\n");
			//system("ls --all");
			//function call that prints the list with all the files...
			num=my_files(&files);
			for(i=0; i<num; i++)
			{
				printf("%d.  %s\n",i+1,files[i]);
			}
			continue;
		}
		else if(!strcmp(temp,"my_df\n"))
		{
			//function call that prints everything about the blocks...
			my_df();
			continue;
		}
		else if(!strncmp(temp,"my_echo",7))
		{
			char file[25];
			char *text;
			//FILE *fp;
			//int text;
			//appending file operation
			if(!strncmp(temp+8,">>",2))
			{
				int size,ufid;
				strcpy(file,temp+11);
				printf("Your file's filename is: %s\n",file);
				text=enter_text();
			        /*if((fp=fopen(file, "a"))==NULL)
				{
            				printf("Cannot open file");
            				continue;
				}
				fputs(text,fp);*/

				ufid=my_open(file);
				size=my_file_size(ufid);
				//char text[size];
				my_write(ufid,text,strlen(text),size);
				my_close(ufid);

				//printf("%s\n",text);
				printf("\n");

				//fclose(fp);
				continue;
				
			}
			//new file operation
			else if(!strncmp(temp+8,"> ",2))
			{
				int ufid;
				strcpy(file,temp+10);
				printf("Your file's filename is: %s\n",file);
				text=enter_text();
			        /*if((fp=fopen(file, "w"))==NULL)
				{
            				printf("Cannot open file");
            				continue;
				}*/
				//printf("%d\n",strlen(text));
				//fputs(text,fp);
				//fclose(fp);

				//block_service(text);

				printf("%s\n%d\n",text,strlen(text));

				my_create(file);
				ufid=my_open(file);
				my_write(ufid,text,strlen(text),0);
				my_close(ufid);
				//size=my_file_size(ufid);
				//printf("%d",size);
				printf("\n");
				
				continue;
				
				continue;
				
			}
			printf("Wrong operator!\n");
			continue;
		}
		else if(!strncmp(temp,"\n",2))
		{
			continue;
		}
		else
		{
			printf("Type \"my_help\" for the full list of commnands...\n");
			continue;
		}
	}
	
	return EXIT_SUCCESS;

}



//function for the my_echo utility...the fuction returns the text the user entered
char *enter_text(void)
{
	//int num=EOF;
	char *num2;
	char *story;

	char temp[100];

	int size=0;
	
	printf("Please enter your text...press ctrl+D to end...\n");
	num2=fgets(temp,sizeof temp,stdin);
	size=size+(strlen(temp));
	//printf("-------> size: %d\n", size);
	story=(char *) malloc(size*sizeof(char *));
	strncpy(story,temp,size);

	while(1)
	{
		bzero(temp,sizeof temp);
		
		num2=fgets(temp,sizeof temp,stdin);
		if(num2==NULL) break;
		size=size+(strlen(temp));
		story=(char *) realloc(story,size*sizeof(char *));
		strncpy(story+strlen(story),temp,strlen(temp));
	}
	//strncpy(story+strlen(story)-1,'\0',1);
	//eat em up the last \n character....
	//story[strlen(story)-1]='\0';
	//story=(char *) realloc(story,size*sizeof(char *)-1);
	/*if(num2==NULL)
	{
		printf("%s",story);
		printf("Bye...\n");
		exit(0);
	}*/

	return story;


}


//the help file
int my_help(void)
{
	printf("List of commands:\n\n");
	printf("my_mkfs blocks block-size\tCreates the filesystem.\n\t\t\t\tblocks=number of blocks\n\t\t\t\tblock-size=the size of every block\n");	
	printf("my_mount\t\t\tMounts the filesystem.\n");
	printf("my_unmount\t\t\tUnmounts the filesystem.\n");
	printf("my_quit\t\t\t\tExits the program(before exiting the filesystem should be unmounted).\n");
	printf("my_ls\t\t\t\tPrints all the files of the filesystem.\n");
	printf("my_rm filename\t\t\tDeletes the file specified by filename.\n");
	printf("my_df\t\t\t\tPrints the number of the free blocks and the block's number of the filesystem.\n");
	printf("my_cat filename\t\t\tPrints the file specified by the filename on the standard output.\n\n");
	printf("my_echo operation filename\noperation: > or >>\n> :  When operation is > the my_echo command creates a new file with the name ");
	printf("filename and then the user can enter the text of the file.\n>> :  When operation is >> the my_echo command appends to the end of the file");
	printf("specified by filename.\n");


	return 0;
}
















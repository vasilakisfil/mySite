/********************************************************************************************
*	The functions that mounts and unmounts the filesystem
*
*********************************************************************************************/

#include "global.h"
#include "mountingFS.h"


//the mount function
int mountFS()
{

	/******************************************************************* allocations ***************************************************************/
	
	int i;
	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	//the File Descriptor Table
	extern int fdTable[10][2];
	
	/*********************************************************** writing to the file ****************************************************************/

	//opening the file of the filesystem (Read Only mode-access by everyone) in order to copy the data structures to the memory
	fd=open(filename,O_RDONLY);

	//we read the file exact the same way as we write it when the filesystem was created

	//reading from the file the directory table
	read(fd,dir_table,sizeof dir_table);

	//reading from the file the FAT table
	read(fd,FAT,sizeof FAT);

	//reading drom the file the free block list..
	read(fd,free_blocks,sizeof free_blocks);

	//closing the file descriptor
	close(fd);

	//initializing the File Descriptor Table
	for(i=0; i<10; i++)
	{
		fdTable[i][0]=-1;
		fdTable[i][1]=-2;
	}

	/*printf("free_blocks: %d\n",free_blocks[0]);
	for(i=0; i<1000; i++)
	{
		printf("%d",free_blocks[i]);
	}
	
	char c;
	scanf("%c", &c);

	for(i=0; i<1000; i++)
	{
		printf("%d\t%d\n",FAT[i][0],FAT[i][1]);
	}*/

	return 0;

}




//the unmount function
int unmountFS(void)
{

	/******************************************************************* allocations ***************************************************************/
	
	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	/*********************************************************** writing to the file ****************************************************************/

	//opening the file of the filesystem (Write Only mode-access by everyone) in order to copy the data structures to the memory
	fd=open(filename,O_WRONLY);

	//we write the file exact the same way as we write it when the filesystem was created

	//writing the directory table to the file..
	write(fd,dir_table,sizeof dir_table);

	//writing the FAT table to the file..
	write(fd,FAT,sizeof FAT);

	//writing the free block list...
	write(fd,free_blocks,sizeof free_blocks);

	//closing the file descriptor
	close(fd);
	return 0;
}




//test function
int test1FS(void)
{
	/******************************************************************* allocations ***************************************************************/

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];


	/******************************************************************** testing ******************************************************************/

	//creating the file
	
	strcpy(dir_table[17].filename,"arxeio.txt");
	dir_table[17].size=10;
	dir_table[17].fat_index=555;
	dir_table[17].ufid=555;

	//allocating the space

	free_blocks[555]=0;
	free_blocks[556]=0;
	free_blocks[557]=0;

	//declaring to the fat

	FAT[555][0]=2353;
	FAT[555][1]=556;

	FAT[556][0]=1366;
	FAT[556][1]=557;

	FAT[557][0]=5642;
	FAT[557][1]=-2;

	return 0;
}




int print_all(void)
{
	
	/******************************************************************* allocations ***************************************************************/
	
	int i;
	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];






	for(i=0; i<1000; i++)
	{
		printf("%d",free_blocks[i]);
	}
	
	char c;
	scanf("%c", &c);

	for(i=0; i<1000; i++)
	{
		if(i==500)
		{
			scanf("%c", &c);
		}
		printf("%d\t%d\n",FAT[i][0],FAT[i][1]);
	}

	return 0;


}


int my_df(void)
{
	/******************************************************************* allocations ***************************************************************/

	int i,num=0;;

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	//file directory table made static which means that 10 files maximum can be opened at the same time
	extern int fdTable[10][2];


	/****************														****************/

	for(i=0; i<1000; i++)
	{
		if(free_blocks[i]==1)
		{
			num++;
		}
	}

	if(i>0)
	{
		printf("Total number of blocks: %d\n", 1000);
		printf("Number of free blocks: %d\n", num);
		printf("Block size: %d\n", 4);
	}
	else printf("No free blocks");

	return 0;

}

#ifndef FILE_SERVICE_H
#define FILE_SERVICE_H


int my_write(int ufid,char *buf,int num,int pos);	//writes on the pos position of the opened file with the given ufid num number of bytes from the 
							//*buf array
	
int my_close(int ufid);					//closing the file with the given ufid


int my_read(int ufid,char *buf,int num,int pos);	//reads from the pos position of the opened file with the given ufid num number  of bytes to the
							//*buf array

int my_file_size(int ufid);				//returns the size of the file with the given ufid in bytes

#endif

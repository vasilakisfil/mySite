#ifndef SERVICE_BLOCK_H
#define SERVICE_BLOCK_H



int block_service(char *file);					//the first verion of block service 	--->	PRIVATE USE ONLY

int cat_file(char *file);					//the first version of my_cat utility 	--->	PRIVATE USE ONLY

int put_block(int blockptr,char *buffer,int position);			//writes from the string *buffer to the disk block pointed to by blockptr

int get_block(int blockptr,char *buffer,int position);		//reads from the block of the filesystem pointed from blockptr to the array *buffer shifted by
								//position bytes


#endif

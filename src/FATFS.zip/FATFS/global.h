/*************************************************************************
*			Global declarations
*
*************************************************************************/


#ifndef GLOBAL_H
#define GLOBAL_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <string.h>
#include <sys/stat.h>


#define bzero(b,len) (memset((b), '\0', (len)), (void) 0)	//This definition replaces the function bzero with memset for maximum portability


//the filename of our filesystem
char *filename;

//directory table made on a struct
struct directory_table
{
	char filename[16];
	long int size;
	int fat_index;
	int ufid;
}dir_table[100];

//FAT table made on a two-dimensional array
int FAT[1000][2];

//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
short int free_blocks[1000];

//file directory table made static which means that 10 files maximum can be opened at the same time
int fdTable[10][2];


#endif

#ifndef DIR_SERVICE_H
#define DIR_SERVICE_H


int my_create(const char *filename);	//creates a new file with name filename with zero size.If it exits a file with the same filename, then this function
					//zeros it's size.
					//Ruturns 0 on success


int my_open(const char *FileName);	//opens a new file with the name filename for reading and/or writing and returns it's ufid
					//ufid is always a positive number.

int my_files(char ***filenames);	//returns the pointer to a two dimensional array which contains the directory contents(all the files)

int my_delete(const char *filename);	//deletes an existing file with the name filename


#endif

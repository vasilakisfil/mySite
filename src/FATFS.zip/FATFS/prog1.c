#include "global.h"
#include "dir_service.h"
#include "file_service.h"
#include "service_block.h"
#include "mountingFS.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
	/******************************************************************* allocations ***************************************************************/
/*
	int num_blocks,pos_blocks,i,j;
	int *bitmap;
	int index;

	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];*/


	char file[]="my_file";
	int ufid;
	char temp[100],temp2[50];

	mountFS();

	my_create(file);
	ufid=my_open(file);
	
	fgets(temp,sizeof temp,stdin);
	printf("%s\n\n\n",temp);

	my_write(ufid,temp,strlen(temp),0);
	my_close(ufid);

	ufid=my_open(file);
	my_write(ufid,temp2,sizeof temp2,0);
	
	printf("%s\n",temp2);
	my_close(ufid);

	return 0;

}
	

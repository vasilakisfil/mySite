/***********************************************************************
*			The File service
*
***********************************************************************/

#include "global.h"
#include "dir_service.h"
#include "service_block.h"
#include "file_service.h"

//here it is not used yet the pos varaible..
int my_write(int ufid,char *buf,int num,int pos)
{

	/******************************************************************* allocations ***************************************************************/

	int num_blocks,pos_blocks,i,j,pos_=pos;
	int *bitmap;
	int index;

	//the file descriptor
	//int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];






	/**********************													***********************/

	printf("buf: %snum:%d\tpos:%d\n",buf,num,pos);

	//if the position is other than zero(means that the my_write function has to write from pos pos byte until pos+num byte)
	if(pos!=0)
	{

		pos_blocks=pos/4;
		pos_=pos%4;
		printf("%d   %d\n",pos_blocks,pos_);
		//to find the position
		/*if((double)pos/4==(int)pos/4)
		{
			pos_blocks=pos/4;
		}
		else	pos_blocks=num/4+1;*/
	}

	//finding the ufid of the file on the File Descriptor Table
	for(i=0; i<10; i++)
	{
		if(fdTable[i][0]==ufid)
		{
			index=fdTable[i][1];
		}
	}


	//to get how many blocks we will need...
	if(pos!=0)
	{
		if((double)num/4==(int)num/4)
		{
			num_blocks=num/4;
		}
		else	num_blocks=num/4+1;
		//num_blocks=3;
	}
	else
	{
		if((double)num/4==(int)num/4)
		{
			num_blocks=num/4;
		}
		else	num_blocks=num/4+1;
	}

	bitmap=(int *) malloc(num_blocks*sizeof(int));
	
	//if pos is not zero the index is not on the first position of the file in the FAT array 
	if(pos!=0)
	{
		int temp=0;
		for(i=0; i<pos_blocks; i++)
		{
			index=FAT[index][1];
			if(index==-2)
			{
				if(pos_==0)
				{
					for(j=0; j<1000; j++)
					{
						if(free_blocks[j]==1)
						{
							free_blocks[j]=0;
							break;
						}
					}
					FAT[temp][1]=j;
					FAT[j][0]=j;
					index=j;
				}
				else if(pos_!=0)
				{
					index=temp;
				}
			}
			temp=index;
		}
	}

	printf("index: %d\n", index);

	
	//entering the first position by my_create
	bitmap[0]=FAT[index][0];	// =index;
	
	//j=1
	j=1;
	//we find which blocks are availiable and store them on an array and marking them on the Free Block array as used...
	for(i=0; i<1000; i++)
	{
		if(free_blocks[i]==1)
		{
			bitmap[j]=i;
			free_blocks[i]=0;
			j++;
		}
		if(j==num_blocks)
		{
			bitmap[j]=-2;
			free_blocks[i]=0;
			break;
		}
	}			

	//allocating the FAT table
	for(i=0; i<num_blocks; i++)
	{
		FAT[bitmap[i]][0]=bitmap[i];
		FAT[bitmap[i]][1]=bitmap[i+1];
	}

	//writing the disk
	j=0;
	if(pos_!=0)
	{
		put_block(bitmap[0],buf,pos_);
		j+=pos_;
		for(i=1; i<num_blocks; i++)
		{
			printf("-->%s\t %d\n",buf+j,bitmap[i]);
			put_block(bitmap[i],buf+j,0);
			j=j+4;
		}
	}
	else
	{
		for(i=0; i<num_blocks; i++)
		{
			printf("-->%s\t %d\n",buf+j,bitmap[i]);
			put_block(bitmap[i],buf+j,pos_);
			j=j+4;
		}
	}

	for(i=0; i<100; i++)
	{
		if(dir_table[i].ufid==ufid)
		{
			dir_table[i].size=dir_table[i].size+strlen(buf);
		}
	}
	


	return 0;
}

//funtion that closes an open file(deletes it's entry from the fdTable)
int my_close(int ufid)
{

	/******************************************************************* allocations ***************************************************************/
	
	int i;

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];

	/********************************************								****************************************/

	for(i=0; i<10; i++)
	{
		if(fdTable[i][0]==ufid)
		{
			fdTable[i][0]=-1;
			fdTable[i][1]=-2;
			break;
		}
	}

	return 0;
}






//here it is not used yet the pos varaible..
int my_read(int ufid,char *buf,int num,int pos)
{

	/******************************************************************* allocations ***************************************************************/

	int num_blocks,pos_blocks,i,j;
	int index;

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];






	/**********************													***********************/

	//printf("%d   %d\n",ufid,num);

	//if the position is other than zero(means that the my_write function has to write from pos pos byte until pos+num byte
	if(pos!=0)
	{

		pos_blocks=pos/4;
		pos=pos%4;
		printf("%d   %d\n",pos_blocks,pos);
		//to find the position
		/*if((double)pos/4==(int)pos/4)
		{
			pos_blocks=pos/4;
		}
		else	pos_blocks=num/4+1;*/
	}

	//finding the ufid of the file on the File Descriptor Table
	for(i=0; i<10; i++)
	{
		if(fdTable[i][0]==ufid)
		{
			index=fdTable[i][1];
			//printf("index:-----------> %d\n",index);
			break;
		}
	}


	//to get how many blocks we will need...
	if((double)num/4==(int)num/4)
	{
		num_blocks=num/4;
	}
	else	num_blocks=num/4+1;

	//printf("Num of blocks %d", num_blocks);

	//if pos not zero, we find the exact position to read from
	if(pos!=0)
	{
		
		for(i=0; i<pos_blocks; i++)
		{
			
			index=FAT[index][1];
			//printf("%d   ",index);
		}
	}

	//creating an array that it will hold all the positions of the FAT table the file has allocated on the past..
	int FATindex[num_blocks];

	j=index;
	for(i=0; i<num_blocks; i++)
	{
		FATindex[i]=j;
		j=FAT[j][1];
		//printf("j: %d\n",j);
	}

	j=0;
	for(i=0; i<num_blocks; i++)
	{
		//reading from the disk to the *buf
		get_block(FATindex[i],buf+j,pos);
		j+=4;
	}


	printf("\n%s",buf);



	return 0;
}




int my_file_size(int ufid)
{

	/******************************************************************* allocations ***************************************************************/

	int size=-1,i;

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	extern int fdTable[10][2];


	/**********************													***********************/

	for(i=0; i<100; i++)
	{
		if(dir_table[i].ufid==ufid)
		{
			size=dir_table[i].size;
		}
	}

	return size;
}


































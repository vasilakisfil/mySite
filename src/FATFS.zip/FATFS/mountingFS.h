#ifndef MOUNTINGFS_H
#define MOUNTINGFS_H



int mountFS(void);		//function that mounts the filesystem: copys the data structures from the hard drive disk to the memory

int unmountFS(void);		//function that unmounts the filesystem: writes the data structures from the memory to the hard drive disk

int test1FS(void);		//function that does a small test on the filesytesm :-)

int print_all(void);		//function that prints all the data strunctures

int my_df(void);		//function that prints the filesystem's informations



#endif

/*************************************************************************************************
*	Functions that handles the blocks of the disk/filesystem
*
**************************************************************************************************/


/*The service block will handle the filesystem's space...

Ta sxolia auta 8a grafoun sta ellhnika kai 8a svhstoun...
Kat'arxhn na ta paroume me th seira..
O xrhsths pataei my_echo > myfile kai meta eisagei to keimeno.Auto to keimeno 8a prepei na apo8hkeutei mesa sto filesystem mas,se diaforetika block mias kai
pros to parwn to ka8e block einai 4 bytes..As poume oti to keimeno einai 10 bytes.Auto shmainei oti 8a xreias8oun 2*4 bytes + 2 bytes sunolo 3 blocks..
Epomenws amesws meta pou eishgage o xrhsths to keimeno tou,auto apo8hkeuetai ston pinaka dunamika kai sthn sunexeia diaireitai me to mege8os pou exei oris8ei na einai to block(4 bytes) gia na vgei apotelesma posa blocks 8a xrhsimopoih8oun(3).Sth sunexeia elegxoume prwta an uparxei o eleu8eros xwros gia ta 3 blocks.
Efososn uparxei pername se enan pinaka tis 8eseis twn 3 eleu8erwn 8eswn,meta pame ston FAT table kai eisagoume stis antistoixes 8eseis sthn prwth sthlh thn 
8esh tou block kai sthn deuterh 8esh thn 8esh tou FAT tou epomenou stoixeiou....Sth sunexeia pame sto Directory table eisagoume ws onoma to myfile pou
eishgage o xrhsths,size to mege8os tou arxeiou,FAT index thn 8esh tou prwtou block ston FAT pinaka kai ufid ton ari8mo tou pinaka tou struct directory
service...*/

#include "global.h"
#include "service_block.h"




//function whick handles the block service
/********************************				private use only			**************************************************/
int block_service(char *file)
{
	int flag=1;
	int i,j;
	int size,num_blocks;
	//double size_d;
	int *bitmap;

	//printf("--------> %s\n", file);


	/******************************************************************* allocations ***************************************************************/

	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];





	printf("%s\n",file);

	size=strlen(file);
	//size_d=size/4;

	//to get how many blocks we will need...
	if((double)size/4==(int)size/4)
	{
		num_blocks=size/4;
	}
	else	num_blocks=size/4+1;

	printf("%d\n",num_blocks);

	bitmap=(int *) malloc(size*sizeof(int));

	j=0;
	for(i=0; i<1000; i++)
	{
		if(free_blocks[i]==1)
		{
			bitmap[j]=i;
			free_blocks[i]=0;
			j++;
		}
		if(j==num_blocks)
		{
			bitmap[j]=-2;
			flag=0;
			break;
		}
	}

	for(i=0; i<=j; i++)
	{
		printf("%d",bitmap[i]);
	}

	for(i=0; i<num_blocks; i++)
	{
		FAT[bitmap[i]][0]=bitmap[i];
		FAT[bitmap[i]][1]=bitmap[i+1];
	}

	//opening the file of the filesystem (Write Only mode-access by everyone) in order to copy the data structures to the memory
	fd=open(filename,O_WRONLY);
	int seek;
	lseek(fd,sizeof dir_table,SEEK_SET);
	lseek(fd,sizeof FAT,SEEK_CUR);
	seek=lseek(fd,sizeof free_blocks,SEEK_CUR);

	//printf("the seek is %d\n", seek);

	for(i=0; i<num_blocks*4; i=i+4)
	{
		write(fd,file+i,4);
		printf("%d ",i);
	}

	lseek(fd,sizeof dir_table,SEEK_SET);
	strcpy(dir_table[0].filename,"text.txt");
	dir_table[0].size=size;
	dir_table[0].fat_index=0;
	dir_table[0].ufid=0;

	close(fd);

	return flag;
}

//te first version of my_cat...
/********************************				private use only			**************************************************/
int cat_file(char *file)
{
	int i,j;
	int size,num_blocks;
	char file_cat[100];

	printf("-------------->%s\n", file);

	/******************************************************************* allocations ***************************************************************/

	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	printf("Filename: %s\n",dir_table[0].filename);
	printf("Size: %ld\n",dir_table[0].size);
	printf("Fat index: %d\n",dir_table[0].fat_index);
	printf("Ufid: %d\n\n\n",dir_table[0].ufid);
	
	size=dir_table[0].size;
	//to get how many blocks we will need...
	if((double)size/4==(int)size/4)
	{
		num_blocks=size/4;
	}
	else	num_blocks=size/4+1;


	fd=open(filename,O_RDONLY);

	int seek;
	lseek(fd,sizeof dir_table,SEEK_SET);
	lseek(fd,sizeof FAT,SEEK_CUR);
	seek=lseek(fd,sizeof free_blocks,SEEK_CUR);

	printf("the seek is %d\n", seek);

	//lseek(fd,4,SEEK_CUR);
	j=0;
	for(i=0; i<num_blocks; i++)
	{
		read(fd,file_cat+j,4);
		//printf("%d ",i);
		j=j+4;
	}

	printf("%s\n\n",file_cat);

	close(fd);

	return 0;

}

//function that reads from the *buffer and writes it on the blockptr block of the disk/filesystem
int put_block(int blockptr,char *buffer,int position)
{

	/******************************************************************* allocations ***************************************************************/
	
	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	/************************************************************ writing to filesystem ************************************************************/

	//opening the file of the filesystem (Write Only mode-access by everyone) in order to copy the data structures to the memory
	fd=open(filename,O_WRONLY);
	int seek;
	lseek(fd,sizeof dir_table,SEEK_SET);
	lseek(fd,sizeof FAT,SEEK_CUR);
	lseek(fd,sizeof free_blocks,SEEK_CUR);

	seek=lseek(fd,4*(blockptr)+position,SEEK_CUR);

	//printf("%d\n",blockptr);

	write(fd,buffer,4-position);
	//printf("------------>%d   %s",seek,buffer);

	close(fd);
	
	return 0;
}


//function that reads from the blockptr block of the disk/filesystem and writes it on the *buffer array
int get_block(int blockptr,char *buffer,int position)
{

	/******************************************************************* allocations ***************************************************************/
	
	//the file descriptor
	int fd;
	//the filename of our filesystem
	extern char *filename;
	filename=(char *)malloc(strlen("ceidFS"));
	strcpy(filename,"ceidFS");

	//directory table made on a struct
	extern struct directory_table dir_table[100];

	//FAT table made on a two-dimensional array
	extern int FAT[1000][2];

	//free block list made on an array but declared as a short integer since we will insert only 0 or 1 (we still waste space though :P)
	extern short int free_blocks[1000];

	/************************************************************ writing to filesystem ************************************************************/

	//opening the file of the filesystem (Write Only mode-access by everyone) in order to copy the data structures to the memory
	fd=open(filename,O_RDONLY);
	int seek;
	lseek(fd,sizeof dir_table,SEEK_SET);
	lseek(fd,sizeof FAT,SEEK_CUR);
	lseek(fd,sizeof free_blocks,SEEK_CUR);

	seek=lseek(fd,4*(blockptr)+position,SEEK_CUR);

	//printf("%d\n",blockptr);

	read(fd,buffer,4);
	//printf("------------>%d   %s",seek,buffer);

	close(fd);
	
	return 0;
}









































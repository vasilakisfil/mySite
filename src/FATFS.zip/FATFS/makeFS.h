#ifndef STRUCTURES_H
#define STRUCTURES_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <string.h>
#include <sys/stat.h>

int create_filesystem(int num_of_blocks,int size_of_blocks);		//Function which creates the filesystem and does all th initializations




#endif

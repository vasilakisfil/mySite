/******************************************************************************************************
*		Header file which contains the functions' definitions..
*
*******************************************************************************************************/

void Idle();
void Periodic(int value);
void vecmat4(GLdouble *vec, GLdouble *mat, GLdouble *res);
void matmat4(GLdouble *matA, GLdouble *matB, GLdouble *res);
double computeDistance(double x1, double y1, double z1, double x2, double y2, double z2);
void initJacobi();
void drawCube(GLdouble xcenter, GLdouble ycenter, GLdouble zcenter, int index);
void updateTemps();
int moveSource();
void RenderScene(void);
void SetupRC();
void SpecialKeys(int key, int x, int y);
void NormalKeys(unsigned char key, int x, int y);
void ChangeSize(int w, int h) ;
void usage(const char *prog);
void jacobi(void *arg);
int initialize_threads();void *thread_function(void *arg);
int count_processors(void);
int initialize_struct(void);
void *jacobi_start(void *arg);

/*#include <stdio.h>
#include <unistd.h>*/

int count_processors(void)
{
	#if defined(unix) || defined(__unix__)
		# if defined(__bsd__)
			int num, mib[] = {CTL_HW, HW_NCPU};
			size_t len = sizeof num;
			sysctl(mib, 2, &num, &len, 0, 0);
			return num;
		# elif defined(__sgi)
		return sysconf(_SC_NPROC_ONLN);
		# else
		return sysconf(_SC_NPROCESSORS_ONLN);
		# endif
	#elif defined(WIN32) || defined(__WIN32__)
		SYSTEM_INFO info;
		GetSystemInfo(&info);
		return info.dwNumberOfProcessors;
	#endif
}



/*int main(void)
{

	printf("%d\n", count_processors());

	return 0;

}*/

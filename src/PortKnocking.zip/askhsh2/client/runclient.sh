#Shell script that runs server with prespecified ports

#clear shell
clear
#if make was also typed compile them all :D
if [ "$1" == "make" ] ; then
	cd ..
	make
#else if classic was typed then run client with the default port sequence
elif [ "$1" == "classic" ] ; then
	./client 5000 5001 5002 5003 5004	#edit here if you want to change the default sequence
#else run server with the arguments given
else
	./client $1 $2 $3 $4 $5 $6 $7
fi

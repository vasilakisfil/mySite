/*******************************************************************************************************************
*			Arxeio pou periexei thn main sunarthsh tou client ka8ws kai tis voh8htikes
*			sunarthseis.Protimhsame na ta valoume ola se ena arxeio for the sake of
*			readability
*
*******************************************************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

//sunarthsh pou dhmiourgei to socket
void do_socket(void);
//sunarthsh pou ektelei thn akolou8eia ping-pong
void do_pingpong(int port);
//sunarthsh pou ektelei thn akolou8eia ping-welcome
void do_pingwelcome(int port);

//metavlhth i gia ta loops kai error gia ton elegxo twn timwn pou epistrefoun ta system calls
int i,error;
//pinakas pou krataei to munhma "ping"
char temp_pong[10];
//pinakas pou krataei to munhma "pong"
char temp_ping[10];
//pinakas pou krataei to munhma "welcome"
char temp_welcome[10];
//to socket descriptor
int sockfd_cl;
//domh tupou sockaddr tou server
struct sockaddr_in servin;
//metavlhth pou krataei to mege8os tou struct tou server
socklen_t servin_size=sizeof servin;
//metavlhth pou krataei ton ari8mo ton pings
int ping_cnt;
//metavlhth pou krataei ton ari8mo ton pongs
int pong_cnt;

//h main sunarthsh tou client
int main(int argc, char *argv[])
{

	//pinakas pou krataei tis parametrous pou do8hkan
	int arg_num[argc];

	/////////////////////////////////////////////////////////
	///////////arxikoioume to struct tou server//////////////
	/////////////wste na ginei h epikoinwnia/////////////////
	/////////////////////////////////////////////////////////
	//IPv4 internet domain
	servin.sin_family=AF_INET;
	////arxikopoioume to port casted se network byte order
	servin.sin_port=htons(5000);
	//h dieu8unhsh IP tou server
	servin.sin_addr.s_addr=inet_addr("127.0.0.1");

	//arxikopoioume MONO to temp_ping pou 8a stelnei o client ston server
	memcpy(temp_ping,"ping",strlen("ping")+1);
	//arxikopoioume ton counter pou metraei ta pingpongs
	ping_cnt=1;
	pong_cnt=1;

	/********************************************************************************************************/


	printf("Ports that client will attempt connections:\n");
	//ena for loop pou ektupwnei ta ports pou exei dwsei o xrhsths opou akouei o server
	for(i=1; i<argc; i++)
	{
		printf("Port %d:%s\n", i,argv[i]);
		//metatrepoume to char * argument se integer wste na mporoume na to xeiragwghsoume
		arg_num[i]=atoi(argv[i]);
	}


	//ena for loop pou kanei pingpong oles tis portes pou dw8hkan stous parametrous(ektos ths teleutaias)
	for(i=1; i<=argc-2; i++)
	{
		//kaloume thn sunarthsh do_pingpong gia na ektelestei
		//h akolou8eia ping-pong se udp socket
		do_pingpong(arg_num[i]);
	}

	//kaloume thn sunarthsh do_pingwelcome gia na ektelestei h 
	//akoul8eia ping-welcome se tcp port
	do_pingwelcome(arg_num[argc-1]);


	return 0;

}

//sunarthsh pou dhmiourgei to socket
void do_socket(void)
{
	//dhmiourgoume to socket ws connectionless(aka udp)
	sockfd_cl=socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd_cl==-1)	
	{
		perror("socket");
		exit(-1);
	}
	printf("Socket opened.\n");

	return;
}

/*****************************************************************************
*	sunarthsh pou kanei thn akolou8ia: allazei port, kalei thn socket(),
*	stelnei "ping", lamvanei "pong" kai kleinei to socket
*****************************************************************************/
void do_pingpong(int port)
{
	//allazoume to port
	servin.sin_port=htons(port);

	//ka8usteroume ton cient gia 1 deuterolepto wste na
	//prolavei o server na ektelesei prwta thn recvfrom
	sleep(1);

	//dhmiourgoume to socket
	do_socket();


	//stelnoume ping ston server
	error=sendto(sockfd_cl,temp_ping,sizeof(temp_ping),0,(struct sockaddr *) &servin,sizeof(servin));
	if(error==-1)
	{
		perror("sendto");
		exit(-1);
	}
	printf("Sended %s %d message from server\n",temp_ping,ping_cnt);
	ping_cnt++;

	//lamvanoume pong apo ton server
	error=recvfrom(sockfd_cl,temp_pong,sizeof(temp_pong),0,(struct sockaddr *) &servin,&servin_size);
	if(error==-1)
	{
		perror("recvfrom");
	}
	else
	{
		//ektupwnoume to munhma
		printf("Received %s %d message from server\n",temp_ping,pong_cnt);
		pong_cnt++;
	}

	//kleinoume to socket
	close(sockfd_cl);
	
	return;
}


/*****************************************************************************
*	sunarthsh pou kanei thn akolou8ia: allazei port, kalei thn socket(),
*	stelnei "ping", lamvanei "welcome" kai kleinei to socket
*****************************************************************************/
void do_pingwelcome(int port)
{
	//allazoume to port
	servin.sin_port=htons(port);

	//ka8usteroume ton cient gia 1 deuterolepto wste na
	//prolavei o server na ektelesei prwta thn recvfrom
	sleep(1);

	//dhmiourgoume ena TCP socket
	sockfd_cl=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd_cl==-1)	
	{
		perror("socket");
		exit(-1);
	}
	printf("TCP socket opended.\n");

	//sundeomaste sto socket
	error=connect(sockfd_cl,(struct sockaddr *) &servin, servin_size);
	if(error==-1)
	{
		perror("connect");
		exit(-1);
	}
	printf("Connection was established.\n");

	//grafoume(opws se ena arxeio) sto socket to "ping"
	error=write(sockfd_cl,temp_ping,sizeof(temp_ping));
	if(error<0)
	{
		perror("write");
		exit(-1);
	}
	printf("Sended %s %d message from server\n",temp_ping,ping_cnt);
	ping_cnt++;

	//diavazoume(opws apo ena arxeio) apo to socket to "welcome"
	error=read(sockfd_cl,temp_welcome,sizeof(temp_welcome));
	if(error<0)
	{
		perror("read");
		exit(-1);
	}
	
	//ektupwnoume to welcome munhma pou mas esteile o server :D
	printf("Received %s %d message from server\n",temp_welcome,pong_cnt);
	pong_cnt++;

	printf("\nClient successfully completed the port knocking.\n");

	//kleinoume to socket :'(
	close(sockfd_cl);
	
	return;
}


/********************************************************************************************************************************
*			To arxeio periexei to main loop tou server.Oi upoloipes sunarthseis
*			exoun ulopoih8ei se diaforetika arxeia for the sake of readability
*
********************************************************************************************************************************/



//ta aparaithta includes
#include "global.h"
#include "functions.h"

//sunarthsh pou pianei to singal otan termatizei ena paidi
void sig_child(int signo);
//sunarthsh pou pianei to signal pou stelnetai apo thn alarm()
//void alarming(int signo);

//h main sunarthsh tou server
int main(int argc, char *argv[])
{
	//pinakas pou krataei tis parametrous pou do8hkan
	int arg_num[argc];
	//metavlhth pou xreiazetai gia to fork
	int childpid;

	//flush it !
	fflush(NULL);

	//This functionmakes the parent to ignore the SIGCHLD signal
	signal(SIGCHLD, sig_child);
	//signal(SIGALRM, alarming);


	printf("Ports that server listens:\n");
	//ena for loop pou ektupwnei ta ports pou exei dwsei o xrhsths gia na akouei o server
	for(i=1; i<argc; i++)
	{
		printf("Port %d:%s\n", i,argv[i]);
		//metatrepoume to char * argument se integer wste na mporoume na to xeiragwghsoume
		arg_num[i]=atoi(argv[i]);
	}

	//atermon loop
	for( ; ; )
	{

		//kanoume tis aparaithtes arxikopoihseis
		initialization(arg_num[1]);
		
		//dhmiourgeitai to socket
		do_UDPsocket();

	
		//kleidwnoume to socket
		do_bind();


		//lamvanoume ping apo ton client
		error=recvfrom(sockfd,temp_ping,sizeof(temp_ping),0,(struct sockaddr *) &clin,&clin_size);
		if(error==-1)
		{
			perror("recvfrom");
		}
		else
		{
			inet_ntop(AF_INET,(void *) &clin.sin_addr.s_addr, client_addr, INET_ADDRSTRLEN);
			//dhmiourgoume me to fork ena paidi pou 8a e3uphrethsei ton kainourgio client
			childpid=fork();
			//o pateras sunexizei na akouei alla connection
			if(childpid!=0)
			{
				//kleinei to socket afou den to xreiazetai pleon
				close(sockfd);
				//piss off
				continue;
			}
			else
			{
				printf("Received %s %d message from client %s.\n",temp_ping,ping_cnt,client_addr);
				ping_cnt++;
				//stelnoume pong ston client
				error=sendto(sockfd,temp_pong,sizeof(temp_pong),0,(struct sockaddr *) &clin,clin_size);
				if(error==-1)
				{
					perror("sendto");
					exit(-1);
				}
				printf("Sended %s %d message to client %s.\n",temp_pong,pong_cnt,client_addr);
				pong_cnt++;
			}
			//ena for loop pou kanei pingpong oles tis portes pou dw8hkan stous parametrous(ektos ths teleutaias)
			for(i=2; i<=argc-2; i++)
			{
				//kaloume thn sunarthsh do_pingpong gia na ektelestei
				//h akolou8eia ping-pong se udp socket
				do_pingpong(arg_num[i]);
			}
			//kaloume thn sunarthsh do_pingwelcome gia na ektelestei h 
			//akoul8eia ping-welcome se tcp port
			do_pingwelcome(arg_num[argc-1]);
		}
		//to paidi termatizei
		exit(0);
	}
	

	return 0;
}

//sunarthsh pou xeirizetai to signal SIGCHLD
void sig_child(int signo)
{
	//metavlhth pou krataei to process id pou termatizei
	pid_t pid;
	int stat;

	printf("SIGCHLD signal raised\n");
	while( (pid=waitpid(-1, &stat, WNOHANG)) > 0)
	{
		//ektupwnetai to process id kai h dieu8unsh tou client
		printf("Child %d and client %s terminated.\n", pid, client_addr);
	
	}

	return;
}

/*void alarming(int signo)
{
	printf("SIGALRAM signal raised\n");
	printf("Client with address %s did wrong port knocking\n", inet_ntop(AF_INET,(void *) &clin.sin_addr.s_addr, last_client, INET_ADDRSTRLEN));
	exit(1);
	return;
}*/




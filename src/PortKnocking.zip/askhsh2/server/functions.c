/********************************************************************************************************************
*			Auto to arxeio periexei tis voh8htikes sunarthseis tou server
*
********************************************************************************************************************/


#include "global.h"
#include "functions.h"

void initialization(int port)
{

	//servin =(struct sockaddr_in *) malloc(sizeof(struct sockaddr_in));
	/////////////////////////////////////////////////////////
	///////////arxikoioume to struct tou server//////////////
	/////////////wste na ginei h epikoinwnia/////////////////
	/////////////////////////////////////////////////////////
	//IPv4 internet domain
	servin.sin_family=AF_INET;
	//arxikopoihsh tou port pou akouei casted se network byte order
	servin.sin_port=htons(port);
	//na dexetai oles tis sundeseis apo ka8e computer interface
	servin.sin_addr.s_addr=htonl(INADDR_ANY);

	//arxikopoioume ton temp_pong pou 8a stelnei o server sto client
	memcpy(temp_pong,"pong",strlen("pong")+1);
	//arxikopoioume ton temp_welcome pou 8a stelnei o server sto client
	memcpy(temp_welcome,"welcome",strlen("welcome")+1);

	//metavlhth pou krataei to mege8os tou struct pou periexei th dieu8unsh tou client
	clin_size=sizeof clin;
	//metavlhth pou krataei to mege8os tou struct pou periexei th dieu8unsh tou server
	servin_size=sizeof(struct sockaddr_in);
	//counter pou metraei ta ping pongs pou exoun antallagei
	ping_cnt=1;
	pong_cnt=1;

	return;
}

//sunarthsh dhmiourgei to socket
void do_UDPsocket(void)
{	
	//dhmiourgoume connectionless socket (aka udp)
	sockfd=socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd==-1)	
	{
		perror("socket");
		exit(-1);
	}
	printf("Udp socket opened.\n");

	return;
}

void do_TCPsocket(void)
{	
	//dhmiourgoume connectionless socket (aka tcp)
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd==-1)	
	{
		perror("socket");
		exit(-1);
	}
	printf("TCP socket opened.\n");

	return;
}

//sunarthsh pou kleidwnei to socket
void do_bind(void)
{

	/************auto den 3erw ti kanei***sto forum mou to dwsan kai epai3e mpompa***credits @ mitsakosc*************/
	int on = 1; 
	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&on, sizeof(on)) < 0) 
        { 
            printf("setsockopt() failed\n"); 
            exit(-1); 
        }
	//kaloume to bind
	error=bind(sockfd,(struct sockaddr *) &servin,servin_size);
	if(error==-1)
	{
		printf("We ve got major problem\n");
		perror("bind");
		exit(-1);
	}

	printf("Socket binded.\n");

	return;
}

//Listen clients requests
void do_listen(void)
{
	//vazoume ws oura tou listen 5 clients to megisto
	error=listen(sockfd,5);
	if(error==-1)
	{
		perror("listen");
		exit(-1);
	}
	printf("Socket listens for connections.\n");

	return;
}


/*****************************************************************************
*	sunarthsh pou kanei thn akolou8ia: allazei port, kalei thn socket(),
*	kalei thn bind(), lamvanei "ping" stelnei "pong" kai kleinei to socket
*****************************************************************************/
void do_pingpong(int port)
{
	//agreed port casted in network byte order
	servin.sin_port=htons(port);

	//kaloume thn socket()
	do_UDPsocket();

	//kaloume thn bind()
	do_bind();
	
	/*
	 * Sunarthsh pou elegxei an o client exei stelnei sto swsto port.Douleuei ws e3hs:
	 * an den ananew8ei to alarm(5) dhladh den 3anatre3ei to alarm tote
	 * o client shmainei oti stelnei se la8os port 'h ot o client pai8ane.Tote
	 * meta apo 5 deuterolepta h alarm() stelnei SIGALRM kai h sunarthsh sig_alarming
	 * xeirizetai to signal opou termatizei to paidi kai anaferei poios client apetuxe
	 * na kanei port knocking.Den xrhsimopoieitai logw ekfwnhshs :D
	 */	
	//alarm(5);
	
	//lamvanoume "ping" apo ton client
	error=recvfrom(sockfd,temp_ping,sizeof(temp_ping),0,(struct sockaddr *) &clin,&clin_size);
	if(error==-1)
	{
		perror("recvfrom");
	}
	else
	{
		//ektupwnoume to "ping" + ton ari8mo pingpong
		printf("Received %s %d message from client %s.\n",temp_ping,ping_cnt,client_addr);
		//au3anoume ton counter
		ping_cnt++;
	}
	//stelnoume "pong" ston client
	error=sendto(sockfd,temp_pong,sizeof(temp_pong),0,(struct sockaddr *) &clin,clin_size);
	if(error==-1)
	{
		perror("sendto");
		exit(-1);
	}
	printf("Sended %s %d message to client %s.\n",temp_pong,pong_cnt,client_addr);
	pong_cnt++;

	//kleinoume to socket
	close(sockfd);

	return;
}

/***************************************************************************
*	sunarthsh pou kanei thn akolou8ia: allazei port, kalei thn socket(),
*	kalei thn bind(), kalei thn listen kai kanei accept mexri na tou er8ei
*	kapoio connection kai na lavei "ping" opou meta stelnei "welcome" ston
*	client kai kleinei to socket
***************************************************************************/
void do_pingwelcome(int port)
{
	//agreed port casted in network byte order
	servin.sin_port=htons(port);

	//dhmiourgoume to socket se TCP mode
	do_TCPsocket();

	//kaloume thn bind
	do_bind();

	//kanoume to socket na "akouei"
	do_listen();

	/* Edw perimenei o server ton client na tou steilei kapoio xarakthra
	 * Epeidh h accept mporei na diakopei apo kapoio allo interrupt 8a prepei
	 * na thn kanoume emeis na sunexisei.8a mporouse na ginei kai me ena
	 * while(TRUE) alla protimh8hke h goto.
	 *
	 */
	AGAIN:
	new_sockfd=accept(sockfd,(struct sockaddr *) &clin,&clin_size);
	if(errno==EINTR)
	{
		goto AGAIN;
	}
	if(new_sockfd==-1)
	{
		perror("accept");
		strerror(new_sockfd);
		exit(-1);
	}
	
	
	//lamvanoume "ping" apo ton client
	error=read(new_sockfd,temp_ping,sizeof(temp_ping));
	if(error<0)
	{
		perror("read");
		exit(-1);
	}
	printf("Received %s %d message from client %s.\n",temp_ping,ping_cnt,client_addr);
	ping_cnt++;

	//stelnoume "pong" ston client
	error=write(new_sockfd,temp_welcome,sizeof(temp_welcome));
	if(error<0)
	{
		perror("write");
		exit(-1);
	}
	printf("Sended %s %d message to client %s.\n",temp_welcome,pong_cnt,client_addr);
	pong_cnt++;

	printf("Port knocking was successfully completed!\n");
	//kleinoume ton socket descripor
	close(sockfd);

	return;
}


/***************************************************************************************************************
*			To arxeio auto periexei ola ta aparaithta includes ka8ws kai tis dhlwseis
*			twn metavlhtwn pou xrhsimopoiountai apo ton server
*
***************************************************************************************************************/

#ifndef GLOBAL_H
#define GLOBAL_H

#define TRUE	0
#define FALSE	-1

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <arpa/inet.h>



//metavlhth i gia ta loops kai error gia ton elegxo twn timwn pou epistrefoun ta system calls
int i,error;
//pinakas pou krataei to munhma "ping"
char temp_pong[10];
//pinakas pou krataei to munhma "pong"
char temp_ping[10];
//pinakas pou krataei to munhma "welcome"
char temp_welcome[10];

//to socket descriptor tou server
int sockfd;
int new_sockfd;
//domh gia thn dieu8unsh tou server
struct sockaddr_in servin;
//domh gia thn dieu8unsh tou client
struct sockaddr_in clin;
//metavlhtes pou kratan to mege8os ths ka8e struct
socklen_t servin_size;
socklen_t clin_size;

//metavlhth pou krataei ton teleutaio sundedemeno client pou apetuxe
//sto port knocking.den xrhsimopoieitai
char client_addr[100];

//metavlhth pou metraei ta pings
int ping_cnt;
//metavlhth pou metraei ta pongs
int pong_cnt;


#endif

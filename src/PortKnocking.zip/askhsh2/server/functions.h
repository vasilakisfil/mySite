/*************************************************************************************************************************
*			To arxeio auto periexei tous orismous twn voh8htikwn sunarthsewn tou server
*
*************************************************************************************************************************/


#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void initialization(int port);
void do_UDPsocket(void);
void do_TCPsocket(void);
void do_bind(void);
void do_listen(void);
void do_pingpong(int port);
void do_pingwelcome(int port);


#endif

/*orisoi gia tous typous dedomenwn. Pros8este tous dikous sas gia title, text, paragraphed text*/
#define IMAGE 1
#define TTITLE 2
#define RTEXT 3
#define PTEXT 4

#ifndef DOCDATA_H
#define DOCDATA_H

//Typoi dedomenwn gia ta images,titles,text kai paragraphed text...

char **images;
int img_count;

char **titles;
int title_count;

/*char titles1[100][1000];
int title1_count;*/

char **texts;
int text_count;

char **par_texts;
int par_t_count;


/*add_data: pros8etei dedomena stous pinakes. value einai h timh kai type einai o typos*/
void add_data(char *value, int type);

// print_all: ektypwnei oles tis plhrofories pou yparxoun sta structs..mporoume na th xrhsimopoihsoume gia debugging
void print_all(void);

/*init: arxikopoiei ta dedomena (kyriws deiktes)*/
void init(void);

/*buildsml: ftiaxnei to sml arxeio*/
void build_sml(void);
//o pinakas pou 8a perieixe ta monadika ids(gia na ginetai o elegxos) omws logw eleipshs xronou den ulopoih8hke plhrws
int *ids;
int *ids_type;


int id_count;
//int *ids=malloc(id_count*sizeof(int));


int i,j;
int AM1,AM2;
int AM3,AM4;



//h sunarthsh auth epistrefei ta monadika ids
int getid(int value);

//h sunarthsh auth elegxei an einai monadiko to id
int check(int value);

#endif

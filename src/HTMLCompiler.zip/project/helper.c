#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "helper.h"




//h add_data apo8hkeuei ta onomata twn image,titles ka8ws kai tis sumvoloseires twn text kai paragraphed text se dusdiastatous dunamikous pinakes
void add_data(char *value, int type)
{
	
	extern int img_count;
	extern char **images;
	extern int title_count;
	extern char **titles;
	extern int text_count;
	extern char **texts;
	extern int par_t_count;
	extern char **par_texts;

	//images    	dunamikh apo8hkeush twn filenames twn eikonwn
	if (type == IMAGE) {
		images[img_count] = malloc(strlen(value)+1);
		strcpy(images[img_count], value);
		img_count++;
	}
	
	//titles    	dunamikh apo8hkeush twn titlwn ths html (ousiastika einai mono enas kai monadikos)
	if (type == TTITLE) {
		titles[title_count] = malloc(strlen(value)+1);
		strcpy(titles[title_count], value);
		title_count++;


	}

	//texts	    	dunamikh apo8hkeush twn sumvoloseirwn pou den vriskontai se paragrafo
	if (type == RTEXT) {
		texts[text_count] = malloc(strlen(value)+1);
		strcpy(texts[text_count], value);
		text_count++;
	}

	//Paragraphed texts	dunamikh apo8hkeush twn sumvoloseirwn pou vriskontai se paragrafo
	if (type == PTEXT) {
		par_texts[par_t_count] = malloc(strlen(value)+1);
		strcpy(par_texts[par_t_count], value);
		par_t_count++;
	}
}	


//h sunarthsh auth xrhsimopoieitai gia debugging..ektypwnei ola ta dedomena pou uparxoun stous pinakes.
void print_all(void)
{
	int i;

	printf("Data on the Data Structs:\n");

	printf("titles:\n");
	for(i=0; i<title_count; i++)
	{
		printf("\t%s\n", titles[i]);
	}

	printf("texts:\n");
	for(i=0; i<text_count; i++)
	{
		printf("\t%s\n", texts[i]);
	}

	printf("paragraphed texts:\n");
	for(i=0; i<par_t_count; i++)
	{
		printf("\t%s\n", par_texts[i]);
	}

	printf("images: \n");
	for (i=0; i < img_count; i++) {
		printf("\t%s\n", images[i]);
	}
}

//h void init() arxikopoiei tous deiktes twn pinakwn pou xrhsimopoiountai sthn add_data(), ka8ws epishs desmeuei mnhmh gia tous pinakes
void init()
{
	//int i,j;


	images = (char **) malloc(sizeof(char *));
	img_count = 0;

	titles = (char **) malloc(sizeof(char *));
	title_count = 0;
	
	texts = (char **) malloc(sizeof(char *));
	text_count=0;

	par_texts = (char **) malloc(sizeof(char *));
	par_t_count=0;

	//mono 2 atoma sthn omada epomenws 2 am..den exei polu shmasia allwste afou o algori8mos ths get_id() dinei monadiko id
	AM1=3894; //kanoniko AM - 1  logw idiomorfias tou algori8mou mas
	AM2=3061; //kanoniko AM - 1  logw idiomorfias tou alggori8mou mas
	AM3=2*AM1; //=7788 AM3(den exei shmasia poios 8a einai o ari8mos tou AM3 arkei na exoume monadika id
	AM4=2*AM2; //=6120 AM4 omoiws

	id_count=6;
	ids = (int *) malloc(id_count*sizeof(int));
	ids_type = (int *) malloc(id_count*sizeof(int));
	
	//arxikopoihsh twn pinakwn
	id_count=4;
	ids[0]=AM1;
	ids_type[0]=1;
	ids[1]=AM2;
	ids_type[1]=2;
	ids[2]=AM3;
	ids_type[2]=3;
	ids[3]=AM4;
	ids_type[3]=4;

	

}

//h sunarthsh auth ousiastika ulopoiei thn glwssa sml afou exei teleiwsei o suntaktikos analuths kai exoun apo8hkeutei ola ta dedomena,diavazei tous pinakes
//kai dhmiourgei to output analogws
void build_sml(void)
{
	int i;
	printf("<sml>\n");

	//int l=365;

	//texts
	if(text_count)
	{
		printf("\t<text>\n");
		for(i=0; i<text_count; i++)
		{
			printf("\t\t<id = %d >", get_id(2));
			printf("%s\n", texts[i]);
		}
		printf("\t</text>\n");
	}

	//paragraphed text
	if(par_t_count)
	{
		printf("\t<paragraphedtext>\n");
		for(i=0; i<par_t_count; i++)
		{
			printf("\t\t<id = %d >", get_id(3));
			printf("%s\n", par_texts[i]);
		}
		printf("\t</paragraphedtext>\n");
	}
	
	/*IMAGES*/
	if (img_count) {
		printf("\t<images>\n");
		for(i=0; i<img_count; i++) {
			printf("\t\t<id = %d >", get_id(4));
			printf("%s\n", images[i]);
		}
		printf("\t</images>\n");
	
	}

	//titles
	if(title_count)
	{
		printf("\t<title>\n");
		for(i=0; i<title_count; i++)
		{
			printf("\t\t<id = %d >", get_id(1));
			printf("%s\n", titles[i]);
		}
		printf("\t</title>\n");
	}

	printf("</sml>\n");

	/*printf("-> %d\n", ids[0]);

	for(i=0; i<id_count; i++)
	{
		printf("---> %d\n",ids[i]);
	}*/

}






//h sunarthsh ayth epistrefei monadiko id...(update sthn version 2.0)
//O algori8mos leitourgei ws e3hs.Sthn arxh arxikopoihtai(apo thn init()) enas dunamikos pinakas me 4 8eseis pou periexei ta 4 am.Apo ekei kai pera ka8e
//8eloume kainourgio id analoga gia poio tupo dedomenwn to 8eloume ay3anoume to antistoixo am kata ena kai elegxoume an uparxei to neo id ston hdh uparxwn
//pinaka(check(int value).An uparxei tote au3anoume kata ena pali.Ayto ginetai mexri na vre8ei ena id pou den uparxei ston pinaka.
int get_id(int s)
{

	//titles
	if(s==1)
	{

		for( ; ; ){
			if(AM1==3894) break;
			
			if(check(AM1)){

			
				ids[id_count]=AM1;
				
				ids_type[id_count]=s;
				break;
			}
			else AM1++;
		}


		AM1++;

		id_count++;


		ids = (int *) realloc(ids,(id_count+1)*sizeof(int));
		ids_type = (int *) realloc(ids_type,(id_count+1)*sizeof(int));

		return AM1;

	}


	//text
	if(s==2)
	{

		

		for( ; ; ){
			if(AM2==3892) break;
		
			if(check(AM2)){
				ids[id_count]=AM2;
				ids_type[id_count]=s;
				break;
			}
			else AM2++;
		}

		AM2++;

		id_count++;
		ids = (int *) realloc(ids,(id_count+1)*sizeof(int));
		ids_type = (int *) realloc(ids_type,(id_count+1)*sizeof(int));

		
		return AM2;
	}


	//paragraphed text
	if(s==3)
	{

		for( ; ; ){
			if(AM3==7788) break;
			
			if(check(AM3)){
				ids[id_count]=AM3;
				ids_type[id_count]=s;
				break;
			}
			else AM3++;
		}

		AM3++;

		id_count++;
		ids = (int *) realloc(ids,(id_count+1)*sizeof(int));
		ids_type = (int *) realloc(ids_type,(id_count+1)*sizeof(int));


		return AM3;
	}




	//images
	if(s==4)
	{


		//ids[id_count-1]=AM4;
		//ids_type[id_count-1]=s;
		for( ; ; ){
			//printf("images--->%d\n", ids[id_count-1]);
			if(AM4==7784) break;
			if(check(AM4)){
				ids[id_count]=AM4;
				ids_type[id_count]=s;
				break;
			}
			else AM4++;
		}

		AM4++;

		id_count++;
		ids = (int *) realloc(ids,(id_count+1)*sizeof(int));
		ids_type = (int *) realloc(ids_type,(id_count+1)*sizeof(int));


		return AM4;
	}

	
	
}

int check(int value){

	int flag=1;

	for(i=0; i<id_count; i++)
	{
		if(ids[i]==value)
		{
			flag=0;
			//printf("found\n");
			break;
		}
	}
	if(flag) return 1;
	else return 0;

}

//including all the necessary files
#include "MillerRabin.h"
#include "global.h"

/************************************************
* Class constructor.In this function all private
* variables are initialized.Also rand function is
* seeded with local time.
*************************************************/
MillerRabin::MillerRabin()
{
	//initializing the array pointer to point on NULL
	this->array=NULL;
	//initializing the size of the array(not actually very usefull)
	this->SIZE=1;
	//initializing the two GMP variables of breakPower struct
	mpz_init(this->breakPower.t);
	mpz_init(this->breakPower.u);
	//seeding the rand function
	//srand(time(NULL));

	//initializing the GMP seeder
	gmp_randinit_default(state);
	//seeding the GMP random function
	gmp_randseed_ui(state,time(NULL));
}

/************************************************
* Class destructor.Not implemented.
*************************************************/
MillerRabin::~MillerRabin()
{
	free(array);
}


/************************************************
* This method converts an integer number into a
* binary number and stores every digit of it into
* the array after memory is allocated.It takes the
* number as an argument and returns the pointer to
* the first memory location.
*************************************************/
bool *MillerRabin::convIntBool(mpz_t number)
{
	//declaring and initializing the variables
	int temp,remainder=0;
	mpz_t temporary;
	mpz_init(temporary);

	//endless loop (it stops until the number<=1 after (word?) right shifts
	for(int i=0; ; i++ )
	{
		//if number<=1
		if((temp=mpz_cmp_d(number,1))<=0)
		{
			//reallocatin a little more space of size bool in memory
			this->array=(bool *) realloc(this->array,sizeof(bool[i+1]));
			//storing the number into the array
			this->array[i]=number;
			//storing the size of the array into the private variable
			this->SIZE=i+1;
			//get out of the loop!
			break;
		}
		else
		{
			//storing to temporary the result of number(mod2)
			mpz_mod_ui(temporary,number,2);
			//exporting GMP variable temporary to integer remainder
			remainder=mpz_get_ui(temporary);
			//reallocating a little more space of size bool in memory
			this->array=(bool *) realloc(this->array,sizeof(bool[i+1]));
			//storing the remainder value into the array
			this->array[i]=remainder;
		}
		//executing the devision number/2^1 (which is actually a right shift) and storing the result again to number
		mpz_tdiv_q_2exp(number,number,1);
	}

	//
	array=this->revertArray(array,this->getArraySize());
	
	//returnin the pointer
	return array;

}

/************************************************
* This method implements the modular exponantiation
* by squaring.It takes 4 parameters: the result of
* the algorithm and the base/exponent/modulus such
* that result=(base^exponent)mod(modulus)
*
* Modular exponantiation algorithm by Dr. Kaklamanis'
* notes:
*******************          ********************
* MODULAR-EXPONANTIATION(a,b,n)
* c <-- 0
* d <-- 1
* Let <B(k),B(k-1),B(k_2)...B(1),B(0)> the binary notation of B)
* for i:=k to 0
*		c <-- 2*c
*		d <-- (d*d)mod(n)
*		if(B(i)==1)
*		then c <-- c + 1
*			 d <-- (d*a)mod(n)
*
* return d
*
* It should be mentioned that c is not necessary for
* the algorithm's execution but it has been added for
* better understanding of it.
*************************************************/
int MillerRabin::modularExpo(mpz_t result,const mpz_t base,mpz_t exponent,const mpz_t modulus)
{
	//initializing the arguments
	mpz_set_ui(result,1);
	//declaring a bool pointer in order to hold the binary array in it
	bool *newarray=NULL;
	//converting the exponent(which is a multiprecision(MP) integer) to a binary array
	newarray=(bool *) this->convIntBool(exponent);


	//entering into the algorithms' main loop
	for(int i=0; i<this->getArraySize(); i++)
	{
		//multiplying d with itself
		mpz_mul(result,result,result);
		//executing the modulus operation
		mpz_mod(result,result,modulus);		

		//checking if current digit of exponent is 1
		if(newarray[i]==1)
		{
			//multiplying the base with the result
			mpz_mul(result,result,base);
			//executing the modulus operation
			mpz_mod(result,result,modulus);
		}
	}

	return 0;
}

/************************************************
* This method returns the size of the array which
* holds the binary notation of exponent argument in
* modularExpo() method.
*************************************************/
long int MillerRabin::getArraySize(void)
{

	return this->SIZE;
}

/************************************************
* This method accepts a pointer that points to an
* array of size size.It's main task is to revert
* the data of the array.
*************************************************/
bool *MillerRabin::revertArray(const bool *array,const int size)
{
	//declaring a new NULL pointer to hold the array
	bool *newarray=NULL;
	newarray=(bool *) malloc(sizeof(bool[size]));
	//reverting all the data of the array
	for(int i=0; i<size; i++)
	{
		newarray[i]=array[size-i-1];
	}
	//returning the new pointer
	return newarray;

}

/************************************************
* This method breaks an even number into a product
* of two numbers one of which is an exponent of 2.
* It stores into the struct breakPower the exponent
* and second factor of the product.
* It returns FALSE(0) only if the number given is
* not an even number.Else it returns TRUE(1).
*************************************************/
int MillerRabin::breakToPower(mpz_t even)
{
	int temp=0;
	mpz_t t,test;
	mpz_init(t);
	mpz_init(test);


	mpz_mod_ui(test,even,2);
	while ((temp=mpz_cmp_d(test,0)) == 0)
	{
		mpz_cdiv_q_ui(even,even,2);
		mpz_add_ui(t,t,1);

		mpz_mod_ui(test,even,2);
	}

	//checking if the number given is even
	if((temp=mpz_cmp_d(t,0))==0) return FALSE;

	//storing the numbers into the private struct breakPower
	mpz_set(this->breakPower.t,t);
	mpz_set(this->breakPower.u,even);

	return TRUE;
}

/************************************************
* This method is actually, a witness if, according
* to a, n is composite number or n is a prime number
* and as a result a is a strong liar.It has been
* implemented accroding to Dr. Kaklamanis notes.
*
* WITNESS(a,n)
* n-1=(2^t)*u
* X(0) <-- MODULAR-EXPONANTIATION(a,u,n)
* for i:=1 to t
* 		X(i) <-- ((X(i-1))^2)mod(n)
*		if(X(i)==1&&X(i-1)!=1&&X(i-1)!=-1)
*		then return TRUE
* if(X(i)!=1) then return TRUE
* return FALSE
*
*************************************************/
int MillerRabin::witness(mpz_t a,const mpz_t n)
{
	//declaring and initializing the variables
	int max,ret=FALSE;
	mpz_t X0,Xi,Xi_1,even,two,temp_u,powerHolder;
	mpz_init(X0);
	mpz_init(Xi);
	mpz_init(Xi_1);
	mpz_init(even);
	mpz_init(two);
	mpz_init(powerHolder);
	mpz_set_ui(two,2);
	mpz_set_ui(powerHolder,1);
	mpz_sub_ui(even,n,1);
	mpz_init(temp_u);

	//breaking into a product the n-1
	ret=breakToPower(even);
	//checking if the breakToPower method has encounter an error
	if(ret==FALSE)
	{
		cerr << endl << "Number must be odd!You entered an even number !!" << endl;
		exit(-1);
	}
	mpz_sub_ui(even,n,1);

	max=mpz_get_ui(this->breakPower.t);
	mpz_set(temp_u,this->breakPower.u);
	this->modularExpo(X0,a,temp_u,n);
	mpz_set(Xi_1,X0);
	//checking the number
	for(int i=1; i<=max; i++)
	{
		mpz_pow_ui(powerHolder,two,i);

		//calculating the modular exponantiation by squaring
		this->modularExpo(Xi,X0,powerHolder,n);

		//mpz_set_ui(two,2);
		if((mpz_cmp_ui(Xi,1)==0) && (mpz_cmp_ui(Xi_1,1)!=0) && (mpz_cmp(Xi_1,even)!=0)) return COMPOSITE;
		mpz_set(Xi_1,Xi);

	}
	if(mpz_cmp_ui(Xi,1)!=0) return COMPOSITE;



	return PRIME;
}


/************************************************
* This function generates a random number in the
* field of [0,limit].It was imlemented in the first
* place through C's rand() function but due to its
* limitation(the maximum number it can give is
* 2,147,483,647) it is implemented through GMP
* rand function which is limitless.
*************************************************/
int MillerRabin::randomNumber(mpz_t random, mpz_t limit)
{
	//set tha state of rand function
	mpz_urandomm(random,state,limit);
	//retrieve a new random number
	mpz_add_ui(random,random,1);

	return 0;

}

/************************************************
* This method implements the final Miller Rabin
* algorithm according to Dr. Kaklamanis notes.
*
* MILLER-RABIN(n,s)
* for i:=1 to s
* 		a <-- RANDOM(1,n-1)
* 		if WITNESS(a,n)
* 		then return COMPOSITE //certainly
* return PRIME // probably
*************************************************/
int MillerRabin::MillerRabinAlg(mpz_t n, int s)
{
	//declaring and initializing variables
	mpz_t a,limit;
	mpz_init(a);
	mpz_init(limit);
	mpz_sub_ui(limit,n,1);
	int num=0;

	//entering the main loop
	for(int i=0; i<s; i++)
	{
		if(FL_PRINT==TRUE) cout << "iteration " << i << " ";
		//fflush(stdout);
		//picking a random a to witness the compositeness of n
		this->randomNumber(a,limit);

		//checking if n is COMPOSITE or PRIME according to the random a
		fflush(stdout);
		num=this->witness(a,n);
		//if witness found out that n is composite return immediately
		//since witness dosen't make any mistake on the compositness of a number

		if(FL_PRINT==TRUE)
		{
			if(num==PRIME) cout << "found the number prime" << endl;
			else cout << "found the number compisite" << endl;
	
		}
		if(num==COMPOSITE) return COMPOSITE;
	}

	//if the method hasn't returned previously then n is a PRIME (probably)
	return PRIME;

}











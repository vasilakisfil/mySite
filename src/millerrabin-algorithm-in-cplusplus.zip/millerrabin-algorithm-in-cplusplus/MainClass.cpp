#include "MainClass.h"


/************************************************
* Class constructor.
*************************************************/
MainClass::MainClass(void)
{
	//creating a new object of class MillerRabin
	this->MRobject = new MillerRabin;

}

/************************************************
* Class destructor.
*************************************************/
MainClass::~MainClass(void)
{
	//deleting the MRobject to deallocate the memory that was used
	delete this->MRobject;

}

/************************************************
* This method reads a sequance of numbers from a
* file and determines if they are prime through
* the Miller Rabin priminality algorithm.
*************************************************/
void MainClass::readOrdFile(string filename)
{

	//creating an arithmetic variable that will hold every number is read from the file
	mpz_t num;
	//creating an string variable that will hold every number is read from the file
	string number;
	mpz_init(num);
	int what;

	//opening the file for input
	ifstream inPrimeFile(filename.c_str(), ios::in);
	if(!inPrimeFile)
	{
		cerr << "File could not be opened" << endl;
		exit (-1);
	}

	//checking every number of the file
	while(inPrimeFile >> number)
	{
		cout << "Checking number " << number << " from file " << filename << endl;

		mpz_set_str(num,number.c_str(),0);
		//checking the compositeness of the number num
		what=MRobject->MillerRabinAlg(num,accuracy);
		if(what==PRIME)
		{
			cout << "The number number is prime!" << endl;
		}
		else
		{
			cout << "The number number is composite!" << endl;
		}
	}


}

/************************************************
* This function generates a prime number of bitsize
* bits.Due to the fact that bitsize is declared as
* an integer, the maximum number bits is limited by
* INT_MAX of limits.h header.Thus it can be at least
* 2,147,483,647 number of bits(depends on the compiler).
*************************************************/
void MainClass::genPrime(int bitsize)
{
	//creating a new object of class MillerRabin
	//MillerRabin *MRobject = new MillerRabin;
	//declaring the variables that will be used afterwards
	int what,flag=FALSE,counter=0;
	char decision;
	string filename;

	mpz_t max,temp,n;
	gmp_randstate_t state;

	//variable max is used to limit the random numbers
	mpz_init(max);
	mpz_init(n);
	//initializing the GMP seeder
	gmp_randinit_default(state);
	//seeding the GMP random function
	gmp_randseed_ui(state,time(NULL));

	/* the method to set the limits(= the number of binary digits) of the random number
	* that is user here is the following: */

	//setting 1 to temp variable
	mpz_init_set_ui(temp,1);
	//calculating (temp)*2^bitsize and storing the result into variable max (limit=[0,2^bitsize])
	mpz_mul_2exp(max, temp, bitsize);
	//setting 2 to temp variable
	mpz_init_set_ui(temp,2);
	//dividing max by temp, forming a quotient max. (limit=[0,(2^bitsize)/2])
	mpz_cdiv_q(max,max,temp);
	//setting 1 to temp variable
	mpz_init_set_ui(temp,1);
	//substracting one from variable max..
	mpz_sub(max,max,temp);
	/*
	* Now we DO have the actual limit (limit=[0,((2^bitsize)/2)-1])
	* we will call later the random function to find a number in the field [0,((2^bitsize)/2)-1] and then the number (2^bitsize)/2)
	* will be added to the random number to give as the random number that we want with bitsize bits
	*/

	//adding temp and max and storing the result to temp in order to added later to the random number
	mpz_add(temp,max,temp);

	//inside the for loop a random number of bitsize bits is generated and the is checked if it is prime
	for( ; ; )
	{
		//finding a random number in the field [0,((2^bitsize)/2)-1]
		mpz_urandomm(n,state,max);
		//adding (2^bitsize)/2) to the random number to get the exact bit size
		mpz_add(n,n,temp);
		//checking if the number is even
		if(mpz_even_p(n)) continue;	
		fflush(NULL);
		what=MRobject->MillerRabinAlg(n,accuracy);
		fflush(NULL);
		if(what==PRIME)
		{
			cout << "Found prime! " << n << endl;
			break;
		}
		fflush(NULL);
		if(FL_PRINT==TRUE) cout << "Trying " << counter << " random number " << n <<  endl;
		fflush(NULL);
		if(counter==5 && FL_SEED==TRUE)
		{
			cout << "trying new seed for rand() function..." << endl;
			gmp_randseed_ui(state,time(NULL));
			counter=0;
		}
		counter++;

	}
	//checking if user wants the number wirten in a file
	//flag indicates the correct/wrong input from the user
	while(flag==FALSE)
	{
		cout << "Do you also want to store the prime number in a file?[Y]/[N]" << endl;
		cin >> decision;

		if(decision=='Y'||decision=='y')
		{
			cout << "Please specify the name of the file:" << endl;
			cin >> filename;
			//opening the file to write the number
			ofstream FilePrime(filename.c_str(), ios::out);
			if(!FilePrime)
			{
				cerr << "File could not be opened" << endl;
				exit (-1);
			}
			//writing the number into the stream
			FilePrime << n;

			flag=TRUE;
		}
		else if(decision=='N'||decision=='n')
		{
			cout << "Program now is terminating." << endl;
			flag=TRUE;
		}
		else cout << "Wrong input" << endl;
	}

}

/************************************************
* This function checks if the string contained in
* the char pointer *strnumber is a prime.The
* function outputs the result in the command line.
*************************************************/
void MainClass::checkNumber(char *strnumber)
{
	//creating a new object of type MillerRabin
	//MillerRabin *MRobject = new MillerRabin;
	int what;
	//declaring a variable that will hold the number
	mpz_t number;
	//converting the string number into an integer number
	mpz_init_set_str(number,strnumber,0);

	//checking the priminality of the given number
	what=MRobject->MillerRabinAlg(number,accuracy);
	//show the result
	if(what==PRIME)
	{
		cout << "The number number is prime!" << endl;
	}
	else
	{
		cout << "The number number is composite!" << endl;
	}

}



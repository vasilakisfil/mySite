#include "global.h"
#include "MillerRabin.h"
#include "MainClass.h"

//these variables are GLOBAL in every file since there are corresponding declaration in global.h file..
bool FL_PRINT=FALSE;
bool FL_SEED=FALSE;
int accuracy=ACCURACY;


//function that shows how to use the millerRabin program
void usage(const char *prog);

int main(int argc, char **argv)
{
	//flags that are used in the main combined with getopt() function
	bool FL_CLI=FALSE,FL_INPUT=FALSE,FL_GEN=FALSE;
	//string that will hold user data
	string filename;
	//C-like string (gotta declare it like this due to GMP library)
	char *number;
	//ch variable is used int getopt and bitsize will hold the size of the prime number the user wants be generated
	int ch,bitsize;


	//checking if there is at least otwo arguments..
	if(argc<2)
	{
			usage(argv[0]);
			exit(-1);
	}
	//parsing the command line arguments..
	while ((ch = getopt (argc, argv, "c:i:g:a:ps")) != -1)
	{
		switch (ch)
		{
			//accuracy adjustment argument
			case 'a':
				//setting the desirable accuracy (default is 200)
				accuracy=atoi(optarg);
				break;
			//state of printing argument
			case 'p':
				//enabling printing the current number of iretation (it helps when calculating very large numbers to see that there is an andance...)
				FL_PRINT=TRUE;
				break;
			//command line checking argument
			case 'c':
				//allocating memory for the *number
				number=(char *)malloc((size_t)strlen(number)*sizeof(char));
				//copying the optarg(the argument the user gave) in to the *number
				strncpy(number,optarg,strlen(optarg));
				//setting the command line flag to TRUE
				FL_CLI=TRUE;
				break;
			//file input argument
			case 'i':
				//passing the string was given in the command line to string variable filename in order to hold the name of the file
				//that that containes the numbers the user want to check..
				filename=optarg;
				//setting the input flag
				FL_INPUT=TRUE;
				break;
			//prime generation argument
			case 'g':
				//passing the number of bits that were given as a number in the command line
				bitsize=atoi(optarg);
				//setting the generate flag
				FL_GEN=TRUE;
				break;
			//repeat seed every bitsize bits
			case 's':
				//setting the FL_SEED flag
				FL_SEED=TRUE;
				break;
			//help argument
			case 'h':
				usage(argv[0]);
				exit(-1);
			//if an argument was not recognised
			case '?':
				usage(argv[0]);
				exit(-1);
			default:
				usage(argv[0]);
				exit(-1);
		}
	}

	//creating a new instance of MainClass object
	MainClass *execute = new MainClass;

	if(FL_CLI==TRUE)
	{
		//checking the number that was given in the command line
		execute->checkNumber(number);
	}
	if(FL_INPUT==TRUE)
	{
		//calling the readOrdFile method to check all the numbers contained in the filename file
		execute->readOrdFile(filename);
	}
	if(FL_GEN==TRUE)
	{
		//finding a prime with bitsize bits
		execute->genPrime(bitsize);
	}

	//checking the arguments(if the user gave none of the known arguments then he used wrongly the program..)
	if(FL_CLI==FALSE && FL_INPUT==FALSE && FL_GEN==FALSE)
	{
			usage(argv[0]);
			delete execute;
			exit(-1);
	}
	return 0;

}


/************************************************
* Function that prints the usage of the program
* when the user makes a mistake on the command
* line argumens.
*************************************************/
void usage(const char *prog){
	fprintf(stderr, "Usage %s [-c num|-i filename|-g numbits|-p|-a num]\n", prog);
	fprintf(stderr, "\t-h :\t Shows help info\n");
	fprintf(stderr, "\t-c number:\t Check a number from the comand line\n");
	fprintf(stderr, "\t-i filename:\t Check a sequence of numbers contained in the filename\n");
	fprintf(stderr, "\t-g numbits:\t Generate a prime number of numbits bits\n");
	fprintf(stderr, "\t-a number:\t Setting the accuracy (default is 200)\n");
	fprintf(stderr, "\t-p:\t\t Turns on iretation printing(helps when numbers are quite big to see that there is actually a progress...)\n");
	fprintf(stderr, "\t-s:\t\t Enables repeated seeding every numbits times..it helps some times to get faster a prime number through rand() function(works only for prime generation)\n");
}

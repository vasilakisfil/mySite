#ifndef MILLERRABIN_H
#define MILLERRABIN_H

#include "global.h"

class MillerRabin
{
public:
	//-----------methods-----------------
	//the constructor of MillerRabin class
	MillerRabin();
	//the destructor of MillerRabin class
	~MillerRabin();


	//the Miller Rabin Algorithm
	int MillerRabinAlg(mpz_t n, int s);

	//----------variables----------------

private:
	//-----------methods-----------------
	//method that converts an integer number into a binary number
	//returns the pointer to the (boolean) array that holds the binary number
	bool *convIntBool(mpz_t number);
	//method that returns the size of the array( that was created through *convIntBool() )
	long int getArraySize(void);
	//method that implements the modular exponatation by squaring algorithm
	int modularExpo(mpz_t result,const mpz_t base,mpz_t exponent,const mpz_t modulus);
	//method that reports if a is a witness of the cpositeness(?) of number n
	int witness(mpz_t a,const mpz_t n);
	//method that produces a random number
	int randomNumber(mpz_t random, mpz_t limit);
	//method that breaks an even number to a product of two numbers,
	//one of which has a base of 2
	int breakToPower(mpz_t even);
	//method that inverts the cells of an array (not used)
	bool *revertArray(const bool *array,const int size);

	//----------variables----------------
	//pointer that refers to the first memory location of the array
	bool *array;
	//a variable that holds the size of the array
	long int SIZE;
	//struct that holds the values produced from method breakToPower()
	struct power
	{
		mpz_t t;	//exponement
		mpz_t u;	//second factor
	}breakPower;

	gmp_randstate_t state;
	
};


#endif

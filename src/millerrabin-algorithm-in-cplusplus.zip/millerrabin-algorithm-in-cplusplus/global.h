#ifndef GLOBAL_H
#define GLOBAL_H

//defining some major keywords that are used extensively in the program
#define TRUE 1
#define FALSE 0
#define PRIME 666
#define COMPOSITE 777
#define ACCURACY 200

//include the apropriate headers
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <cmath>
#include <gmp.h>
#include <gmpxx.h>

//specifying only the namespaces that are used in the program
using std::cout;
using std::cin;
using std::cerr;
using std::endl;
using std::ios;
using std::string;
using std::ifstream;
using std::ofstream;
using std::exit;

//declaring these variables as extern in order to be global and included on every file..
extern bool FL_PRINT;
extern int accuracy;
extern bool FL_SEED;

//extern int variable;

#endif

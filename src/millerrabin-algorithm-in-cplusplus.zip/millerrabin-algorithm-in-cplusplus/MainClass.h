#ifndef MAINCLASS_H
#define MAINCLASS_H

#include "global.h"
#include "MillerRabin.h"

class MainClass
{
public:
	//-----------methods-----------------
	//the constructor of MainClass class(not implemented)
	MainClass(void);
	//the destructor of MainClass class(not implemented)
	~MainClass(void);
	//function that reads numbers from a file and checks them for primilaty
	void readOrdFile(string filename);
	//function that generates a prime number of bitsize bits
	void genPrime(int bitsize);
	//function that checks the number contained in the char pointer strnumber
	void checkNumber(char *strnumber);
	
	//-----------variables-----------------

private:
	//-----------methods-----------------

	//-----------variables-----------------
	// object of class MillerRabin
	MillerRabin *MRobject;

};



#endif

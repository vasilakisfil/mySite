#include "global.h"
#include "functions.h"


//the main function
int main(int argc, char **argv)
{
	//variable declarations
	int k,l,i,j,neigh_alive=0,dol,swap,ch,c,r,divC,divR,ret,ir,ic;
	//initializations
	PRINT_FLAG=TRUE;
	MINI_PRINT_FLAG=FALSE;
	NUM_THREADS=1;
	LOAD_FILE=FALSE;
	CREATE_FILE=FALSE;
	opterr = 0;
	//declaring the structs the are used by gettimeofday
    struct timeval tb1;
    struct timeval tb2;

	//checking the parameters with getopt function
	while ((ch = getopt (argc, argv, "mbc:l:t:")) != -1)
	{
		switch (ch)
		{
			//b:benchmark mode
			case 'b':
				//do not print anything
				PRINT_FLAG=FALSE;
				break;
			//c:create file
			case 'm':
				PRINT_FLAG=FALSE;
				MINI_PRINT_FLAG=TRUE;
				break;
			case 'c':
				//copy the parameter string into filename variable
				strcpy(filename,optarg);
				CREATE_FILE=TRUE;
				//if both -c and -l parameters exist in the parameter's array exit!
				if(LOAD_FILE==TRUE)
				{
					fprintf(stderr,"Error:Cannot read and load a file at the same time.\n");
					usage(argv[0]);
					exit(EXIT_FAILURE);
				}
				break;
			//l:load file
			case 'l':
				//copy the parameter string into filename variable
				strcpy(filename,optarg);
				LOAD_FILE=TRUE;
				//if both -c and -l parameters exist in the parameter's array exit!
				if(CREATE_FILE==TRUE)
				{
					fprintf(stderr,"Error:Cannot read and load a file at the same time.\n");
					usage(argv[0]);
					exit(EXIT_FAILURE);
				}
				break;
			//t:number of threads
			case 't':
				NUM_THREADS=atoi(optarg);
				break;
			case '?':
				usage(argv[0]);
				exit(0);
			default:
				usage(argv[0]);
				exit(0);
		}
	}

	//do the appropriate initializations according to cli arguments
	initialization(filename);

	//calculate the threads
	calcNumThreads(NUM_THREADS,&r,&c);
	//creating an array that will hold all the threads id
	pthread_t threads_id[NUM_THREADS];

	//creating a struct of type threadPass to hold the data the threads will need to use
	struct threadPass th_pass[r][c];
	//...
	//printf("%d %d\n",cols,rows);
	//exit(1);
	divC=(cols-2)/c;
	divR=(rows-2)/r;

	//if benchmark mode is not enabled...
	if(PRINT_FLAG==TRUE)
	{
		system("clear");
		printf("Using array:\n");
		for(i=0; i<rows; i++)
		{
			for(j=0; j<cols; j++)
			{
				printf("%d",ARRAY[i][j][main_array]);
			}
			printf("\n");
		}
		printf("\nUsing %d number of threads (%d X %d)\n",NUM_THREADS,r,c);
		printf("c:%d r:%d divC:%d divR:%d\n",c,r,divC,divR);
		sleep(3);
		system("clear");
	}

	//storing computation data for each thread
	for(ir=0; ir<r; ir++)
	{
		for(ic=0; ic<c; ic++)
		{
			th_pass[ir][ic].starti=divR*ir+1;
			th_pass[ir][ic].endi=divR*(ir+1)+1;
			th_pass[ir][ic].startj=divC*ic+1;
			th_pass[ir][ic].endj=divC*(ic+1)+1;
		}
	}

	//getting  system's local time
    if(gettimeofday(&tb1,NULL))
    {
    	printf("Error on gettimeofday\n");
    	exit(-1);
    }

	//for 100 phases..
	for(k=1; k<100; k++)
	{
		int l=0; //l stands as index for threads_id[] array
		for(ir=0; ir<r; ir++)
		{
			for(ic=0; ic<c; ic++)
			{
				//creating the threads
				ret=pthread_create(&threads_id[l],NULL, calcNewArray, (void *) &th_pass[ir][ic]);
				if(ret)
				{
					printf("ERROR; return code from pthread_create is %d\n", ret);
					exit(-1);
				}
				l++;
			}
		}

		//waiting for threads to join the main thread..
		for(l=0; l<NUM_THREADS; l++)
		{
			pthread_join(threads_id[l], NULL);
		}


		//swapping the arrays
		swap=main_array;
		main_array=backup_array;
		backup_array=swap;

		//if MINI_PRINT_FLAG is enabled print the phases(it helps to see the progress of the program..)
		if(MINI_PRINT_FLAG==TRUE)
		{
			printf("Phase %d\n", k);
		}	
		
	}		
	
	//get once more the system's local time
    if(gettimeofday(&tb2,NULL))
    {
    	printf("Error on gettimeofday\n");
    	exit(-1);
    }

	//calculating the difference between the two time measurements
	double real = (double)tb2.tv_sec-(double)tb1.tv_sec + ((double)tb2.tv_usec-(double)tb1.tv_usec)/1000000;

	printf("time: %f \n", real);


	return 0;
}

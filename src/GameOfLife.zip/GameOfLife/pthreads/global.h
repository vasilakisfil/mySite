#ifndef GLOBAL_H
#define GLOBAL_H


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/time.h>


#define TRUE 1
#define FALSE 0
#define DEAD 0
#define ALIVE 1
#define M 1200
#define N 1200

int ARRAY[M][N][2];
short main_array;
short backup_array;
short PRINT_FLAG;

int rows,cols;
char filename[12];
short NUM_THREADS;
short LOAD_FILE;
short CREATE_FILE;
short MINI_PRINT_FLAG;

struct threadPass{
	int starti;
	int endi;
	int startj;
	int endj;
};

#endif

#include "functions.h"

/******************************************************************************
* This function creates rand numbers of 0 and 1 seeded by local UTC time and
* writes them on ARRAY[][][main_array] & ARRAY[][][backup_array].
*******************************************************************************/
int randArray(void)
{

	int i,j,temp;
	//is used to seed the rand fuction
	unsigned int utime;
	//is used to seed the rand fuction through local UTC time
	utime=(unsigned int)time(NULL);
	srand(utime);


	//start creating the array
	for(i=0; i<rows; i++)
	{
		for(j=0; j<cols; j++)
		{
			temp=rand()%2;
			if(temp==1)
			{
				ARRAY[i][j][main_array]=ALIVE;
				ARRAY[i][j][backup_array]=ARRAY[i][j][main_array];
			}
			else
			{
				ARRAY[i][j][main_array]=DEAD;
				ARRAY[i][j][backup_array]=ARRAY[i][j][main_array];
			}
		}
	}



	return 0;
}


/******************************************************************************
* This function just prints the usage of the programs parameters.
* (stolen from project 2009 :-D)
*******************************************************************************/
void usage(const char *prog){
	fprintf(stderr, "Usage %s [-b | -l filename]\n", prog);
	fprintf(stderr, "\t-b:\t Do benchmark mode.Do not print the array on every phase.\n");
	fprintf(stderr, "\t-c filename:\t Create a file named filename and write a new array in it.\n");
	fprintf(stderr, "\t-l filename:\t Load the array from a file named filename to memory.\n");
	fprintf(stderr, "\t-t numThreads:\t Specify the number of threads by numThreads that will run the Game of Life.\n");
}


/******************************************************************************
* This function follows Karantasis' procedure for the separation of a two-
* dimensional array.The function accepts as input the number of threads(numT)
* and two integer pointers.When an array of MxN dimensions has to be devised
* for P threads, P is consider as a product of two numbers, r and c so as
* P=r*c, and obviously such a product exists for every integer number of
* threads.However it is desirable that the difference r-c is minimized.
*******************************************************************************/
int calcNumThreads(const int numT, int *c, int *r)
{
	int i,j;
	//create a maximum difference between c and r
	*r=1,*c=numT;

	for(i=1; i<=numT; i++)
	{
		for(j=1; j<=numT; j++)
		{
			//if i*j has product equivelent to numT then...
			if(i*j==numT)
			{
				//if the difference is smaller than the previous
				if(abs(j-i)<abs(*c-*r))
				{
					//store the new c,r
					*c=i;
					*r=j;
				}
			}
		}
	}


	return 0;
}

/******************************************************************************
* This function initializes the ARRAY according to the command line arguments.
* If the argument -l was given, the
*******************************************************************************/
void initialization(const char *filename)
{

	main_array=0;
	backup_array=1;


	if(LOAD_FILE==TRUE)
	{
		loadfile(filename);
		//rows-=2;
		//cols-=2;
	}
	else if(CREATE_FILE==TRUE)
	{
		rows=M;
		cols=N;
		randArray();
		createfile(filename);
	}
	else
	{
		//rows=M-2;
		//cols=N-2;
		randArray();
	}		

}

/******************************************************************************
* This function creates a file specified by *filename containing an array of
* M x N dimensions with ALIVE or DEAD letters(propably 1 and 0 respectively).
* On the top of the file the function writes the number of rows and columns
* the array has.
*******************************************************************************/
int createfile(const char *filename)
{
	int i,j;
	FILE *fd;

	//opening the filename file to write the rand array into the file
	if((fd=fopen(filename, "w"))==NULL)
	{
		printf("Cannot open file.\n");
		exit(1);
	}

	//writing the dimensions of the array into the file
	fprintf(fd,"%d\n", rows);
	fprintf(fd,"%d\n", cols);
	//writing the array into the file
	for(i=0; i<rows; i++)
	{
		for(j=0; j<cols; j++)
		{
			fprintf(fd,"%d ", ARRAY[i][j][main_array]);
		}
		fprintf(fd,"\n");		
	}
	
	//closing the file
	fclose(fd);

	return 0;


}

/******************************************************************************
* This function opens a file specified by *filename, reads the characters of
* the file and stores them on the ARRAY[][][].The function presupposes that
* dimensions(rows,columns) are written at the top of the file.
*******************************************************************************/
int loadfile(const char *filename)
{
	int i,j;
	FILE *fd;

	//opening the file for reading
	if((fd=fopen(filename, "r"))==NULL)
	{
		printf("Cannot open file.\n");
		exit(1);
	}
	//reading the dimensions of the array
	fscanf(fd, "%d", &rows);
	fscanf(fd, "%d", &cols);

	//storing the values into the array
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			fscanf(fd, "%d", &ARRAY[i][j][main_array]);
			ARRAY[i][j][backup_array]=ARRAY[i][j][main_array];
		}
	}
	//finally closing the file
	fclose(fd);

	return 0;
}





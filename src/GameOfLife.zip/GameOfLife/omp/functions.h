#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "global.h"

//a function that creates an array containing ALIVE and DEAD characters
int randArray(void);
//a function that prints how the program's parameters work
void usage(const char *prog);
//a function that calculates the new state of a subsection of ARRAY
void *calcNewArray(void *arg);
//a function that calculates the numbers c and r that have a product of numT
int calcNumThreads(const int numT, int *c, int *r);
//a function that does all the initializations
void initialization(const char *filename);
//a function that writes the ARRAY into a file specified by *filename
int createfile(const char *filename);
//a function that loads a file containing numbers into the ARRAY
int loadfile(const char *filename);
#endif

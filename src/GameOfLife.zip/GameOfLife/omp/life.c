#include "global.h"
#include "functions.h"


//the main function
int main(int argc, char **argv)
{
	//variable declarations
	int k,l,i,j,neigh_alive=0,dol,swap,ch,c,r,divC,divR,ret,ir,ic;
	int new_i,new_j;
	//initializations
	PRINT_FLAG=TRUE;
	MINI_PRINT_FLAG=FALSE;
	NUM_THREADS=1;
	LOAD_FILE=FALSE;
	CREATE_FILE=FALSE;
	opterr = 0;

	//declaring the structs the are used by gettimeofday
    struct timeval tb1;
    struct timeval tb2;



	//checking the parameters with getopt function
	while ((ch = getopt (argc, argv, "mbc:l:t:")) != -1)
	{
		switch (ch)
		{
			//b:benchmark mode
			case 'b':
				//do not print anything
				PRINT_FLAG=FALSE;
				break;
			//c:create file
			case 'm':
				PRINT_FLAG=FALSE;
				MINI_PRINT_FLAG=TRUE;
				break;
			case 'c':
				//copy the parameter string into filename variable
				strcpy(filename,optarg);
				CREATE_FILE=TRUE;
				//if both -c and -l parameters exist in the parameter's array exit!
				if(LOAD_FILE==TRUE)
				{
					fprintf(stderr,"Error:Cannot read and load a file at the same time.\n");
					usage(argv[0]);
					exit(EXIT_FAILURE);
				}
				break;
			//l:load file
			case 'l':
				//copy the parameter string into filename variable
				strcpy(filename,optarg);
				LOAD_FILE=TRUE;
				//if both -c and -l parameters exist in the parameter's array exit!
				if(CREATE_FILE==TRUE)
				{
					fprintf(stderr,"Error:Cannot read and load a file at the same time.\n");
					usage(argv[0]);
					exit(EXIT_FAILURE);
				}
				break;
			//t:number of threads
			case 't':
				NUM_THREADS=atoi(optarg);
				break;
			case '?':
				usage(argv[0]);
				exit(0);
			default:
				usage(argv[0]);
				exit(0);
		}
	}

	//do the appropriate initializations according to cli arguments
	initialization(filename);

	//if benchmark mode is not enabled...
	if(PRINT_FLAG==TRUE)
	{
		system("clear");
		printf("Using array:\n");
		for(i=0; i<rows; i++)
		{
			for(j=0; j<cols; j++)
			{
				printf("%d",ARRAY[i][j][main_array]);
			}
			printf("\n");
		}
		sleep(3);
		system("clear");
	}


    if(gettimeofday(&tb1,NULL))
    {
    	printf("Error on gettimeofday\n");
    	exit(-1);
    }


	//for 100 phases..
	for(k=1; k<100; k++)
	{
		//neigh_alives holds the number of alive neighbours of an element
		int neigh_alive=0;

		//declaring OpenMP's derective with the appropriate scheduling...
		#pragma omp parallel for private(j,new_i,new_j,neigh_alive) schedule(guided,1200) 
		for(i=1; i<rows-1; i++)
		{
			
			for(j=1; j<cols-1; j++)
			{
				//find all the alive neighbours through a clockwise rotation
				neigh_alive=0;
				for(new_i=i-1; new_i<=i+1; new_i++)
				{
					for(new_j=j-1; new_j<=j+1; new_j++)
					{
						if(new_i==i&&new_j==j) continue; //continue here since it is the cell that is examined
						if(ARRAY[new_i][new_j][main_array]==ALIVE)
						{
							neigh_alive+=1;
						}
					}
				}
				//set the rules according to Conway's Game of Life
				if(ARRAY[i][j][main_array]==DEAD)
				{
					if(neigh_alive==3) ARRAY[i][j][backup_array]=ALIVE;
					else ARRAY[i][j][backup_array]=DEAD;
				}
				else
				{
					if(neigh_alive<2||neigh_alive>3) ARRAY[i][j][backup_array]=DEAD;
					else if(neigh_alive==2||neigh_alive==3) ARRAY[i][j][backup_array]=ALIVE;
				}
			}
		}


		//swapping the arrays
		swap=main_array;
		main_array=backup_array;
		backup_array=swap;

		if(MINI_PRINT_FLAG==TRUE)
		{
			printf("Phase %d\n", k);
		}			

	}

	//get once more the system's local time
    if(gettimeofday(&tb2,NULL))
    {
    	printf("Error on gettimeofday\n");
    	exit(-1);
    }

	//calculating the difference between the two time measurements
	double real = (double)tb2.tv_sec-(double)tb1.tv_sec + ((double)tb2.tv_usec-(double)tb1.tv_usec)/1000000;


	printf("time: %f \n", real);



	return 0;
}

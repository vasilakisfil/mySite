#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "global.h"


//a function that initializes the mutex
int my_rw_init(my_rw_t *lockvar);
//a funtion that locks the mutex on write mode
int my_rw_writelock(my_rw_t *lockvar);
//a funtion that unlocks the mutex which previously had been locked on write mode by the same thread
int my_rw_writeunlock(my_rw_t *lockvar);
//a funtion that destroys the mutex
int my_rw_destroy(my_rw_t *lockvar);





#endif

#ifndef GLOBAL_H
#define GLOBAL_H

#define FALSE	0
#define TRUE	1

#define MAX_THREADS	16

#define R	MAX_THREADS
#define C	2

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

/* struct that implements the my_rw_t mutex variable
*
* ---->   SHOULD BE IMPLEMENTED WITH POINTERS   <----
*/
typedef struct my_rw_t{
	//holds the read lock state
	volatile int read;
	//holds the write lock state
	volatile int write;
	//holds the (p)thread id that locked the mutex
	pthread_t tid;
	//pthread mutex
	pthread_mutex_t mymutex;
	//pthread condition variable
	pthread_cond_t condvar;

}my_rw_t;


typedef int rdwr_t;

#endif

//include the header file
#include "functions.h"

/******************************************************************************
* This function initializes the mutex.The read and write variables which 
* hold if the mutex is on read/write mode are initialized to 1 whereas the
* tid variable which holds the thread id is initialized to zero.Also a
* pthread mutex and a pthread condition variable are created.
*******************************************************************************/
int my_rw_init(my_rw_t *lockvar)
{
	int i,j;

	//initializing the read mode
	lockvar->read=FALSE;
	//initializing the write mode
	lockvar->write=FALSE;
	//initializing the pthread id
	lockvar->tid = 0;

	//initializing the pthread mutex
	pthread_mutex_init(&(lockvar->mymutex), NULL);
	//initializing the pthread condition variable
	pthread_cond_init(&(lockvar->condvar), NULL);




	return 0;
}


/******************************************************************************
* This function implements the write lock.On this mode only one thread per time
* can lock the mutex.At the beginning it locks a pthread mutex(in order
* to access the global struct which implements the my_rw_t mutex :-D ) and then
* checks if the my_rw_t mutex is already locked on this mode.If it is then the
* pthread_cond_wait is called in order to unlock the pthread mutex and block.
* If the thread unblocks or/and the my_rw_t mutex is not locked on write mode,
* this function marks the my_rw_t mutex as locked by addressing the zero value
* to lockvar->write variable.Also the (p)thread id is stored to tid variable
* which is needed on the unlocking procedure.
*******************************************************************************/
int my_rw_writelock(my_rw_t *lockvar)
{

	//locking the pthread mutex
	pthread_mutex_lock(&(lockvar->mymutex));
	//checking if the my_rw_t mutex is already locked
	while(lockvar->write==TRUE)
	{
		//if it is, the pthread mutex is unlocked and the tread blocks
		pthread_cond_wait(&(lockvar->condvar),&(lockvar->mymutex));
	}
	//locking the my_rw_t mutex
	lockvar->write=TRUE;
	//storing the (p)thread id to tid variable
	lockvar->tid=pthread_self();
	//unlocking the pthread mutex
	pthread_mutex_unlock(&(lockvar->mymutex));


	return 0;
}


/******************************************************************************
* This function implements the write unlock.The my_rw_t mutex will be unlocked
* if and only if the (p)thread that locked it(through my_rw_writeunlock(my_
* rw_t *lockvar)) is the same with the thread that tries to unlock it through
* this function.At the beginning a pthread mutex is locked in order to access
* the global struct that implements the my_rw_t mutex.Then the (p)thread id (
* through pthread)self() ) is compared with the variable lockvar->tid which holds
* the (p)thread id of the thread that called my_rw_writelock(my_rw_t *lockvar).
* If they are not the same the program terminates.Else my_rw_t mutex is unlocked,
* pthread mutex is also unlocked and last but not least the thread calls
* pthread_cond_signal(pthread_cond_t *cond) to signal on the other threads that
* the write lock has been unlocked.
*******************************************************************************/
int my_rw_writeunlock(my_rw_t *lockvar)
{

	//locking the pthread mutex
	pthread_mutex_lock(&(lockvar->mymutex));
	//checking the current (p)thread id with the previous id stored to lockvar->tid variable
	if(pthread_self()!=lockvar->tid)
	{
		//current (p)thread id with stored (p)thread id don't match
		printf("wrong thread %u\n", (unsigned int)pthread_self());
		//programm terminates
		exit(-1);
	}
	//unlocking the my_rw_t mutex
	lockvar->write=FALSE;
	//unlocking the pthread mutex
	pthread_mutex_unlock(&(lockvar->mymutex));
	//signaling the change of the state of the condition to the other threads that wait for the condition to become true
	pthread_cond_signal(&(lockvar->condvar));

	return 0;
}

/******************************************************************************
* This function destroys the my_rw_t mutex.In fact it stores to lockvar->read, 
* lockvar->write and lockvar->tid varibles a value of zero.At last it destroys
* the pthread mutex and pthread condition variable through the pthread functions.
*******************************************************************************/
int my_rw_destroy(my_rw_t *lockvar)
{
	int i,j;


	//setting the read lock on lock state
	lockvar->read=TRUE;
	//setting the write lock on lock state
	lockvar->write=TRUE;

	//zeroing the id variable
	lockvar->tid=0;

	//destroying the pthread mutex
	pthread_mutex_destroy(&(lockvar->mymutex));
	//destroying the pthread condition variable
	pthread_cond_destroy(&(lockvar->condvar));


	return 0;
}




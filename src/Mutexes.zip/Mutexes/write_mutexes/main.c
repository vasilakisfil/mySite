#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include "functions.h"

//function that reads the global variable 10000 times
void *readers_funct(void *arg);
//function that reads the global variable and increments its value 10000 times
void *writers_funct(void *arg);
//function that initializes the read/write mutexes
int init_rdwrlock(void);

//struct that holds the global variable
struct pass{
	double value;
}pass;

//my_rw_t mutex
struct my_rw_t lockvar;

int main()
{
	int i,err;
	//an array that holds all(16) the pthread ids.
	pthread_t pid[16];


	//calling the initialization function
	init_rdwrlock();

	//creating 2 threads that will be writers
	for(i=0; i<2; i++)
	{
		//creating the thread..
		err=pthread_create(&pid[i], NULL, writers_funct, (void *) &pass);
		if(err!=0)
		{
			printf("Error on pthread_create\t%d\n...program terminating..\n", err);
			exit(-1);
		}
	}
	//creating 14 threads that will be readers
	for(i=2; i<16; i++)
	{
		//creating the thread...
		err=pthread_create(&pid[i], NULL, readers_funct, (void *) &pass);
		if(err!=0)
		{
			printf("Error on pthread_create\t%d\n...program terminating..\n", err);
			exit(-1);
		}
	}

	//waiting the treads to join the main thread
	for(i=0; i<16; i++)
	{
		pthread_join(pid[i], NULL);
	}
		
	return 0;

}

/****************************************************************************************
* This function implements the readers.Every thread that enters in this function, reads
* the global 10000 times
*****************************************************************************************/
void *readers_funct(void *arg)
{
	//casting the parameter
	struct pass *number = (struct pass *) arg;
	int i;

	//sleep(0.1);
	for(i=0; i<10000; i++)
	{
		//locking the mutex in read mode
		if(my_rw_writelock(&lockvar)!=0)
		{
			printf("Error...\n");
			exit(-1);
		}
		//printing the global variable
		printf("thread %u reads value %f \n", (unsigned int)pthread_self(),number->value);
		//unlocking the mutex
		my_rw_writeunlock(&lockvar);
	}

	return ((void *) 0);
}

/****************************************************************************************
* This functions implements the writers.Every thread that enters in this function reads
* the global variable and increments it by one for 10000 times.
*****************************************************************************************/
void *writers_funct(void *arg)
{
	//casting the parameter
	struct pass *number = (struct pass *) arg;
	int i;

	for(i=0; i<10000; i++)
	{
		//locking the mutex on write mode
		my_rw_writelock(&lockvar);
		//printing the current value
		printf("thread %u reads value %f ",(unsigned int)pthread_self(),number->value);
		//increments the value
		number->value=number->value + 1;
		//printing the new value
		printf("and writes value %f\n",number->value);
		//unlocking the mutex
		my_rw_writeunlock(&lockvar);
	}

	return ((void *) 0);
}

/****************************************************************************************
* This function initialized the pthread read/write locks.
*****************************************************************************************/
int init_rdwrlock(void)
{
	//initializing the read/write mutex
	if(my_rw_init(&lockvar)!=0)
	{
		printf("error...\n");
		exit(-1);
	}

	return 0;
}






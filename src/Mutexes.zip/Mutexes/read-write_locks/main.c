#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
#include "functions.h"

//function that reads the global variable 10000 times
void *readers_funct(void *arg);
//function that reads the global variable and increments its value 10000 times
void *writers_funct(void *arg);
//function that initializes the read/write mutexes
int init_rdwrlock(void);

//struct that holds the global variable
struct pass{
	double value;
}pass;

//my_rw_t mutex
struct my_rw_t lockvar;

int main()
{
	int i,err;
	//an array that holds all(16) the pthread ids.
	pthread_t pid[100];

	struct timeval tb1;
	struct timeval tb2;
	
	
	gettimeofday(&tb1,NULL);

	pass.value=0;
	//calling the initialization function
	my_rw_init(&lockvar);

	//creating 2 threads that will be writers
	for(i=0; i<10; i++)
	{
		//creating the thread..
		err=pthread_create(&pid[i], NULL, writers_funct, (void *) &pass);
		if(err!=0)
		{
			printf("Error on pthread_create\t%d\n...program terminating..\n", err);
			exit(-1);
		}
	}
	//creating 14 threads that will be readers
	for(i=10; i<100; i++)
	{
		//creating the thread...
		err=pthread_create(&pid[i], NULL, readers_funct, (void *) &pass);
		if(err!=0)
		{
			printf("Error on pthread_create\t%d\n...program terminating..\n", err);
			exit(-1);
		}
	}

	//waiting the treads to join the main thread
	for(i=0; i<100; i++)
	{
		pthread_join(pid[i], NULL);
	}
	
	my_rw_destroy(&lockvar);
	
	gettimeofday(&tb2,NULL);
	
	double real = (double)tb2.tv_sec-(double)tb1.tv_sec + ((double)tb2.tv_usec-(double)tb1.tv_usec)/1000000;


	printf("time: %f \n", real);
		
	return 0;

}

/****************************************************************************************
* This function implements the readers.Every thread that enters in this function, reads
* the global 10000 times
*****************************************************************************************/
void *readers_funct(void *arg)
{
	//casting the parameter
	struct pass *number = (struct pass *) arg;
	long int i;

	//sleep(0.1);
	for(i=0; i<1000; i++)
	{
		//locking the mutex in read mode
		if(my_rw_readlock(&lockvar)!=0)
		{
			printf("Error...\n");
			exit(-1);
		}
		//printing the global variable
		//--printf("thread %u reads value %f \n", (unsigned int)pthread_self(),number->value);
		//unlocking the mutex
		my_rw_readunlock(&lockvar);
	}

	return ((void *) 0);
}

/****************************************************************************************
* This functions implements the writers.Every thread that enters in this function reads
* the global variable and increments it by one for 10000 times.
*****************************************************************************************/
void *writers_funct(void *arg)
{
	//casting the parameter
	struct pass *number = (struct pass *) arg;
	long int i;

	for(i=0; i<1000; i++)
	{
		//locking the mutex on write mode
		my_rw_writelock(&lockvar);
		//printing the current value
		//printf("thread %u reads value %f ",(unsigned int)pthread_self(),number->value);
		//increments the value
		number->value=number->value + 1;
		//printing the new value
		//printf("and writes value %f\n",number->value);
		//unlocking the mutex
		my_rw_writeunlock(&lockvar);
	}

	return ((void *) 0);
}

/****************************************************************************************
* This function initialized the pthread read/write locks.
*****************************************************************************************/
int init_rdwrlock(void)
{
	//initializing the read/write mutex
	if(my_rw_init(&lockvar)!=0)
	{
		printf("error...\n");
		exit(-1);
	}

	return 0;
}






#ifndef GLOBAL_H
#define GLOBAL_H

#define FALSE	0
#define TRUE	1

#define MAX_THREADS	10000

#define R	MAX_THREADS
#define C	2

#define WRITER	-777
#define READER	-444

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

/* struct that implements the my_rw_t mutex variable
*
* ---->   SHOULD BE IMPLEMENTED WITH POINTERS   <----
*/
typedef struct my_rw_t{
	//pthread mutex
	pthread_cond_t rdwr_condvar;
	//pthread condition variable
	pthread_mutex_t rdwr_mutex;

	//variable that indicates that a writer asked for the mutex
	volatile int interrupt;
	//variable that holds the state which indicates if there is a writer that has locked the my_rw_t mutex
	volatile int writers;
	//variable that holds the thread id of the writer
	pthread_t wr_tid;

	//array that holds the readers ids
	volatile unsigned int rd_stack[R][C];
	//variable that holds the number of readers threads that are inside the rd_stack
	volatile int stack_threads;
}my_rw_t;


#endif

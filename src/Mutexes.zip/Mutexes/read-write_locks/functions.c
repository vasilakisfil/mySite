//include the header file
#include "functions.h"

/******************************************************************************
* This function initializes the mutex.The read and write variables which 
* hold if the mutex is on read/write mode are initialized to 1 whereas the
* tid variable which holds the thread id is initialized to zero.Also a
* pthread mutex and a pthread condition variable are created.
*******************************************************************************/
int my_rw_init(my_rw_t *lockvar)
{
	int i,j;


	//initializing the rd_stack array
	for(i=0; i<R; i++)
	{
		for(j=0; j<C; j++)
		{
			lockvar->rd_stack[i][j]=-1;
		}
	}

	//initializing the stack_threads to 0 which indicates that there aren't any threads in the rd_stack array
	lockvar->stack_threads=FALSE;

	//initializing variable interrupt to indicate that there isn't any pending interrupt
	lockvar->interrupt=FALSE;
	//description coming soon
	lockvar->writers=FALSE;

	//initializing the pthread mutex
	pthread_mutex_init(&(lockvar->rdwr_mutex), NULL);
	//initializing the pthread condition variable
	pthread_cond_init(&(lockvar->rdwr_condvar), NULL);


	return 0;
}


/****************************************************************************************
* This function implements the read lock.After locking the pthread mutex to gain access
* to global struct,it checks if there is any pending interrupt(write lock) from
* writers.If there is then it calls pthread_cond_wait to block until the interrupt is
* served.Otherwise, it searches the rd_stack to find an empty ->cell<-.When an empty
* cell is found it is stored the threads' id and that it is a READER(actually this info
* is not used anywhere else but for the sake of portability it has not been removed).
* Also the stack_threads is incremented by one.Finally, the function unlocks the
* pthread mutex and returns.
*****************************************************************************************/
int my_rw_readlock(my_rw_t *lockvar)
{
	int i,j;

	//locking the mutex
	pthread_mutex_lock(&(lockvar->rdwr_mutex));
	while(lockvar->interrupt==TRUE)
	{
		pthread_cond_wait(&(lockvar->rdwr_condvar),&(lockvar->rdwr_mutex));
	}
	//searching for an empty cell
	for(i=0; i<R; i++)
	{
		//if the cell is empty then...
		if(lockvar->rd_stack[i][0]==-1)
		{
			//...store the id of the current thread...
			lockvar->rd_stack[i][0]=(unsigned int)pthread_self();
			//...store that the current thread is a READER...
			lockvar->rd_stack[i][1]=READER;
			//printf("%u thread incrments stack_thread from %d\n", (unsigned int)pthread_self(),lockvar->stack_threads);
			//...increment the stack_threads
			lockvar->stack_threads++;
			break;
		}
	}
	//unlocking the mutex
	pthread_mutex_unlock(&(lockvar->rdwr_mutex));
	return 0;
}


/****************************************************************************************
* This function implements the read unlock.It begins by locking the pthread mutex and
* then it searches on the rd_stack[x][0] array every thread id and matches it with its
* thread id by calling the pthread_self().After this, it reinitializes the value of the
* previous existed thread id and previous existed type(READER or WRITER) to -1.Also it
* decrements the the stack_threads variable by one and sets the flag to TRUE.When it
* exits the loop the function checks if the value of the flag has remained FALSE.If it
* is FALSE then it means that none of the existing ids stored to id_stack array was
* matching with the current id.In that case probably there won't be any problem but
* officially the behaviour is undefined due to lack of testing.Finally the function
* unlocks the pthread mutex and signals the change of the ondition variable.
*****************************************************************************************/
int my_rw_readunlock(my_rw_t *lockvar)
{
	int i,j,flag=FALSE;

	//locking the pthread mutex
	pthread_mutex_lock(&(lockvar->rdwr_mutex));

	//searching the rd_stack array for the a matching id...
	for(i=0; i<R; i++)
	{
		//and if there is one
		if((lockvar->rd_stack[i][0]==(unsigned int)pthread_self())&&(lockvar->rd_stack[i][1]==READER))
		{
			//reinitialize the cells
			lockvar->rd_stack[i][0]=-1;
			lockvar->rd_stack[i][1]=-1;
			//decrement the stack_threads variable by one
			lockvar->stack_threads--;
			//make the flag true which indicates that a matching id was found
			flag=TRUE;
			break;
		}
	}
	//if no matching id was found
	if(flag==FALSE)
	{
		//error message
		printf("Unlocking read lock before locking it!!! UNDEFINED BEHAVIOUR !!!\n^^^thread:%u\n",(unsigned int)pthread_self());
		//exit(-1);//uncomment this
	}
	//unlocking the pthread mutex
	pthread_mutex_unlock(&(lockvar->rdwr_mutex));
	//signaling the pthread condition variable to ALL blocked threads..
	pthread_cond_broadcast(&(lockvar->rdwr_condvar));

	return 0;
}

/****************************************************************************************
* This function implements the write lock.At the beginning it locks the pthread mutex(in
* order to gain acces to global struct) and then it marsk the lockvar->interrupt as
* TRUE.After this the function checks if the lockvar->writers variable is TRUE which, if
* it is, it indicates that the is another writer who has already locked the my_rw_t
* mutex.Also it checks if the stack_threads variable is not FALSE(=0) which, if it is,
* it indicates that there aren't any readers inside the stack.If these two conditions are
* true(no previous writer has locked the mutex,no readers inside the stack) then it marks
* the lockvar->writers variable as TRUE to indicate the entrance of the thread in the
* my_rw_t write lock, it stores the threads' id to thw lockvar->wr_tid variable and then
* it unlocks the pthread mutex.Otherwise it marks the lockvar->interrupt variable as TRUE
* to indicate that there is a aithsh for a write lock and then it calls pthread_cond_wait
* to block until an pthread_cond_broadcast is called from another thread.
*****************************************************************************************/
int my_rw_writelock(my_rw_t *lockvar)
{


	//locking the pthread mutex
	pthread_mutex_lock(&(lockvar->rdwr_mutex));
	//marking the interrupt as TRUE to indicate that a writer asked the my_rw_t mutex
	lockvar->interrupt=TRUE;//!!!
	//if there is a  previous writer that holds the my_rw_t mutex or if there is one or more readers in the stack then...
	while((lockvar->writers==TRUE)||(lockvar->stack_threads!=FALSE))
	{
		//mark the interrupt as TRUE <------------------------ ?
		lockvar->interrupt=TRUE;
		//printf("write thread %u got in writelock just before cond_wait...\n", (unsigned int)pthread_self());
		//...cal the pthread_cond_wait to block until a signal or broadcast is made
		pthread_cond_wait(&(lockvar->rdwr_condvar),&(lockvar->rdwr_mutex));
		//lockvar->interrupt=TRUE;
	}
	//otherwise mark the ockvar->writers variable as TRUE to indicate the entrance of the thread inside the my_rw_t mutex
	lockvar->writers=TRUE;
	//store the threads' id to lockvar->wr_tid
	lockvar->wr_tid=pthread_self();
	//and finally unlock the mutex
	pthread_mutex_unlock(&(lockvar->rdwr_mutex));
	return 0;
}


/****************************************************************************************
* This function implements write unlock.It is worthwise to mention that since only one 
* writer can lock the my_rw_t mutex, the pthread mutex here is not really required.But
* for the sake of stability it has been added.The function at first locks the pthread
* mutex and then checks if the previous thread that locked the write lock is the same(has
* the same id) with the current thead that unlocks the my_rw_t mutex.If the ids does not
* match, again, propably there won't be any problem but officially it hasn't been tested
* thoroughly.After this, the lockvar->writers variable is set to FALSE, the
* lockvar->wr_tid variable is set to 0 and the lockvar->interrupt variable is set also
* to FALSE.Before return, the function unlocks the phtread mutex and broadcasts the
* change of the condition variable.
*****************************************************************************************/
int my_rw_writeunlock(my_rw_t *lockvar)
{
	//locking the pthread mutex
	pthread_mutex_lock(&(lockvar->rdwr_mutex));
	//if the pthread id of the thread that locked the my_rw_t mutex is not the same as currents
	if(lockvar->wr_tid!=pthread_self())
	{
		//report error
		printf("FATAL ERROR!!!\n");
		printf("You either try to unlock a write lock before locking it or more than one thread had access to the common resource !!!\n");
		printf("^^^thread:%u\n",(unsigned int)pthread_self());
		exit(-1);
	}
	//otherwise set the lockvar->writers to FALSE
	lockvar->writers=FALSE;
	//set the lockvar->wr_tid to 0
	lockvar->wr_tid=0;
	//and set the lockvar->interrupt to FALSE
	lockvar->interrupt=FALSE;

	//unlocking the pthread mutex
	pthread_mutex_unlock(&(lockvar->rdwr_mutex));
	//broadcasting the change of the condition variable
	pthread_cond_broadcast(&(lockvar->rdwr_condvar));


	return 0;
}


/******************************************************************************
* This function destroys the my_rw_t mutex.In fact it stores to lockvar->read, 
* lockvar->write and lockvar->tid varibles a value of zero.At last it destroys
* the pthread mutex and pthread condition variable through the pthread functions.
*******************************************************************************/
int my_rw_destroy(my_rw_t *lockvar)
{
	int i,j;


	//destroying the pthread mutex
	pthread_mutex_destroy(&(lockvar->rdwr_mutex));
	//pthread_cond_destroy(&(lockvar->condvar));
	pthread_cond_destroy(&(lockvar->rdwr_condvar));

	//reinitializing the lockvar->rd_stack to -1
	for(i=0; i<R; i++)
	{
		for(j=0; j<C; j++)
		{
			lockvar->rd_stack[i][j]=-1;
		}
	}

	//setting a random value to lockvar->stack_threads
	lockvar->stack_threads=1000;
	//setting TRUE to lockvar->writers variable
	lockvar->writers=TRUE;

	return 0;
}



